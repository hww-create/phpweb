<?php
namespace app\index\controller;

use think\Controller;
//引用运用类
use org\Upload;

class Users  extends Controller
{


       //1.角色
      //1.对应的表:admin_group

     //(这是要在网站上显示出来的页面)
     //角色规则列表的(select)
     public function admin_role_list()
     {
          //展示的是角色列表，所以要实例化角色表
          $m=M('auth_group');
          $data=$m->where("status=1")->select();
          $this->assign('data',$data);
          return $this->fetch();
     }


    //添加角色显示页面(add)
    public function admin_role_add()
    {
        //因为添加角色要分配给角色的某些权限,所以要实例化权限表
        $m = M('auth_rule');
        $data = $m->where('status=1')->select();
        $this->assign('data', $data);
        return $this->fetch();
    }

    //添加角色到数据库(表单提交的处理方法)
    public function admin_role_add_data()
    {
         //把权限列表的数据以表单的形式传输过来,用这个方法来接收处理
         $data['title']=$_POST['roleName'];
         $data['status']=1;
        //以逗号合并成字符串
         $data['rules']=implode(',',['check']);
         //把添加的带有权限功能的角色数据存储到对应的角色表中(实例化数据库)
         $m=M('auth_group');
         $result=$m->add($data);
            if($result)
            {
                return $this->success("添加角色成功",'admin_role_list',3);
            }else{
                 return $this->error("添加角色失败",'admin_role_list',3);
            }
    }


 //修改角色显示页面(update)
    public function admin_role_edit()
    {
        //因为修改角色也要修改角色对应的权限,所以要实例化权限表
        $m=M('auth_rule');
        $data=$m->where('status=1')->select();
        $this->assign('data',$data);
        return $this->fetch();
    }


    //修改角色到数据库(表单提交的处理方法)
    public function admin_role_edit_data()
    {
        //把权限列表的数据以表单的形式传输过来，用这个方法来接收处理
        //获取第一次要修改数据的id
        $id = $_POST['id'];
        $data['title']=$_POST['roleName'];
        $data['status']=1;
        //以逗号合并成字符串
        $data['rules']=implode(',',['check']);
        //把修改的带有权限功能的角色数据储到对应的角色表中(实例化数据库)
        $m=M('auth_group');
        //第二次的id是用来展示的
        $result=$m->where("id=".$id)->save($data);
        if($result){
            return $this->success("修改角色成功",'admin_role_list',3);
        }else{
            return $this->error("修改角色失败",'admin_role_list',3);
        }
     }


    //角色删除
    public function admin_role_del()
    {
       $id = $_GET['id'];
       $m = M('auth_group');
       $result = $m->delete($id);
         if($result){
             echo "1";
         }else{
             echo "0";
         }
    }











      //2.权限
      //2.对应的表:admin_rule

      //(这是要在网站上显示出来的页面)
      //权限列表页面(select)
    public function admin_permission_list()
    {
        //展示的是权限列表，所以要实例化权限表
        $m=M('auth_rule');
        $data=$m->where('status=1')->select();
        $this->assign('data',$data);
        return $this->fetch();
    }

     //添加权限页面(add)限到数据库(表单提交的处理方法)
    public function admin_permission_add()
    {
        return $this->fetch();
    }

     //添加权限到数据库(表单提交后台处理方法)
    public function admin_permission_add_data()
    {
        //把权限列表的数据以表单的形式传输过来,用这个方法来接收处理
         $data['name']=$_POST['name'];
         $data['title']=$_POST['title'];
         $data['type']=1;
         $data['status']=1;
         //把添加的权限节点存储到数据库中(实例化数据库)
         $m=M('auth_rule');
         $result=$m->add($data);
           if($result)
           {
                return $this->success("添加权限成功",'admin_permission_list',3);
           }else{
                return $this->error("添加权限失败",'admin_permission_list',3);
           }
    }


    //修改权限显示页面(update)
    public function admin_permission_edit()
    {
        return $this->fetch();
    }


    public function admin_permission_edit_data()
    {
        //把权限列表的数据以表单的形式传输过来,用这个方法来接收处理
        $id = $_POST['id'];
        $data['name']=$_POST['name'];
        $data['title']=$_POST['title'];
        $data['type']=1;
        $data['status']=1;
        //把添加的权限节点存储到数据库中(实例化数据库)
        $m=M('auth_rule');
        $result=$m->where("id=".$id)->save($data);
        if($result)
        {
            return $this->success("修改权限成功",'admin_permission_list',3);
        }else{
            return $this->error("修改权限失败",'admin_permission_list',3);
        }
    }


    //权限删除
    public function admin_permission_del()
    {
          //先要传一个id过来
          $id = $_GET['id'];
          //实例化数据库
          $m  = M('auth_rule');
          $result = $m->delete($id);
            if ($result) {
               echo 1;
            } else {
                echo 0;
            }
    }









    //3.管理员
    //3.对应的表:admin_user

    //(这是要在网站上显示出来的页面)
    //管理员列表页面(select)
    public function admin_user_list()
    {
        //展示的是管理员的列表,所以要实例化管理员表
         $m=M('admin_user');
         $data=$m->select();
         $this->assign('data',$data);
         return $this->fetch();
    }

    //添加管理员界面(add)
    public function admin_user_add()
    {
        //因为添加管理员要确定这个管理员是什么角色，所以要实例化角色表
         $m=M('auth_group');
         $data=$m->where('status=1')->select();
         $this->assign('data',$data);
         return $this->fetch();
    }

    //添加管理员到数据库(表单提交的处理方法)(add)
    public function admin_user_add_data()
    {
        //如果$_POST存在
        if ($_POST) {
            //接收表单传过来的值(现在已有值)
             $data['admin_name']=$_POST['admin_name'];
             $data['admin_password']=$_POST['admin_password'];
            //把添加了管理员的数据存储到数据库中，所以要实例化用户数据库(激活数据库)
             $m=M('admin_user');
            //先查询一条记录(找出有相同名字的数据),(以名字作为条件)  (这条语句作为下面的判断条件用)
             $name=$m->where("admin_name='".$_POST['admin_name']."'")->find();

            //接着判断是否有相同的名字
            //如果没有重复名字，那就创建新用户(每每将两个数据进行对比，看是否相同)
            //也就是用户id(uid)
             if(!$name){
                //首先实例化角色分组数据库
                $g=M('auth_group_access');
                //然后把(表单传值)注册新用户的数据添加到用户数据库中(admin_user)(没有重名的情况下)
                 $result1=$m->add($data);
                //接着接收新用户的数据(在角色分组数据库中)
                 $groupAccess['group_id']=$_POST['group_id'];
                 $groupAccess['uid']=$result1;  //已经有新用户的数据id了,把新用户的数据放到分组表里面
                //用户数据库（$name）
                //把新用户的数据存储到分组数据库中
                  $result2=$g->add($groupAccess);
                //否则有重复名字，那就过滤 (每每将两个数据进行对比，看是否相同)
                //接下来判断同个名字的数据前后两次是否相同,相同就成功
                     if($result1 && $result2){
                         return $this->success("添加用户成功",'admin_user_list',3);
                     }else{
                         return $this->error("添加用户失败",'admin_user_list',3);
                     }

            }else{
                  //如果有重名,就添加用户失败
                 return $this->error("当前用户已存在,添加失败");
             }
        }
    }


    //修改管理员显示页面(update)
    public function admin_user_edit()
    {
//        //因为修改管理员也要修改管理员对应的角色,所以要实例化角色表
         $m=M('auth_group');
         $data=$m->where('status=1')->select();
         $this->assign('data',$data);
         return $this->fetch();
    }

    //修改管理员显示页面(update)
    public function admin_user_edit_data()
    {
        if ($_POST) {
            //
            $id = $_POST['id'];
            $data['admin_name']=$_POST['admin_name'];
            $data['admin_password']=$_POST['admin_password'];
            $m=M('admin_user');
            //判断是否有相同用户
            $name=$m->where("admin_name='".$_POST['admin_name']."'")->find();

            if(!$name){
                $g=M('auth_group_access');
                $result1=$m->where("id=".$id)->save($data);
                //接着接收用户的数据(在角色分组数据库中)
                //接收group_id
                $groupAccess['group_id']=$_POST['group_id'];
                //通过 uid 查找  修改group_id
                $result2=$g->where("uid=".$id)->save($groupAccess);


                //否则有重复名字，那就过滤 (每每将两个数据进行对比，看是否相同)
                //接下来判断同个名字的数据前后两次是否相同,相同就成功
                if($result1 && $result2){
                    return $this->success("修改管理员用户成功",'admin_user_list',2);
                }else{
                    return $this->error("修改管理员用户失败",'admin_user_list',2);
                }

            }else{
                //如果有重名,就添加用户失败
                return $this->error("当前用户已存在,修改失败");
            }
        }
    }


    //角色删除
    public function admin_user_del()
    {
        $id = $_GET['id'];
        $m = M('admin_user');
        $result = $m->delete($id);
        if($result){
            echo "1";
        }else{
            echo "0";
        }
    }

}
