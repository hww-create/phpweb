<?php
namespace app\index\controller;
use think\Controller;
//引入拓展类
use \org\Auth;

 //重点:1.admin是有分类添加的权限
 //重点:2.这个(Common)是公共类,让其他的类都继承这个公共的类

class Common extends Controller
{

     //当任何函数加载的时候，会调用此函数(相当于构造函数一样)
    public function _initialize() //默认的方法 会自动执行 (特征有点像构造方法)
    {
        //第一步:为获取session的id
         $uid=session('user')['id'];

        //第二步:接下来为判断条件:(1)如果没有获取到id，则显示没有登录，就跳转到:index/Login/index
           if(empty($uid)){
                echo "<script>alert('登录失败');location.href='".U('index/Login/index')."'</script>";
           }

        //第三步:引入拓展类
        //第四步:开启权限
            $AUTH = new \org\Auth();
         //相当于 MODULE_NAME.'/'.CONTROLLER_NAME.'/'.ACTION_NAME

        //第五步:这里用到的是 权限 登录,(2)所以要接判断语句(检查，用到check()方法)这个某某角色的管理员有没有权限。
        //第六步:写上没有权限的跳转语句，跳转地址为：index/Login/check_error
//        var_dump(session('user')['id']);
//          var_dump($AUTH->check(MODULE_NAME.'/'.CONTROLLER_NAME.'/'.ACTION_NAME,session('user')['id']));exit;
           if(!$AUTH->check(MODULE_NAME.'/'.CONTROLLER_NAME.'/'.ACTION_NAME,session('user')['id'])){
              echo "<script>location.href='".U('index/Login/check_error')."'</script>";
//               $login = new Login();
//               $login->check_error();
           }

        //第七步:在Login控制器里面写上检测权限的方法:check_error()
////
    }

}

?>
