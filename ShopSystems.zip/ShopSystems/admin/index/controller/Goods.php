<?php

namespace app\index\controller;

class Goods extends Common
{
    //1-1.
    //对应的product_category.html前端页面
    //分类总展示界面
    public function product_category()
    {
        return $this->fetch();
    }


    //1-2-1.
    //对应的product_category.html前端页面
    //使用ajax获取无限分类数据  (select)
    public function product_category_select_ajax()
    {
        //创建出数据库对象
        $m = M('goods_type');
        //把指定的字段数据查出来，这里有三个字段
        $data = $m->field("id,pid,name")->select();
        //输出数据(因为使用了ajax，所以要用json_encode方法承载输出查询的数据)
        //json_encode()方法是把数据传到ajax上去
        echo json_encode($data);
    }


    //对应的product_category.html前端页面
    //使用ajax删除无限分类数据    (del)
    public function product_category_del_ajax()
    {
        //1.通过get方法把表单的数据以id作为条件传过来(因为删除要用id传过来)
        $id = $_GET['id'];
        //2.再者,如果一级分类下面还有子分类，则不允许删除
        //(1)先实例化数据库对象
        $m = M('goods_type');
        //(2)先查询出 分类下面还有没有分类的数据(要做判断语句)
        //(3)如果有数据，则显示"分类下面还有子分类，不允许删除"
        //(4)如果没有数据，就删除
        //(5)如果删除成功，就输出1
        $data = $m->where('pid=' . $id)->find();
        if ($data) {
            $str = "分类下面还有子分类,不允许删除";
            echo json_encode($str);
        } else {
            //通过get方式传过来的以id为条件
            $result = $m->delete($id);
            if ($result) {
                echo 1;
            }
        }

    }

    //1-2-2.
    //对应的product_category_add.html前端页面
    //这是创建无限分类的方法    (add)  相当于表单一样
    public function product_category_add()
    {
        //实例化数据库
        $m = M('goods_type');
        //查询出数据然后进行排序(要查询呢出所有字段)
        $data = $m->field("*,concat(path,',',pid) as paths")->order("paths")->select();//路径连接
        //把查询出来的数据进行遍历
        foreach ($data as $k => $v) {
            //(将原本的name改为新的name)(通过等级来判断,如果等级为1就输出"|---")
            //如果等级为2就输出"|---|---")
            //这个为新名字
            $data[$k]['name'] = str_repeat("|---", $v['level']) . $v['name'];
            //str_repeat()函数的功能就是用新字符串替换旧字符串
        }
        $this->assign('data', $data);
        return $this->fetch();
    }

    //这是处理创建无限分类数据的方法  顺便添加 分类信息 到数据库 的方法    (add)
    //对应的producy_category_add.html前端页面
    public function goods_type_add()
    {

        //分类名称(表单传值)
        $data['name'] = $_POST['name'];
        //备注
        $data['pid'] = $_POST['pid'];
        $m           = M('goods_type');

        //pid不为0
        if ($data['name'] != "" && $data['pid'] != 0) {

            //这块代码不考虑path的id顺序
            //首先查询"一个"路径,以路径作为查询条件(把pid查询出来)
            $path = $m->field("path")->find($data['pid']);   //pid

            $data['path'] = $path['path'];
            //统计逗号的个数以显示等级差别
            $data['level'] = substr_count($data['path'], ",");
            //返回插入的id;添加数据
            $re = $m->add($data);

            //分类优化
            //这块代码考虑path的id顺序
            //获取它的最后一个路径
            $path['id']    = $re;
            $path['path']  = $data['path'] . ',' . $re;
            $path['level'] = substr_count($path['path'], ",");
            //把添加的数据保存在数据库中
            $res = $m->save($path);
            if ($res) {
                return $this->success("添加分类成功3", "product_category_add", 2);
            } else {
                return $this->error("添加分类失败4", "product_category_add", 2);
            }

            //pid为0
        } else if ($data['name'] != "" && $data['pid'] == 0) {


            //如果等级为1，就不用查询路径
            //$path = $m->field("path")->find($data['pid']);  //pid
            $data['path'] = $data['pid'];
            //pid等于0就为1级(永远显示最上级)
            $data['level'] = 1;

            //分类优化
            //返回插入的id;添加数据到数据库中
            $re = $m->add($data);
            //它的最后一个路径
            $path['id']   = $re;
            $path['path'] = $data['path'] . ',' . $re;
            $res          = $m->save($path); //保存在数据库中
            if ($res) {
                return $this->success("添加分类成功1", "product_category_add", "", 2);
            } else {
                return $this->error("添加分类失败2", "product_category_add", "", 2);
            }


        } else {
            return $this->error("添加分类失败,内容不能为空", "product_category", "", 2);
        }

        //重点:如果是平级，相当于是没有把id加进来
    }








    //2.这是要在网站上展示出来的页面(add)
    //对应的product_add.html前端页面
    //添加商品页 (相当于表单一样)
    public function product_add()
    {
        //实例化数据库
        $m = M('goods_type');
        //查询出数据然后进行排序(要查询出所有字段)
        $data = $m->field("*,concat(path,',',id) as paths")->order("paths")->select();
        //把查询出来的数据进行遍历,这个foreach是对应前端页面的
        foreach ($data as $k => $v) {
            $data[$k]['name'] = str_repeat("|---", $v['level']) . $v['name'];
        }
        //把查询出来的数据给assign,然后通过fetch()方法显示出来
        $this->assign('data', $data);
        return $this->fetch();
    }
    //6.商品图片上传 (不懂的地方)
    //通过ajax来上传
    public function producu_shangchuang_images()
    {
        $upload           = new \org\Upload(); //实例化上传类
        $upload->maxSzie  = 3145728; //设置附件上传大小
        $upload->exts     = array('jpg', 'gif', 'png', 'jpeg'); //设置附件上传类型
        $upload->rootPath = './static/images/'; //设置附件的上传目标目录 //上传文件
        $upload->saveName = time() . rand(1111, 9999); //
        $date             = date("Y-m-d", time()); //已上传日期为子目录名
        $upload->saveExt  = "png";  //上传的文件后缀
        //把文件都传入到upload()
        $info = $upload->upload();

        //判断上传文件的语句
        if (!$info) { //上传错误提示错误信息
            $this->error($upload->getError());
            echo $upload->getError();exit;
        } else {   //上传成功
            $m = M('goods_files');
            //文件路径的数据
            $data['filepath'] = '/static/images/' . $date . "/" . $upload->saveName . "." . $upload->saveExt;
            $result           = $m->add($data);
            $file             = ['id' => $result, 'imagepath' => $data['filepath']];
            echo json_encode($file);
        }
    }
    //添加商品页的处理页(add)
    public function product_add_goods()
    {
        $m = M("goods");
        //接收表单传过来的数据
        $data['goodsname'] = $_POST['goodsname'];

        //获取分类的id及pid
        $tid = explode(",", $_POST['tid']);
        $data['tid']  = $tid[0];
        $data['tpid'] = $tid[1];

        $data['unit']       = $_POST['unit'];
        $data['curprice']   = $_POST['curprice'];
        $data['number']     = $_POST['number'];
        $data['attributes'] = $_POST['attributes'];
        $data['barcode']    = $_POST['barcode'];
        $data['oriprice']   = $_POST['oriprice'];
        $data['cosprice']   = $_POST['cosprice'];
        $data['inventory']  = $_POST['inventory'];
        $data['restrict']   = $_POST['restrict'];
        $data['already']    = $_POST['already'];
        $data['freight']    = $_POST['freight'];
        $data['reorder']    = $_POST['reorder'];
        $data['status']     = $_POST['status'];
        //拼接图片
        $data['imagepath'] = implode(',',$_POST['imagepath']);
//        $data['text'] = $data['editorValue'];


        //将以上数据保存到数据库中
        $result = $m->add($data);
        //判断添加成功与否:
        if ($result) {
            return $this->success("添加商品成功", "product_list", "", 1);
        } else {
            return $this->error("添加商品失败", "product_list", "", 1);
        }
    }







    //3.这是要在网站上展示出来的页面(select)
    //商品查询
    //对应的product_list.html前端页面
    //商品列表分类页
    public function product_list()
    {
        $m     = M('goods');
        $where = "";
        if (!empty($_GET['id'])) {
            $where = "tid='" . $_GET['id'] . "'";
            //var_dump($where);exit;
        }
        $data = $m->where($where)->select();
        $this->assign('data', $data);
        return $this->fetch();
    }








    //4. 这是要在网站上展示出来的页面(update)
    //商品修改前台显示页方法
    //对应的product_edit_goods.html前端页面
    public function product_edit_goods()
    {
        //商品数据
        $g = M('goods');
        //首先传需要修改商品的id过来
        $goods = $g->find($_GET['id']);
        $this->assign("goods", $goods);


        //无限分类
        $m = M('goods_type');
        //把无限分类的列表查询出来
        $data = $m->field("*,concat(path,',',id) as paths")->order("paths")->select();
        //也需要写分类的方法
        //var_dump($data);exit;
        foreach ($data as $k => $v) {
            $data[$k]['name'] = str_repeat("|---", $v['level']) . $v['name'];
        }
        $this->assign("data", $data);  //无限分类数据


        //图片
        $images = explode(',', $goods['imagepath']);
        //实例化图片数据库
        $i      = M('goods_files');
        $images = [];
        foreach ($images as $v) {
            array_push($images, $i->find($v));
        }
        $this->assign("image", $images);

        return $this->fetch();
    }


    //商品修改后台处理页方法(接收表单传过来的数据)
    public function product_edit_goods_new()
    {
        //调试工具 //var_dump($_POST);exit;

        //首先实例化数据库
        $m = M('goods');

        //接收表单传过来的数据
        //获取第一次要修改数据的id
        $data['id'] = $_POST['id'];

        //获取无限分类的id及pid
        $tid          = explode(",", $_POST['tid']);
        $data['tid']  = $tid[0];
        $data['tpid'] = $tid[1];

        $data['goodsname']  = $_POST['goodsname'];
        $data['unit']       = $_POST['unit'];
        $data['curprice']   = $_POST['curprice'];
        $data['number']     = $_POST['number'];
        $data['attributes'] = $_POST['attributes'];
        $data['barcode']    = $_POST['barcode'];
        $data['oriprice']   = $_POST['oriprice'];
        $data['cosprice']   = $_POST['cosprice'];
        $data['inventory']  = $_POST['inventory'];
        $data['restrict']   = $_POST['restrict'];
        $data['already']    = $_POST['already'];
        $data['freight']    = $_POST['freight'];
        $data['reorder']    = $_POST['reorder'];
        $data['status']     = $_POST['status'];
        $data['imagepath'] = implode(',',$_POST['imagepath']);


        //$data['text']=$_POST['editorValue'];

        //第二次已经修改了要显示出来的id
        $result = $m->where("id=" . $data['id'])->save($data);
        if ($result) {
            return $this->success("修改商品成功", "product_list", "", 3);
        } else {
            return $this->error("修改商品失败", "product_list", "", 3);
        }
    }









    //5.删除商品后台处理方法
    public function product_del()
    {
        $id     = $_GET['id'];
        $m      = M('goods');
        $result = $m->delete($id);
        if ($result) {
            echo 1;
        } else {
            echo 0;
        }
    }


//7.商品上下架
    public function status()
    {
        $id     = $_POST['id'];
        $status = $_POST['status'];
        $m      = M('goods');
        $result = $m->where(['id' => $id])->save(['status' => $status]);

        if ($result) {
            return json_encode(['msg' => '成功', 'code' => 1, 'data' => []], true);
        } else {
            return json_encode(['msg' => '失败', 'code' => 0, 'data' => []], true);
        }
    }





    //商品图片删除
    //通过ajax来删除
    public function product_images_del()
    {
        //传过来要删除的id
        $id     = $_GET['id'];
        $m      = M('goods_files');
        $result = $m->delete($id);
        if ($result) {
            echo 1;
        } else {
            echo 0;
        }
    }


    //添加商品图片数据库
    public function product_add_goods_ajax()
    {
        var_dump($_FILES);
        echo 1;
    }
}








