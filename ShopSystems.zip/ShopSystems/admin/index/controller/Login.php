<?php

namespace app\index\controller;
use think\Controller;


//登录控制器

class Login extends Controller
{

    //后台登录显示页面方法
     public function index()
     {
         return $this->fetch();
     }


    //后台登录处理方法
     public function dologin()
     {

         //实例化数据库(因为登录的是管理员，所以要用admin_user)
         //接收登录前台表单传过来的数据,顺便给查询出来
           $m=M('admin_user');
           $data=$m->where('admin_name="'.$_POST["admin_name"].'" and admin_password="'.$_POST["admin_password"].'"')->find();
         //这里用到session来传id的数据
         //如果登录成功,跳转到:index/index/index(也就是后台主页)
           if($data) {
               session('user',$data);
               return $this->success("登录成功",'../index/index',2);
           }else{
               //否则就登录失败
               return $this->error("登录失败");
            }
     }

       //管理员角色的权限检测方法
        public function check_error()
        {
//            echo 123;exit;
//            '../login/index'
            //没有权限的话,跳转到:  ../index/welcome
            return $this->success("没有权限",'../login/index',2);
        }



}

?>
