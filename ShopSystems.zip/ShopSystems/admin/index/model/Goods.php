<?php	
namespace app\index\model;

class User extends \think\Model


{
}

?>