<?php
namespace app\index\controller;

use \think\Controller;
use \think\Cache;

class Index   extends Controller
{
    //这是商城的首页
    public function index()
    {
         //实例化无限分类表
         $m=M('goods_type');
         $type=$m->where("pid=0")->select();//获取一级分类(直接查pid为0作为条件)
         $type2=array();
         $type3=array();
         //$type4=array();
            foreach($type as $k1=>$v1){    //遍历一级分类来获取二级分类
                  $type[$k1]['child']=array();//组装二级分类的数组(set:空)(创建一个新的'child'值)
                  $type2=$m->where("pid=".$v1['id'])->select();//(get)获取二级分类(通过一级分类的id来查询二级分类的pid)(一级分类的id等于二级分类的pid)

                  foreach($type2 as $k2=>$v2){ //遍历二级分类来获取三级分类
                      array_push($type[$k1]['child'],$v2);//合并一二级分类
                      $type[$k1]['child'][$k2]['child2']=array();//组装三级分类的数组(set:空)(创建一个新的'child2'值)
                      $type3=$m->where("pid=".$v2['id'])->select();//获取三级分类(通过二级分类的id来查询三级分类的pid)(二级分类的id等于三级分类的pid)

                          foreach($type3 as $k3=>$v3){ //遍历三级分类来获取更多的分类
                              array_push($type[$k1]['child'][$k2]['child2'],$v3);//合并一二三级分类
                              //$type[$k1]['child'][$k2]['child2'][$k3]['child3']=array()组装四级分类
                              //$type4=$m->where("pid=".$v3['id'])->select();获取四级分类
                          }
                  }
            }

            $this->assign('type',$type);
            return $this->fetch();
    }







    public function lists()
    {
        header("Content_Type:text/html;charset=utf-8");
        $m=M('goods');
        $i=M('goods_files');
        //分类的id等于它传过来商品的id
        $data=$m->where("tid=".$_GET['id'])->where(['status'=>1])->select();
        $array=array();

           foreach($data as $k=>$v){
               $v['image']=array(); //图片的名字
               $imageId=explode(',',$v['imagepath']);

                  foreach($imageId as $vid){
                      $img=$i->field('filepath')->where('id='.$vid)->find();
                       array_push($v['image'],$img);

                  }
                  array_push($array,$v);
           }

        $this->assign('data',$array);
        return $this->fetch();
    }




    public function details(){

        return $this->fetch();
    }
}
