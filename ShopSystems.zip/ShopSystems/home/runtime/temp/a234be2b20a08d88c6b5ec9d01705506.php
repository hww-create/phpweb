<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:54:"C:\wamp\www\tp5\application\index\view\blue\index.html";i:1461214455;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	这是blue模板
	
</body>
</html>