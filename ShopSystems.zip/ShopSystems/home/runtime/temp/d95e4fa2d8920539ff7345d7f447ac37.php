<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"E:\phpstudy\PHPTutorial\WWW\PHPweb\ShopSystems\home\index\view\index\lists.html";i:1574436826;}*/ ?>
﻿<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
        <meta name="baidu-site-verification" content="ZEXvy8Xkma" />
        <link rel="dns-prefetch" href="//mallcmscdn.baidu.com">
        <link rel="dns-prefetch" href="//mallcdn.baidu.com">
        <link rel="dns-prefetch" href="//hm.baidu.com">
        <link rel="dns-prefetch" href="//bcscdn.baidu.com">
        <link rel="dns-prefetch" href="//bj.bcebos.com">

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>服装服饰</title>

        <script>
            void function(g,f,j,c,h,d,b){g.alogObjectName=h,g[h]=g[h]||function(){(g[h].q=g[h].q||[]).push(arguments)},g[h].l=g[h].l||+new Date,d=f.createElement(j),d.async=!0,d.src=c,b=f.getElementsByTagName(j)[0],b.parentNode.insertBefore(d,b)}(window,document,"script","http://img.baidu.com/hunter/alog/alog.min.js","alog");void function(){function c(){return;}window.PDC={mark:function(a,b){alog("speed.set",a,b||+new Date);alog.fire&&alog.fire("mark")},init:function(a){alog("speed.set","options",a)},view_start:c,tti:c,page_ready:c}}();void function(n){var o=!1;n.onerror=function(n,e,t,c){var i=!0;return!e&&/^script error/i.test(n)&&(o?i=!1:o=!0),i&&alog("exception.send","exception",{msg:n,js:e,ln:t,col:c}),!1},alog("exception.on","catch",function(n){alog("exception.send","exception",{msg:n.msg,js:n.path,ln:n.ln,method:n.method,flag:"catch"})})}(window);
        </script>
<meta name="keywords" content="hww">
<meta name="description" content="hww">

        <link rel="shortcut icon" href="http://mallcdn.baidu.com/static/2016033051016/favicon.ico" >
        <script src="/static/index/js/core.js"></script>

        <script>
            require.config({
        'waitSeconds': 30,
        'baseUrl': 'http://mallcdn.baidu.com/static/2016033051016/js',
        'packages': [
            {
                'name': 'echarts',
                'location': '../dep/echarts/2.2.7/src',
                'main': 'echarts'
            },
            {
                'name': 'zrender',
                'location': '../dep/zrender/2.1.1/src',
                'main': 'zrender'
            }
        ]
    });
        </script>

<link rel="stylesheet" href="/static/index/css/goodslist.css">

        <script>
        var cr = Math.floor(Math.random() * 99999);
        var activityId = '';
        var pageId = '3' ? '3' : 0;
        var rtTag = $.stringifyJSON();

        // if (location.href.indexOf('mall.baidu.com') !== -1) {
            var _hmt = _hmt || [];
            var siteId = 'd64af1f3b8e241d56f0536501d4bfdd6';
            _hmt.push(['_setAccount', siteId]);
            _hmt.push(['_setAutoPageview', false]);

            if (rtTag) {
                _hmt.push(['_trackRTEvent', {
                    data: $.parseJSON(rtTag)
                }]);
            }

            trackPageViewTJ(siteId, '3', '[{"tg": "sv.18061262886301460904652522302_exp." }]');
            if ('' !== '') {
                require(['common/md5'], function (md5) {
                    var merchantSiteId = md5('');
                    _hmt.push(['_setAccount', merchantSiteId]);
                    _hmt.push(['_setAutoPageview', true]);
                    deployBaiduTJ(merchantSiteId);
                });
            // }
        }

        </script>
    </head>
    <script>
        alog('speed.set', 'ht', +new Date);
    </script>
    <body>
        <script>
            var GLOBAL_CONF = {"debug":false,"passport":{"host":"passport.baidu.com","tpl":"bdmall"},"site":{"siteId":7202944,"ucId":10914574}};
        </script>

<div id="common-header" class="normal-header">
    <div class="mini-header-search">
        <div class="container">
            <div class="user-info">
                <span class="common-login-info">
                    <a class="logo" href="/" data-position-id="1000001">返回首页</a>
                </span>
            </div>
        </div>
    </div>



<script>

    $(document).ready(function(){
        require(['widget/header'], function (cart) {
            cart.init();
        });
    });

</script>

<div class="goods-list-container">

    <div class="nav-bar">


        <div class="nav_position comWidth">

	<div class="nav">


	</div>

        </div>

    </div>

    <div>
        <div class="main-content">

<div class="store-sinfo" data-sid="18061262886301460904652522302" data-exp-infos=""></div>
<div class="product-filter">
    <div class="product-filter-content">

        <div class="product-attr-filter">

            <div class="product-attr-content">

                <div class="filter-content">
                    <ul class="categoty-wrapper">


                    </ul>
                </div>
            </div>

            <div class="more-option">
                <a href="javascript:void(0)" class="more-stretch">更多选项（风格、版式）&nbsp;<i class="icon-font icon-arrow-down2"></i></a>
                <a href="javascript:void(0)" class="more-shrink">收起&nbsp;<i class="icon-font icon-arrow-up2"></i></a>
            </div>
        </div>

        <!-- 排序 -->
        <div class="sort-wrapper">
            <div class="sort-container">
                <div class="clearfix">

                    <div class="fixed-attribute">
                            <a href="javascript:void(0)" data-pid="43246" class="all-category more-filter">品牌<i class="icon-arrow-down2"></i></a>
                            <a href="javascript:void(0)" data-pid="49" class="all-category more-filter">上市时间<i class="icon-arrow-down2"></i></a>
                            <a href="javascript:void(0)" data-pid="50077" class="all-category more-filter">主要材质<i class="icon-arrow-down2"></i></a>
                            <a href="javascript:void(0)" data-pid="50079" class="all-category more-filter">版型<i class="icon-arrow-down2"></i></a>
                            <a href="javascript:void(0)" data-pid="27" class="all-category more-filter">领型<i class="icon-arrow-down2"></i></a>
                            <a href="javascript:void(0)" data-pid="43170" class="all-category more-filter">裤型<i class="icon-arrow-down2"></i></a>
                    </div>


                </div>

                <div class="category-list-bar">
                    <ul class="categoty-wrapper">

                    </ul>
                </div>
            </div>
        </div>

    </div>
</div>

            <script>
                void function(e,t){for(var n=t.getElementsByTagName("img"),a=+new Date,i=[],o=function(){this.removeEventListener&&this.removeEventListener("load",o,!1),i.push({img:this,time:+new Date})},s=0;s<n.length;s++)!function(){var e=n[s];e.addEventListener?!e.complete&&e.addEventListener("load",o,!1):e.attachEvent&&e.attachEvent("onreadystatechange",function(){"complete"==e.readyState&&o.call(e,o)})}();alog("speed.set",{fsItems:i,fs:a})}(window,document);
            </script>
    		<div class="shop-product-list" data-count="3027">

<div class="widget-loading">
    <span class="content">
        <img src="/static/index/img/loading.gif">
        <span class="text">正在加载，请稍后…</span>
    </span>
</div>

<ul class="product-list">
<?php foreach($data as $data): ?>

    <li class="product-item product-item0" data-id="17170" data-skuid="94336" data-position-id="4000020"
        style="pointer-events: none;">

        <div class="product-wrapper">

            <div class="img-container">

                <img class="cover-img" src="<?php echo $data['image'][0]['filepath']; ?>" data-title="<?php echo $data['goodsname']; ?>">

            </div>


<div class="small-img-list  no-padding ">
 <div class="banner">
    <div class="swiper-container">
       <div class="swiper-wrapper">
        <div class="swiper-slide">
            <?php foreach($data['image'] as $image): ?>
                <a href="javascript:void(0)" target="_blank">
                    <img data-origin="<?php echo $image['filepath']; ?>" src="<?php echo $image['filepath']; ?>" class="swiper-lazy" alt="">
                </a>
            <?php endforeach; ?>
        </div>
       </div>
    </div>
 </div>
</div>

            <div class="context">


                <h3 class="price">

                    <sub>￥</sub><?php echo $data['curprice']; ?>
                </h3>
                <a class="title" href="/product?itemId=17170&skuId=94336"  data-position-id="4000020"><?php echo $data['goodsname']; ?></a>
                <p class="shop-name"  data-id="297" data-position-id="4000021">
                    <a href="/shop?shopId=297" target="_blank" data-position-id="4000021"><?php echo $data['goodsname']; ?></a>
                </p>
            </div>


        </div>

    </li>
   
 <?php endforeach; ?>
   
</ul>
</div>
</div>

<div class="left-aside">



<script type="text/javascript" src="/static/index/js/backtop.js"></script>
<script type="text/javascript" src="/static/index/js/category.js"></script>
<script type="text/javascript" src="/static/index/js/cookie.js"></script>
<script type="text/javascript" src="/static/index/js/header.js"></script>
<script type="text/javascript" src="/static/index/js/index.js"></script>
<script type="text/javascript" src="/static/index/js/etpl.js"></script>
<script type="text/javascript" src="http://mallcdn.baidu.com/static/2016033051016/js/common/cookie.js"></script>
<script>
$(function () {
    require(['goodsList/category']);
})
</script>
        <script>
        if ('' !== '') {
            require(['common/md5'], function (md5) {
                var merchantSiteId = md5('');
                clearBaiduTJ('', merchantSiteId);
            });
        }
        </script>
        <script>
            window.alogObjectConfig = {
                product: '682',
                page: 'MALL-list',
                speed: {
                    sample: '1'
                },
                monkey: {
                    sample: '1'
                },
                exception: {
                    sample: '1'
                },
                feature: {
                    sample: '1'
                }
            };
            void function(a,b,c,d,e,f){function g(b){a.attachEvent?a.attachEvent("onload",b,!1):a.addEventListener&&a.addEventListener("load",b)}function h(a,c,d){d=d||15;var e=new Date;e.setTime((new Date).getTime()+1e3*d),b.cookie=a+"="+escape(c)+";path=/;expires="+e.toGMTString()}function i(a){var c=b.cookie.match(new RegExp("(^| )"+a+"=([^;]*)(;|$)"));return null!=c?unescape(c[2]):null}function j(){var a=i("PMS_JT");if(a){h("PMS_JT","",-1);try{a=a.match(/{["']s["']:(\d+),["']r["']:["']([\s\S]+)["']}/),a=a&&a[1]&&a[2]?{s:parseInt(a[1]),r:a[2]}:{}}catch(c){a={}}a.r&&b.referrer.replace(/#.*/,"")!=a.r||alog("speed.set","wt",a.s)}}if(a.alogObjectConfig){var k=a.alogObjectConfig.sample,l=a.alogObjectConfig.rand;if("https:"===a.location.protocol){if(d="https://gss2.bdstatic.com/70cFsjip0QIZ8tyhnq"+d,!k||!l)return}else d="http://img.baidu.com"+d;k&&l&&l>k||(g(function(){alog("speed.set","lt",+new Date),e=b.createElement(c),e.async=!0,e.src=d+"?v="+~(new Date/864e5),f=b.getElementsByTagName(c)[0],f.parentNode.insertBefore(e,f)}),j())}}(window,document,"script","/hunter/alog/dp.min.js");
        </script>
        <script>
            alog('speed.set', 'drt', +new Date);
        </script>
    </body>
</html>
