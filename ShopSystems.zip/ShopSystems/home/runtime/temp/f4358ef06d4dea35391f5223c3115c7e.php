<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:60:"D:\phpstudy\WWW\ShopSystems\home\index\view\index\index.html";i:1571213568;}*/ ?>
﻿<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
        <meta name="baidu-site-verification" content="ZEXvy8Xkma" />
        <link rel="dns-prefetch" href="//mallcmscdn.baidu.com">
        <link rel="dns-prefetch" href="//mallcdn.baidu.com">
        <link rel="dns-prefetch" href="//hm.baidu.com">
        <link rel="dns-prefetch" href="//bcscdn.baidu.com">
        <link rel="dns-prefetch" href="//bj.bcebos.com">

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>百度MALL-全场正品，只为你臻选</title>
        <script>
            void function(g,f,j,c,h,d,b){g.alogObjectName=h,g[h]=g[h]||function(){(g[h].q=g[h].q||[]).push(arguments)},g[h].l=g[h].l||+new Date,d=f.createElement(j),d.async=!0,d.src=c,b=f.getElementsByTagName(j)[0],b.parentNode.insertBefore(d,b)}(window,document,"script","http://img.baidu.com/hunter/alog/alog.min.js","alog");void function(){function c(){return;}window.PDC={mark:function(a,b){alog("speed.set",a,b||+new Date);alog.fire&&alog.fire("mark")},init:function(a){alog("speed.set","options",a)},view_start:c,tti:c,page_ready:c}}();void function(n){var o=!1;n.onerror=function(n,e,t,c){var i=!0;return!e&&/^script error/i.test(n)&&(o?i=!1:o=!0),i&&alog("exception.send","exception",{msg:n,js:e,ln:t,col:c}),!1},alog("exception.on","catch",function(n){alog("exception.send","exception",{msg:n.msg,js:n.path,ln:n.ln,method:n.method,flag:"catch"})})}(window);
        </script>
<meta name="description" content="百度MALL是百度旗下定位中高端的品质电商，定向邀请1000家国内外中高端知名品牌入驻，且只和品牌官方直接合作，确保100%正品行货。目标顾客是25-40岁，对品牌或高品质商品有追求的小资白领和中产家庭。">
<meta name="keywords" content="百度MALL,品质电商,网上购物,网上商城">

        <link rel="shortcut icon" href="http://mallcdn.baidu.com/static/2016033051016/favicon.ico" >
        <script src="/static/index/js/core.js"></script>

        <script>
            require.config({
        'waitSeconds': 30,
        'baseUrl': 'http://mallcdn.baidu.com/static/2016033051016/js',
        'packages': [
            {
                'name': 'echarts',
                'location': '../dep/echarts/2.2.7/src',
                'main': 'echarts'
            },
            {
                'name': 'zrender',
                'location': '../dep/zrender/2.1.1/src',
                'main': 'zrender'
            }
        ]
    });
        </script>

<link rel="stylesheet" href="/static/index/css/style.css">

        <script>
        var cr = Math.floor(Math.random() * 99999);
        var activityId = '';
        var pageId = '1' ? '1' : 0;
        var rtTag = $.stringifyJSON({
    "ecom_page": {
        "page_type": "home"
    }
}
);

        // if (location.href.indexOf('mall.baidu.com') !== -1) {
            var _hmt = _hmt || [];
            var siteId = 'd64af1f3b8e241d56f0536501d4bfdd6';
            _hmt.push(['_setAccount', siteId]);
            _hmt.push(['_setAutoPageview', false]);

            if (rtTag) {
                _hmt.push(['_trackRTEvent', {
                    data: $.parseJSON(rtTag)
                }]);
            }

            trackPageViewTJ(siteId, '1', '');
            if ('' !== '') {
                require(['common/md5'], function (md5) {
                    var merchantSiteId = md5('');
                    _hmt.push(['_setAccount', merchantSiteId]);
                    _hmt.push(['_setAutoPageview', true]);
                    deployBaiduTJ(merchantSiteId);
                });
            // }
        }

        </script>
    </head>
    <script>
        alog('speed.set', 'ht', +new Date);
    </script>
    <body>
        <script>
            var GLOBAL_CONF = {"debug":false,"passport":{"host":"passport.baidu.com","tpl":"bdmall"},"site":{"siteId":7202944,"ucId":10914574}};
        </script>

<div class="home-container">

<div id="common-header" class="normal-header0">
    <div class="mini-header-search">
        <div class="container">
            <div class="user-info">
                <a href="/" target="_self" data-position-id="1000002">欢迎光临百度MALL</a><span class="separate">|</span>
                <span class="common-login-info">
                <a href="javascript:;" class="J_loginBtn" data-position-id="1000007">请登录</a><span class="separate">|</span>
                <a href="javascript:;" class="J_regBtn" data-position-id="1000008">免费注册</a><span class="separate">|</span>
                </span>
                <a href="/home" target="_blank" data-position-id="1000005">个人中心</a><span class="separate">|</span>
                <a href="/home/order/list" target="_blank" data-position-id="1000043">我的订单</a><span class="separate">|</span>
                <a href="/cart/list" target="_blank" data-position-id="1000006"><i class="bag-icon f-icon"></i>购物袋（<span class="num">0</span>）</a>
            </div>
        </div>
    </div>
    <div id="header">

        <a class="logo" href="/" data-position-id="1000001">
            <img src="/static/index/img/mall_logo.png">
        </a>
<div class="search-box">
    <input type="text" class="search-text" placeholder="搜索你想要的" value="">
    <button class="search-btn">搜索</button>
    <ul class="search-suggest">
    </ul>
</div>

<dl class="widget-service-guarantee">
    <dd>
        <i class="icon-guarantee22"></i>
        <p>正品保障</p>
    </dd>
    <dd>
        <i class="icon-certified"></i>
        <p>品牌验真</p>
    </dd>
    <dd>
        <i class="icon-compensation"></i>
        <p>假一赔五</p>
    </dd>
</dl>
    </div>
    <div class="nav-container">
        <div id="nav">
            <ul class="main-menu">
                <li class="main-menu-item all-category with-sub-menu">
                    <a href="javascript:"><i class="ui-icon-category icon-category"></i>全部商品分类</a>
                    <div class="sub-menu-container">
                        <ul class="">

                        <?php foreach($type as $data): ?>
                            <li class="sub-menu-item">
                                <h3><?php echo $data['name']; ?></h3>
                                <div class="second-menu-wapper">
                                    <?php foreach($data['child'] as $data2): ?>
                                    <a href="/category?catidList=1399" target="_blank" data-position-id="1000012"><?php echo $data2['name']; ?></a>

                                    <?php endforeach; ?>
                                   
                                </div>
                                <div class="third-menu-container">
                                  <?php foreach($data['child'] as $data2): ?>
                                    <ul>
                                        <li>
                                       

                                            <h3 class="second-title"><a href="/index.php/index/index/lists?id=<?php echo $data2['id']; ?>" target="_blank" data-position-id="1000012"><?php echo $data2['name']; ?></a></h3>


                                            <div class="sub-item">
                                                <?php foreach($data2['child2'] as $data3): ?>
                                                    <a href="/index.php/index/index/lists?id=<?php echo $data3['id']; ?>" target="_blank" data-position-id="1000012"><?php echo $data3['name']; ?></a>
                                                <?php endforeach; ?>
                                              
                                            </div>

                                        </li>
                                       

                                       
                                    </ul>
                                     <?php endforeach; ?>
                                </div>
                            </li>
                            <?php endforeach; ?>
                              
                        </ul>
                            
                    </div>

                </li>
                <li class="main-menu-item"><a href="/" class="active" data-position-id="1000010">首页</a></li>
<!--                 <li class="main-menu-item"><a href="/" class="">臻选</a></li> -->
<!--                 <li class="main-menu-item"><a href="/flpurchase" class="" target="_blank">闪购</a></li> -->
                <li class="main-menu-item"><a href="/brandStreet" class="" data-position-id="1000011">品牌街</a></li>
            </ul>

        </div>
    </div>
</div>

<script>

    $(document).ready(function(){
        require(['widget/header'], function (cart) {
            cart.init();
        });
    });

</script>
    <div class="currentTime" data-time="1460904652379"></div>

    <div class="slide-banner-container">
        <div class="row show-grid slide-banner clearfix">
            <div class="col-lg-2">
            </div>

            <div class="col-lg-8 slider-controller">
                <i class="swiper-button-prev icon-arrow-left" ></i>
                <i class="swiper-button-next icon-arrow-right"></i>
                <div class="swiper-pagination swiper-pagination-white">
                        <span class="swiper-pagination-switch"></span>
                        <span class="swiper-pagination-switch"></span>
                        <span class="swiper-pagination-switch"></span>
                        <span class="swiper-pagination-switch"></span>
                </div>
            </div>

            <div class="col-lg-2 banner-small-img">

                <div class="banner-recomment" data-position-id="1000014">
                    <img src="/static/index/img/3de97f5becb06d1e2cf85673c352256c.png@q_90,f_png">
                    <dl class="content">
                        <dd>
                            <a class="" href="http://mall.baidu.com/promote?pageCode=RightFirst" target="_blank" alt="爆品热卖 限时抢" title="爆品热卖 限时抢">
                                爆品热卖 限时抢
                            </a>
                        </dd>
                        <dd>
                            <a class="" href="http://mall.baidu.com/shop?shopId=396" target="_blank" alt="欧莱雅新春钜惠 旅行装特卖" title="欧莱雅新春钜惠 旅行装特卖">
                                欧莱雅新春钜惠 旅行装特卖
                            </a>
                        </dd>
                        <dd>
                            <a class="" href="http://mall.baidu.com/shop?shopId=750" target="_blank" alt="汇源果汁低至19.9包邮特惠" title="汇源果汁低至19.9包邮特惠">
                                汇源果汁低至19.9包邮特惠
                            </a>
                        </dd>
                        <dd>
                            <a class="" href="http://mall.baidu.com/shop?shopId=219" target="_blank" alt="惠普星战系列游戏本8折优惠" title="惠普星战系列游戏本8折优惠">
                                惠普星战系列游戏本8折优惠
                            </a>
                        </dd>
                        <dd>
                            <a class="" href="http://mall.baidu.com/shop?shopId=344&tr=cp.32_pr.65032" target="_blank" alt="才子满1件送袜子2件送领带" title="才子满1件送袜子2件送领带">
                                才子满1件送袜子2件送领带
                            </a>
                        </dd>

                    </dl>
                </div>
                <a class="banner-recomment" href="http://mall.baidu.com/activity/latest" target="_blank">
                    <img src="/static/index/img/2730d9b8850f6d45f46a4b4d4df96259.jpg@q_90,f_webp">
                </a>

            </div>
        </div>

        <div class="main-slider">
                <div class="slider-item-container" style="background-color: #f6dbee">
                        <div class="slider-img-container" data-color="#f6dbee">
                                <a href="http://mall.baidu.com/shop?shopId=563" target="_blank"  data-position-id="1000013">
                                        <img src="/static/index/img/88bcf08d532b3fdd92f95305f2b04e19.jpg@q_90,f_webp">
                                </a>
                        </div>
                </div>

                <div class="slider-item-container" style="background-color: #e8fbfa">
                        <div class="slider-img-container" data-color="#e8fbfa">
                                <a href="http://mall.baidu.com/promote?pageCode=camel" target="_blank"  data-position-id="1000013">
                                        <img src="/static/index/img/e20d646b43ac8c8a9170af3cb67eda29.jpg@q_90,f_webp">
                                </a>
                        </div>
                </div>

                <div class="slider-item-container" style="background-color: #bf90b4">
                        <div class="slider-img-container" data-color="#bf90b4">
                                <a href="http://mall.baidu.com/shop?shopId=740" target="_blank"  data-position-id="1000013">
                                        <img src="/static/index/img/8402f3bb8af88204c7d8ed6eaef749d5.jpg@q_90,f_webp">
                                </a>
                        </div>
                </div>

                <div class="slider-item-container" style="background-color: #000000">
                        <div class="slider-img-container" data-color="#000000">
                                <a href="http://mall.baidu.com/shop?shopId=55&amp;tr=cp.32_pr.71157" target="_blank"  data-position-id="1000013">
                                        <img src="/static/index/img/efcafd25439d88fce22360e572a16603.jpg@q_90,f_webp">
                                </a>
                        </div>
                </div>

        </div>

    </div>
    <script>
        void function(e,t){for(var n=t.getElementsByTagName("img"),a=+new Date,i=[],o=function(){this.removeEventListener&&this.removeEventListener("load",o,!1),i.push({img:this,time:+new Date})},s=0;s<n.length;s++)!function(){var e=n[s];e.addEventListener?!e.complete&&e.addEventListener("load",o,!1):e.attachEvent&&e.attachEvent("onreadystatechange",function(){"complete"==e.readyState&&o.call(e,o)})}();alog("speed.set",{fsItems:i,fs:a})}(window,document);
    </script>

    <!--<div class="main-container">-->

        <!--<div id="major" class="today-major-suit module-container">-->
            <!--<div class="module-title">-->
                <!--<div class="row show-grid clearfix">-->
                    <!--<div class="col-lg-2 title">-->
                        <!--今日最大牌-->
                    <!--</div>-->
                    <!--<div class="col-lg-8 category">-->
                        <!--<span data-type="major" class="swiper-pagination-switch swiper-active-switch">大牌</span>-->
                        <!--<span data-type="hot" class="swiper-pagination-switch">人气</span>-->
                        <!--<span data-type="preference" class="swiper-pagination-switch">优选</span>-->
                    <!--</div>-->
                    <!--<div class="more">-->
                        <!--<a href="/brandStreet" target="_blank">更多</a><i class="icon-arrow-right2"></i>-->
                    <!--</div>-->
                <!--</div>-->
            <!--</div>-->

            <!--<div class="row show-grid content clearfix">-->

                <!--<div class="col-lg-2 left-img">-->
                    <!--<a href="http://mall.baidu.com/search?q=%E9%A3%9E%E4%BA%9A%E8%BE%BE&amp;tr=cp.1_pr.37586" target="_blank"><img src="/static/index/img/92a625eb551bde8f59ba7d527ed7926c.jpg@q_90,f_webp"></a>-->
                <!--</div>-->

                <!--<div class="col-lg-8 brand-slide">-->
                    <!--<div class="brand-major brand-slide-item">-->
<!--<div class="banner">-->
    <!--<div class="swiper-container">-->

<!--<div class="swiper-wrapper">-->

        <!--<div class="swiper-slide">-->
                <!--<a href="http://mall.baidu.com/shop?shopId=32" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/3ffa0c6e4c234231370b8af0180af6ac.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=349" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/c709b03952d51994e89e3c7ecfbfa6d9.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=100" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/0d0c44632367fcb9fc8835e43bf8fe19.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=388" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/126094f08192660a4a070f55ca96f7ec.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=374" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/d7ca1aad7b091b78ea2689dcde085bc1.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=177" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/df4b4b16bf0706cc818f5865b605f44f.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=165" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/52bbbb3129221929a7d6edb4e6d08cd5.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=249" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/53caa1d8f442744f4acd97bcc18b45a3.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=253" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/cdf20eea9339571553c8138fb4f6a1fa.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=327" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/09f3e3887620f0b6f3d70c2117c00b2c.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=347" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/318c27bb7e5a47efff6b8b8209de34d2.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=147" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/d089c56d23ef0efbfd2866285fbb1abf.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=31" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/d03a924f602abd5b45ad7c4e5fe01904.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=229" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/889fb9f4a00dda3a07549b981bdacef5.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=383&amp;tr=cp.31_pr.66343" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/eb86a7eab1c47f189e1245f7f82d6df9.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=307" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/2210b51093b888d6d2386aee818dd9e0.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=25" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/934c017bd443262e08e244db55019096.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=394" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/994e90f95933e0f3ad296de7f58b19ab.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=162" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/f48c8de45885751a692b9d6d4ec374da.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=204" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/27bca1a370258a05745b4483a3d8d8f2.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
        <!--</div>-->
<!--</div>-->


    <!--</div>-->

<!--</div>-->
                    <!--</div>-->
                    <!--<div class="brand-hot brand-slide-item">-->
<!--<div class="banner">-->
    <!--<div class="swiper-container">-->

<!--<div class="swiper-wrapper">-->

        <!--<div class="swiper-slide">-->
                <!--<a href="http://mall.baidu.com/shop?shopId=170&amp;tr=cp.31_pr.15208" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/f16c10fb80409d693586062855317215.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=306" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/5b25793d572d67479919073a38c6b25b.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=219" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/584fc63f3d007889d9a03836ddcf7b8d.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=212" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/8a71582925acf0d5b290806a95a0d951.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=48" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/9c43bfa84245520ef32ffc4eb754cc47.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=30" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/bbf1a1e99d0242f697034a368e9d2f01.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=133&amp;tr=cp.30_pr.18099" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/d68d80d74b4786182f79fa7097ce46ab.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=260" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/7a70ee4dc77871cf5ffac4b838db4bb2.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=152" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/c525f3f7da003f71036182232dfe99c4.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=175" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/84a677fcf21efbcf7dd96bebde9d8bd2.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=228" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/bd26afd6814af5a44f39507c67fc9138.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=266" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/56907a8ac94c90a179a9f71760336f29.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=248" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/bf28a28d87779276ee80da2a9a0243cc.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=215" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/c4850c69b0487b07aab2e4224335a0d7.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=312" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/41708e2f79de99ca6dcac701923c88fc.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=164" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/ea61cbf76bc5c8591d86659f431e3848.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=57" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/a94bb7d56a9094b56aaaa0a4cc92ec23.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=109" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/a6a0a60c9a3d63fe09864057d3154c2f.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=182" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/aa8c5e553d9977851da73f776e901802.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=222" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/15903b79e098020854960f302b880646.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
        <!--</div>-->
<!--</div>-->


    <!--</div>-->

<!--</div>-->
                    <!--</div>-->
                    <!--<div class="brand-preference brand-slide-item">-->
<!--<div class="banner">-->
    <!--<div class="swiper-container">-->

<!--<div class="swiper-wrapper">-->

        <!--<div class="swiper-slide">-->
                <!--<a href="http://mall.baidu.com/shop?shopId=75" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/c39ce200c3121957d97ef925a4a4a5fa.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=163" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/4914c82b7381fe9af6d3c054bd7685d1.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=169" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/18009f11d4d07b4acc97264f90e1452e.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=382" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/73d0188764b6c181fa3bdbc21de98dd5.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=60" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/f98f54232effe0d0fe1c8131b4c59147.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=294" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/aba5c54d1671f5e1ad1ab56a7e3c3787.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=251" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/5d9294c8dcb1ddf4319926c502dab7a1.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=213" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/8087ee62bc3a40f416417d0c369ce337.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=42" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/1e4938d3ab9832cff19bde324e8d5331.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=131" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/360ca3b0953f3fcc49b11b35321c5a5a.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=284" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/fb63ed2ec1768255ebbfaf9f80be5e79.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=95" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/aaa089a410d84d97033b7fd52289a09d.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=154" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/fd54bc031659bd5a26c689c15af8da6f.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=98" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/06d31072529462fc003f6494ab0ebf38.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=209" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/cd74494fee113f5b4019414c02655c29.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=214" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/5fde3556fae172398dd6e3596603f58b.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=66" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/d789e8bb933ad0656b28f18cb400f382.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=155" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/e3655644bc27f57c5ed41a86fd025410.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=159" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/f0544abe9916546e0c0a387af08584b4.png@q_90,f_png" class="swiper-lazy" alt="">-->
                <!--</a>-->
                <!--<a href="http://mall.baidu.com/shop?shopId=379" target="_blank">-->
                    <!--<img data-origin="" src="/static/index/img/d18b40ff35fb76bddb6d1016d75361d7.jpg@q_90,f_webp" class="swiper-lazy" alt="">-->
                <!--</a>-->
        <!--</div>-->
<!--</div>-->


    <!--</div>-->

<!--</div>-->
                    <!--</div>-->
                <!--</div>-->

                <!--<div class="col-lg-2 right-img">-->
<!--<div class="banner">-->
    <!--<div class="swiper-container">-->


<!--<div class="swiper-wrapper">-->

    <!--<div class="swiper-slide" data-color="">-->
        <!--<a href="http://mall.baidu.com/product?itemId=14037" target="_blank">-->
            <!--<img data-origin="" src="/static/index/img/fff8f5742a869dd6ddb5446b43a0d4f0.png@q_90,f_png" class="swiper-lazy" alt="">-->
        <!--</a>-->
    <!--</div>-->
<!--</div>-->


    <!--</div>-->

<!--</div>-->
                <!--</div>-->


            <!--</div>-->
        <!--</div>-->

        <!--<div id="immediate" class="today-immediate-buy module-container">-->
            <!--<div    class="module-title " >-->
                <!--<div class="row show-grid clearfix">-->
                    <!--<div class="col-lg-2 title">-->
                        <!--每日精选<sub>SELECTED</sub>-->
                    <!--</div>-->
<!--&lt;!&ndash;                     <div class="more">-->
                        <!--<a href="/flpurchase" target="_blank">更多</a><i class="icon-arrow-right2"></i>-->
                    <!--</div> &ndash;&gt;-->
                <!--</div>-->
            <!--</div>-->
            <!--<div class="row show-grid clearfix promote-product">-->

                <!--<div class="col-lg-3 product-item first-row-product-item"    data-id="" style="background-color: #fcf5f1">-->

                    <!--<a href="/product?itemId=107212&skuId=314445" target="_blank" data-position-id="1000020">-->
                        <!--<div class="desc">-->
                            <!--<div class="lables">-->
                            <!--</div>-->

                            <!--<div class="img-container">-->
                                <!--<img class="logo-img" src="/static/index/img/1e79e2c40532bfc042c977cfe9c3e36d.png@q_90,f_png">-->
                                <!--<img class="product-img" src="/static/index/img/1d59e7bc233720b60d5ee2790872e640.png@q_90,f_png" alt="CK EDT中性香水100ml">-->
                            <!--</div>-->

                            <!--<div class="content-container">-->
                                <!--<p class="price">-->
                                <!--￥179.00-->
                                <!--</p>-->
                                <!--<p class="title">-->
                                    <!--CK EDT中性香水100ml-->
                                <!--</p>-->
                                <!--<div class="remaining-time">-->
                                    <!--<i class="icon-clock"></i><span class="ui-icon-clock" data-status="2" data-endtime="1461038400000">未开始</span>-->
                                <!--</div>-->
                            <!--</div>-->

                        <!--</div>-->

                    <!--</a>-->
                <!--</div>-->
                <!--<div class="col-lg-3 product-item first-row-product-item"    data-id="" style="background-color: #FFF0F0">-->
                    <!--<a href="/product?itemId=111246&skuId=346886" target="_blank" data-position-id="1000021">-->
                        <!--<div class="desc">-->
                            <!--<div class="lables">-->
                            <!--</div>-->

                            <!--<div class="img-container">-->
                                <!--<img class="logo-img" src="/static/index/img/cd5f782f4193549cac85433e3e2da8c7.png@q_90,f_png">-->
                                <!--<img class="product-img" src="/static/index/img/f412bae82fccf93b498a8ce2fdc01282.png@q_90,f_png" alt="特价 飞利浦电吹风">-->
                            <!--</div>-->

                            <!--<div class="content-container">-->
                                <!--<p class="price">-->
                                <!--￥129.00-->
                                <!--</p>-->
                                <!--<p class="title">-->
                                    <!--特价 飞利浦电吹风-->
                                <!--</p>-->
                                <!--<div class="remaining-time">-->
                                    <!--<i class="icon-clock"></i><span class="ui-icon-clock" data-status="2" data-endtime="1460948400000">未开始</span>-->
                                <!--</div>-->
                            <!--</div>-->

                        <!--</div>-->

                    <!--</a>-->
                <!--</div>-->
                <!--<div class="col-lg-3 product-item first-row-product-item"    data-id="" style="background-color: #f1f7ef">-->
                    <!--<a href="/product?itemId=125094&skuId=446950" target="_blank" data-position-id="1000022">-->
                        <!--<div class="desc">-->
                            <!--<div class="lables">-->
                            <!--</div>-->

                            <!--<div class="img-container">-->
                                <!--<img class="logo-img" src="/static/index/img/898d16b67b87c9bb3aad85fcf5c56b2c.png@q_90,f_png">-->
                                <!--<img class="product-img" src="/static/index/img/b6624d074e4937465e241596559e58f3.png@q_90,f_png" alt="特价 好时香浓牛奶巧克力50g铁盒装">-->
                            <!--</div>-->

                            <!--<div class="content-container">-->
                                <!--<p class="price">-->
                                <!--￥19.90-->
                                <!--</p>-->
                                <!--<p class="title">-->
                                    <!--特价 好时香浓牛奶巧克力50g铁盒装-->
                                <!--</p>-->
                                <!--<div class="remaining-time">-->
                                    <!--<i class="icon-clock"></i><span class="ui-icon-clock" data-status="2" data-endtime="1460948400000">未开始</span>-->
                                <!--</div>-->
                            <!--</div>-->

                        <!--</div>-->

                    <!--</a>-->
                <!--</div>-->
                <!--<div class="col-lg-3 product-item first-row-product-item"    data-id="" style="background-color: #fef2ee">-->
                    <!--<a href="/product?itemId=111118&skuId=346116" target="_blank" data-position-id="1000023">-->
                        <!--<div class="desc">-->
                            <!--<div class="lables">-->
                            <!--</div>-->

                            <!--<div class="img-container">-->
                                <!--<img class="logo-img" src="/static/index/img/4b4f1bc8d3e84e93888a16be05f4dae1.png@q_90,f_png">-->
                                <!--<img class="product-img" src="/static/index/img/55470403f5e6c81023b197a0cdb058b4.png@q_90,f_png" alt="贝德玛 多效洁肤卸妆水500ml">-->
                            <!--</div>-->

                            <!--<div class="content-container">-->
                                <!--<p class="price">-->
                                <!--￥178.00-->
                                <!--</p>-->
                                <!--<p class="title">-->
                                    <!--贝德玛 多效洁肤卸妆水500ml-->
                                <!--</p>-->
                                <!--<div class="remaining-time">-->
                                    <!--<i class="icon-clock"></i><span class="ui-icon-clock" data-status="2" data-endtime="1460991600000">未开始</span>-->
                                <!--</div>-->
                            <!--</div>-->

                        <!--</div>-->

                    <!--</a>-->
                <!--</div>-->
            <!--</div>-->

            <!--<div class="row show-grid clearfix promote-brand">-->
                <!--<div class="col-lg-4 second-row-product-item">-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=284" target="_blank" data-position-id="1000024">-->
                        <!--<div>-->
                            <!--<img class="cover-img" src="/static/index/img/939ede4b87fa6077fd9ba1765eb47a8c.jpg@q_90,f_webp" alt="踏青好选择 折起">-->
                            <!--<div class="context">-->
                                <!--<div class="right-part">-->
                                    <!--<p class="discount">踏青好选择</p>-->
                                    <!--<p class="desc">三月钜惠 全场特价</p>-->
                                <!--</div>-->
                                <!--<p    class="name"><img src="/static/index/img/506039971c210ddfe87190bc334d60fc.png@q_90,f_png"></p>-->
                            <!--</div>-->
<!--&lt;!&ndash;                             <p class="remaining-time">-->
                                <!--距离活动结束&nbsp;-->
                                <!--<span class="ui-icon-clock" data-endtime=""></span>-->
                            <!--</p> &ndash;&gt;-->
                        <!--</div>-->
                    <!--</a>-->
                <!--</div>-->
                <!--<div class="col-lg-4 second-row-product-item">-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=28" target="_blank" data-position-id="1000025">-->
                        <!--<div>-->
                            <!--<img class="cover-img" src="/static/index/img/b5b05adcb10f0d529a812d3a77bcf701.jpg@q_90,f_webp" alt="瑞士进口 源自1845 折起">-->
                            <!--<div class="context">-->
                                <!--<div class="right-part">-->
                                    <!--<p class="discount">瑞士进口 源自1845</p>-->
                                    <!--<p class="desc">瑞士莲 全场四折起</p>-->
                                <!--</div>-->
                                <!--<p    class="name"><img src="/static/index/img/016d9e3eb2154d6db9aded269ed2e249.png@q_90,f_png"></p>-->
                            <!--</div>-->
<!--&lt;!&ndash;                             <p class="remaining-time">-->
                                <!--距离活动结束&nbsp;-->
                                <!--<span class="ui-icon-clock" data-endtime=""></span>-->
                            <!--</p> &ndash;&gt;-->
                        <!--</div>-->
                    <!--</a>-->
                <!--</div>-->
                <!--<div class="col-lg-4 second-row-product-item">-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=735&amp;tr=cp.5_pr.48120_po.3000022" target="_blank" data-position-id="1000026">-->
                        <!--<div>-->
                            <!--<img class="cover-img" src="/static/index/img/b00cad3bb19605438724c4ce73871eab.png@q_90,f_png" alt="白出晶采 活出晶采 折起">-->
                            <!--<div class="context">-->
                                <!--<div class="right-part">-->
                                    <!--<p class="discount">白出晶采 活出晶采</p>-->
                                    <!--<p class="desc">呵护春季肌肤 热销套装五折起</p>-->
                                <!--</div>-->
                                <!--<p    class="name"><img src="/static/index/img/b784f29b26bad1bd2ddc72b6ae330776.png@q_90,f_png"></p>-->
                            <!--</div>-->
<!--&lt;!&ndash;                             <p class="remaining-time">-->
                                <!--距离活动结束&nbsp;-->
                                <!--<span class="ui-icon-clock" data-endtime=""></span>-->
                            <!--</p> &ndash;&gt;-->
                        <!--</div>-->
                    <!--</a>-->
                <!--</div>-->

            <!--</div>-->
        <!--</div>-->

<!--<div id="clothing" class=" category-module module-container">-->
    <!--<div class="module-title">-->
        <!--<div class="row show-grid clearfix">-->
            <!--<div class="col-lg-4 title">-->
                <!--服装服饰<sub>CLOTHING</sub>-->
            <!--</div>-->
            <!--<div class="more">-->
                <!--<a data-id="" href="http://mall.baidu.com/promote?pageCode=fushiceshi"    target="_blank" data-position-id="1000028">大牌精选</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1400"    target="_blank" data-position-id="1000029">女士羽绒服</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1449"    target="_blank" data-position-id="1000030">男士羽绒服</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1440"    target="_blank" data-position-id="1000031">男士夹克</a>-->
<!--&lt;!&ndash;                 <a href="http://baidu.com">更多服装服饰</a>> &ndash;&gt;-->
            <!--</div>-->
        <!--</div>-->
    <!--</div>-->

    <!--<div class="row show-grid content">-->
        <!--<div class="col-lg-6 left-img" style="background-color: #22AAFF">-->
            <!--<img class="background-img" src="/static/index/img/9f3c46ba5201ed8f7efe2ba32aaf83c4.jpg@q_90,f_webp">-->
            <!--<a class="bg-link" href="http://mall.baidu.com/shop?shopId=254" target="_blank" data-position-id="1000032"></a>-->
            <!--<div class="category">-->


                <!--<h3>精选分类</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=1399" title="时尚女装" alt="时尚女装"  target="_blank" data-position-id="1000031">时尚女装</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/promote?pageCode=fushiceshi" title="大牌精选" alt="大牌精选"  target="_blank" data-position-id="1000031">大牌精选</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1433" title="品牌男装" alt="品牌男装"  target="_blank" data-position-id="1000031">品牌男装</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1468" title="精品内衣" alt="精品内衣"  target="_blank" data-position-id="1000031">精品内衣</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1416" title="女针织衫" alt="女针织衫"  target="_blank" data-position-id="1000031">女针织衫</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=1432" title="女呢大衣" alt="女呢大衣"  target="_blank" data-position-id="1000031">女呢大衣</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1436" title="男士衬衫" alt="男士衬衫"  target="_blank" data-position-id="1000031">男士衬衫</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1470" title="文胸" alt="文胸"  target="_blank" data-position-id="1000031">文胸</a>-->

                <!--</div>-->

                <!--<h3>时尚品牌</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=152" title="红袖" alt="红袖" target="_blank" data-position-id="1000031">红袖</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=112" title="伊芙丽" alt="伊芙丽" target="_blank" data-position-id="1000031">伊芙丽</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=79" title="伊芙心悦" alt="伊芙心悦" target="_blank" data-position-id="1000031">伊芙心悦</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=33" title="曼妮芬" alt="曼妮芬" target="_blank" data-position-id="1000031">曼妮芬</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=181" title="太子龙" alt="太子龙" target="_blank" data-position-id="1000031">太子龙</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=661" title="菲妮迪" alt="菲妮迪" target="_blank" data-position-id="1000031">菲妮迪</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=532&amp;tr=cp.31_pr.37054" title="JEEP" alt="JEEP" target="_blank" data-position-id="1000031">JEEP</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=89" title="Lily" alt="Lily" target="_blank" data-position-id="1000031">Lily</a>-->

                <!--</div>-->

                <!--<div class="left-bottom-img">-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=142&amp;tr=cp.5_pr.36670" target="_blank">-->
                        <!--<img src="/static/index/img/3fba4d132e3de9b53605da76c36ffeba.png@q_90,f_png">-->
                    <!--</a>-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=260" target="_blank">-->
                        <!--<img src="/static/index/img/7f81beca122b31b70110e4c73e027db5.png@q_90,f_png">-->
                    <!--</a>-->
                <!--</div>-->
            <!--</div>-->
        <!--</div>-->

<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=108581&skuId=323809" class="content-container clearfix" target="_blank" data-position-id="1000033">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>ASOBIO修身毛织开衫</h3>-->
        <!--<p class="desc">多色可选 4.4折</p>-->
        <!--<p class="price">-->
            <!--¥169.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/e7ce2e2cfe0784bf2c59baa5ab2b27ae.jpg@q_90,f_webp" alt="ASOBIO修身毛织开衫 多色可选 4.4折">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=112278&skuId=352468" class="content-container clearfix" target="_blank" data-position-id="1000034">-->
<!--&lt;!&ndash;                 <div class="lables">-->
            <!--<span class="lable lable-type5">-->
                <!--库存紧张-->
                <!--<i class="icon-arrow-right2"></i>-->
            <!--</span>-->
        <!--</div>-->
 <!--&ndash;&gt;-->
        <!--<h3>ELLE女装露背连衣裙</h3>-->
        <!--<p class="desc">三色可选1.5折包邮</p>-->
        <!--<p class="price">-->
            <!--¥219.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/534f682896dd2fb50a45f344337f983e.jpg@q_90,f_webp" alt="ELLE女装露背连衣裙 三色可选1.5折包邮">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=14664&skuId=74445" class="content-container clearfix" target="_blank" data-position-id="1000035">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>才子男装修身衬衫</h3>-->
        <!--<p class="desc">才子男装专注男装33年</p>-->
        <!--<p class="price">-->
            <!--¥89.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/e8b95b8c114277aee2fa1dc7a38afec5.jpg@q_90,f_webp" alt="才子男装修身衬衫 才子男装专注男装33年">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=12482&skuId=59276" class="content-container clearfix" target="_blank" data-position-id="1000036">-->
<!--&lt;!&ndash;                 <div class="lables">-->
            <!--<span class="lable lable-type5">-->
                <!--库存紧张-->
                <!--<i class="icon-arrow-right2"></i>-->
            <!--</span>-->
        <!--</div>-->
 <!--&ndash;&gt;-->
        <!--<h3>轻薄短款羽绒服</h3>-->
        <!--<p class="desc">2.9折</p>-->
        <!--<p class="price">-->
            <!--¥399.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/65308a2098da7a7f302fd5dc357cb47c.jpg@q_90,f_webp" alt="轻薄短款羽绒服 2.9折">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=116750&skuId=388184" class="content-container clearfix" target="_blank" data-position-id="1000037">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>棉花共和国平角2条</h3>-->
        <!--<p class="desc">本命年猴年大吉</p>-->
        <!--<p class="price">-->
            <!--¥138.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/ef8eb20d479490d3d5290c8f4034d977.jpg@q_90,f_webp" alt="棉花共和国平角2条 本命年猴年大吉">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=117112&skuId=391261" class="content-container clearfix" target="_blank" data-position-id="1000038">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>伊芙丽韩版V领外套</h3>-->
        <!--<p class="desc">优雅V领 舒适落肩</p>-->
        <!--<p class="price">-->
            <!--¥299.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/c6d2d986ba38c02dae756e2535428f97.jpg@q_90,f_webp" alt="伊芙丽韩版V领外套 优雅V领 舒适落肩">-->
        <!--<img class="brand-desc" src="/static/index/img/130e6d7cb2b155cd8893a8defae3fdcd.jpg@q_90,f_webp">-->
    <!--</a>-->

<!--</div>-->


    <!--</div>-->

    <!--<div class="row show-grid">-->
    <!--</div>-->
<!--</div>-->
<!--<div id="bags" class=" category-module module-container">-->
    <!--<div class="module-title">-->
        <!--<div class="row show-grid clearfix">-->
            <!--<div class="col-lg-4 title">-->
                <!--鞋包运动<sub>SHOES BAGS &amp; SPORTING GOODS</sub>-->
            <!--</div>-->
            <!--<div class="more">-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1494"    target="_blank" data-position-id="1000028">正装鞋</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=906&amp;tr=cp.1_pr.79322_po.1000012"    target="_blank" data-position-id="1000029">夹克风衣</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=968&amp;tr=cp.1_pr.79322_po.1000012"    target="_blank" data-position-id="1000030">皮肤衣</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1538"    target="_blank" data-position-id="1000031">男包</a>-->
<!--&lt;!&ndash;                 <a href="http://baidu.com">更多鞋包运动</a>> &ndash;&gt;-->
            <!--</div>-->
        <!--</div>-->
    <!--</div>-->

    <!--<div class="row show-grid content">-->
        <!--<div class="col-lg-6 left-img" style="background-color: #22AAFF">-->
            <!--<img class="background-img" src="/static/index/img/c125ae75f9c47b0e8b3cb645a2587d08.jpg@q_90,f_webp">-->
            <!--<a class="bg-link" href="http://mall.baidu.com/shop?shopId=382" target="_blank" data-position-id="1000032"></a>-->
            <!--<div class="category">-->


                <!--<h3>精选分类</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=1511" title="女鞋" alt="女鞋"  target="_blank" data-position-id="1000031">女鞋</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1493" title="男鞋" alt="男鞋"  target="_blank" data-position-id="1000031">男鞋</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=891&amp;tr=cp.1_pr.57638_po.1000012" title="篮球鞋" alt="篮球鞋"  target="_blank" data-position-id="1000031">篮球鞋</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=888&amp;tr=cp.1_pr.57638_po.1000012" title="跑步鞋" alt="跑步鞋"  target="_blank" data-position-id="1000031">跑步鞋</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=942&amp;tr=cp.1_pr.57638_po.1000012" title="冲锋衣裤" alt="冲锋衣裤"  target="_blank" data-position-id="1000031">冲锋衣裤</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1028&amp;tr=cp.1_pr.57638_po.1000012" title="骑行运动" alt="骑行运动"  target="_blank" data-position-id="1000031">骑行运动</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1542" title="电脑包" alt="电脑包"  target="_blank" data-position-id="1000031">电脑包</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=1535" title="拉杆箱" alt="拉杆箱"  target="_blank" data-position-id="1000031">拉杆箱</a>-->

                <!--</div>-->

                <!--<h3>时尚品牌</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=230" title="哈森" alt="哈森" target="_blank" data-position-id="1000031">哈森</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=380" title="哈瓦那" alt="哈瓦那" target="_blank" data-position-id="1000031">哈瓦那</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=227&amp;tr=cp.5_pr.38404_po.3000022" title="特步" alt="特步" target="_blank" data-position-id="1000031">特步</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=707&amp;tr=cp.32_pr.67644" title="达克沃" alt="达克沃" target="_blank" data-position-id="1000031">达克沃</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=182&amp;tr=cp.32_pr.89007" title="探路者" alt="探路者" target="_blank" data-position-id="1000031">探路者</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=753&amp;tr=cp.32_pr.99129" title="DAHON" alt="DAHON" target="_blank" data-position-id="1000031">DAHON</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=40" title="UTC" alt="UTC" target="_blank" data-position-id="1000031">UTC</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=814" title="袋鼠" alt="袋鼠" target="_blank" data-position-id="1000031">袋鼠</a>-->

                <!--</div>-->

                <!--<div class="left-bottom-img">-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=170" target="_blank">-->
                        <!--<img src="/static/index/img/1754ff5417cdba7ff945242aafb3ce78.jpg@q_90,f_webp">-->
                    <!--</a>-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=74&amp;tr=cp.32_pr.77787" target="_blank">-->
                        <!--<img src="/static/index/img/043a92d22f909fe8ad989b98945adc77.png@q_90,f_png">-->
                    <!--</a>-->
                <!--</div>-->
            <!--</div>-->
        <!--</div>-->

<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=13873&skuId=65313" class="content-container clearfix" target="_blank" data-position-id="1000033">-->
<!--&lt;!&ndash;                 <div class="lables">-->
            <!--<span class="lable lable-type5">-->
                <!--库存紧张-->
                <!--<i class="icon-arrow-right2"></i>-->
            <!--</span>-->
        <!--</div>-->
 <!--&ndash;&gt;-->
        <!--<h3>迷你唐卡  女鞋</h3>-->
        <!--<p class="desc">博特雷鸟牛皮平跟鞋</p>-->
        <!--<p class="price">-->
            <!--¥489.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/b1514db2da38640d45597e23aece580f.jpg@q_90,f_webp" alt="迷你唐卡  女鞋 博特雷鸟牛皮平跟鞋">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=93055&skuId=213970" class="content-container clearfix" target="_blank" data-position-id="1000034">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>鳄鱼恤 男鞋</h3>-->
        <!--<p class="desc">涂鸦透气帆布休闲鞋</p>-->
        <!--<p class="price">-->
            <!--¥168.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/d057683933c734b865f5e537eb022f7f.jpg@q_90,f_webp" alt="鳄鱼恤 男鞋 涂鸦透气帆布休闲鞋">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=93376&skuId=217859" class="content-container clearfix" target="_blank" data-position-id="1000035">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>匹克 舒适跑鞋</h3>-->
        <!--<p class="desc">超耐磨运动慢跑鞋</p>-->
        <!--<p class="price">-->
            <!--¥288.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/ac7339a1ed7cb4e82be2971fbcfef71a.png@q_90,f_png" alt="匹克 舒适跑鞋 超耐磨运动慢跑鞋">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=96051&skuId=236418" class="content-container clearfix" target="_blank" data-position-id="1000036">-->
<!--&lt;!&ndash;                 <div class="lables">-->
            <!--<span class="lable lable-type5">-->
                <!--库存紧张-->
                <!--<i class="icon-arrow-right2"></i>-->
            <!--</span>-->
        <!--</div>-->
 <!--&ndash;&gt;-->
        <!--<h3>美津浓 足球鞋</h3>-->
        <!--<p class="desc">男款碎丁 草地足球鞋</p>-->
        <!--<p class="price">-->
            <!--¥379.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/e80c8f06ac083e59ba8cbee78420a5ce.png@q_90,f_png" alt="美津浓 足球鞋 男款碎丁 草地足球鞋">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=19967&skuId=107938" class="content-container clearfix" target="_blank" data-position-id="1000037">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>牧高笛 户外情侣款</h3>-->
        <!--<p class="desc">防风保暖加厚抓绒衣外套</p>-->
        <!--<p class="price">-->
            <!--¥169.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/2a53b9f58583dd5af89ce2ca74f5c873.jpg@q_90,f_webp" alt="牧高笛 户外情侣款 防风保暖加厚抓绒衣外套">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=96668&skuId=239248" class="content-container clearfix" target="_blank" data-position-id="1000038">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>RIMOWA 拉杆箱</h3>-->
        <!--<p class="desc">铝镁合金复古登机箱</p>-->
        <!--<p class="price">-->
            <!--¥6382.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/77c7e5dec3c58fe6381fd505e52f9b29.jpg@q_90,f_webp" alt="RIMOWA 拉杆箱 铝镁合金复古登机箱">-->
        <!--<img class="brand-desc" src="/static/index/img/c7dde04e88c904673d89d34b9c5ddab8.jpg@q_90,f_webp">-->
    <!--</a>-->

<!--</div>-->


    <!--</div>-->

    <!--<div class="row show-grid">-->
    <!--</div>-->
<!--</div>-->

<!--<div id="beauty" class=" category-module module-container">-->
    <!--<div class="module-title">-->
        <!--<div class="row show-grid clearfix">-->
            <!--<div class="col-lg-4 title">-->
                <!--美妆珠宝<sub>BEAUTY</sub>-->
            <!--</div>-->
            <!--<div class="more">-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1126"    target="_blank" data-position-id="1000028">面霜乳液</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1134"    target="_blank" data-position-id="1000029">洁面卸妆</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1055"    target="_blank" data-position-id="1000030">男士手表</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1061"    target="_blank" data-position-id="1000031">黄金K金</a>-->
<!--&lt;!&ndash;                 <a href="http://baidu.com">更多美妆珠宝</a>> &ndash;&gt;-->
            <!--</div>-->
        <!--</div>-->
    <!--</div>-->

    <!--<div class="row show-grid content">-->
        <!--<div class="col-lg-6 left-img" style="background-color: #fffef3">-->
            <!--<img class="background-img" src="/static/index/img/c3993a56fdda32e72113f4269ded94eb.jpg@q_90,f_webp">-->
            <!--<a class="bg-link" href="http://mall.baidu.com/shop?shopId=57&amp;tr=cp.32_pr.42148" target="_blank" data-position-id="1000032"></a>-->
            <!--<div class="category">-->


                <!--<h3>精选分类</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1125" title="面部护肤" alt="面部护肤"  target="_blank" data-position-id="1000031">面部护肤</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1185" title="个人护理" alt="个人护理"  target="_blank" data-position-id="1000031">个人护理</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=1227" title="香水" alt="香水"  target="_blank" data-position-id="1000031">香水</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1142" title="彩妆" alt="彩妆"  target="_blank" data-position-id="1000031">彩妆</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1060" title="黄金珠宝" alt="黄金珠宝"  target="_blank" data-position-id="1000031">黄金珠宝</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1054" title="腕表" alt="腕表"  target="_blank" data-position-id="1000031">腕表</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1087" title="眼镜礼品" alt="眼镜礼品"  target="_blank" data-position-id="1000031">眼镜礼品</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1072" title="时尚饰品" alt="时尚饰品"  target="_blank" data-position-id="1000031">时尚饰品</a>-->

                <!--</div>-->

                <!--<h3>时尚品牌</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=253&amp;tr=cp.1_pr.16289" title="ipsa" alt="ipsa" target="_blank" data-position-id="1000031">ipsa</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=397&amp;tr=cp.30_pr.29779" title="美宝莲" alt="美宝莲" target="_blank" data-position-id="1000031">美宝莲</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=389&amp;tr=cp.30_pr.29779" title="施华蔻" alt="施华蔻" target="_blank" data-position-id="1000031">施华蔻</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=396" title="欧莱雅" alt="欧莱雅" target="_blank" data-position-id="1000031">欧莱雅</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=30" title="卡西欧" alt="卡西欧" target="_blank" data-position-id="1000031">卡西欧</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=57" title="西铁城" alt="西铁城" target="_blank" data-position-id="1000031">西铁城</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=378" title="潮宏基" alt="潮宏基" target="_blank" data-position-id="1000031">潮宏基</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=54" title="六福珠宝" alt="六福珠宝" target="_blank" data-position-id="1000031">六福珠宝</a>-->

                <!--</div>-->

                <!--<div class="left-bottom-img">-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=383" target="_blank">-->
                        <!--<img src="/static/index/img/4358d22bc1d610eedeed30f427657ff2.png@q_90,f_png">-->
                    <!--</a>-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=316&amp;tr=cp.31_pr.53686" target="_blank">-->
                        <!--<img src="/static/index/img/71f58e7cbd1e7cccb159a7c96cbbd5ff.png@q_90,f_png">-->
                    <!--</a>-->
                <!--</div>-->
            <!--</div>-->
        <!--</div>-->

<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=8657&skuId=39139" class="content-container clearfix" target="_blank" data-position-id="1000033">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>周大福考拉与Kitty</h3>-->
        <!--<p class="desc">经典Kitty系列吊坠</p>-->
        <!--<p class="price">-->
            <!--¥960.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/4c7687ac6f7e9014ad336a054b3cdbac.jpg@q_90,f_webp" alt="周大福考拉与Kitty 经典Kitty系列吊坠">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=108583&skuId=323821" class="content-container clearfix" target="_blank" data-position-id="1000034">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>女士雏菊香水</h3>-->
        <!--<p class="desc">清新花果香调50ml</p>-->
        <!--<p class="price">-->
            <!--¥349.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/ed931de669f137aa119d564da5a4ab10.jpg@q_90,f_webp" alt="女士雏菊香水 清新花果香调50ml">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=2359&skuId=23323" class="content-container clearfix" target="_blank" data-position-id="1000035">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>卡西欧户外男士手表</h3>-->
        <!--<p class="desc">航空系列防水石英表预售</p>-->
        <!--<p class="price">-->
            <!--¥1990.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/2ae8028d068354750a3e35039d152135.jpg@q_90,f_webp" alt="卡西欧户外男士手表 航空系列防水石英表预售">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=106759&skuId=311691" class="content-container clearfix" target="_blank" data-position-id="1000036">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>暴龙 男女蛤蟆镜</h3>-->
        <!--<p class="desc">时尚与舒适的完美平衡</p>-->
        <!--<p class="price">-->
            <!--¥528.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/e8dff2507875737bf068b41589124748.jpg@q_90,f_webp" alt="暴龙 男女蛤蟆镜 时尚与舒适的完美平衡">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=10541&skuId=49694" class="content-container clearfix" target="_blank" data-position-id="1000037">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>IPSA保湿礼盒套装</h3>-->
        <!--<p class="desc">匀净透彻舒缓</p>-->
        <!--<p class="price">-->
            <!--¥770.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/9e1ce7b691c6ee0fc8f9fa27160444ea.png@q_90,f_png" alt="IPSA保湿礼盒套装 匀净透彻舒缓">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=95826&skuId=235277" class="content-container clearfix" target="_blank" data-position-id="1000038">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>rebecca 长卷发</h3>-->
        <!--<p class="desc">女士中分假发 冰冰同款</p>-->
        <!--<p class="price">-->
            <!--¥3680.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/2adfa3c364e942371f4a719663ee236d.jpg@q_90,f_webp" alt="rebecca 长卷发 女士中分假发 冰冰同款">-->
        <!--<img class="brand-desc" src="/static/index/img/330ebeaef02f91e8036e38a36f310159.jpeg">-->
    <!--</a>-->

<!--</div>-->


    <!--</div>-->

    <!--<div class="row show-grid">-->
    <!--</div>-->
<!--</div>-->
<!--<div id="domesitic" class=" category-module module-container">-->
    <!--<div class="module-title">-->
        <!--<div class="row show-grid clearfix">-->
            <!--<div class="col-lg-4 title">-->
                <!--数码家电<sub>ELECTRONICS</sub>-->
            <!--</div>-->
            <!--<div class="more">-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1561"    target="_blank" data-position-id="1000028">智能手环</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1623"    target="_blank" data-position-id="1000029">电饭煲</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1623"    target="_blank" data-position-id="1000030">扫地机</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1698"    target="_blank" data-position-id="1000031">按摩椅</a>-->
<!--&lt;!&ndash;                 <a href="http://baidu.com">更多数码家电</a>> &ndash;&gt;-->
            <!--</div>-->
        <!--</div>-->
    <!--</div>-->

    <!--<div class="row show-grid content">-->
        <!--<div class="col-lg-6 left-img" style="background-color: #22AAFF">-->
            <!--<img class="background-img" src="/static/index/img/7c1a7b753a4f0adb1ccd322950ff1117.jpg@q_90,f_webp">-->
            <!--<a class="bg-link" href="http://mall.baidu.com/shop?shopId=34" target="_blank" data-position-id="1000032"></a>-->
            <!--<div class="category">-->


                <!--<h3>精选分类</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1550" title="手机通讯" alt="手机通讯"  target="_blank" data-position-id="1000031">手机通讯</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1570" title="电脑办公" alt="电脑办公"  target="_blank" data-position-id="1000031">电脑办公</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1598" title="摄影摄像" alt="摄影摄像"  target="_blank" data-position-id="1000031">摄影摄像</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1559" title="智能产品" alt="智能产品"  target="_blank" data-position-id="1000031">智能产品</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1667" title="健康护理" alt="健康护理"  target="_blank" data-position-id="1000031">健康护理</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=1605" title="耳机耳麦" alt="耳机耳麦"  target="_blank" data-position-id="1000031">耳机耳麦</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=1621" title="厨房生活" alt="厨房生活"  target="_blank" data-position-id="1000031">厨房生活</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1653" title="生活电器" alt="生活电器"  target="_blank" data-position-id="1000031">生活电器</a>-->

                <!--</div>-->

                <!--<h3>时尚品牌</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=368" title="GoPro" alt="GoPro" target="_blank" data-position-id="1000031">GoPro</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=136" title="虎牌" alt="虎牌" target="_blank" data-position-id="1000031">虎牌</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=176" title="惠人" alt="惠人" target="_blank" data-position-id="1000031">惠人</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=347" title="Beats" alt="Beats" target="_blank" data-position-id="1000031">Beats</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=131" title="佳明" alt="佳明" target="_blank" data-position-id="1000031">佳明</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=219" title="惠普" alt="惠普" target="_blank" data-position-id="1000031">惠普</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=98" title="科沃斯" alt="科沃斯" target="_blank" data-position-id="1000031">科沃斯</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=34" title="傲胜" alt="傲胜" target="_blank" data-position-id="1000031">傲胜</a>-->

                <!--</div>-->

                <!--<div class="left-bottom-img">-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=228" target="_blank">-->
                        <!--<img src="/static/index/img/e536ae46befe1b6a976c1912930f12c7.png@q_90,f_png">-->
                    <!--</a>-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=45" target="_blank">-->
                        <!--<img src="/static/index/img/48cc14635fc02fb73a98195bf2613231.png@q_90,f_png">-->
                    <!--</a>-->
                <!--</div>-->
            <!--</div>-->
        <!--</div>-->

<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=1370&skuId=4429" class="content-container clearfix" target="_blank" data-position-id="1000033">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>九阳全自动豆浆机</h3>-->
        <!--<p class="desc">破壁免滤系统一杯顶两杯</p>-->
        <!--<p class="price">-->
            <!--¥389.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/f46262bb45fdafee49027cfe9fe5cc44.jpg@q_90,f_webp" alt="九阳全自动豆浆机 破壁免滤系统一杯顶两杯">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=1001&skuId=2971" class="content-container clearfix" target="_blank" data-position-id="1000034">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>九阳水龙头净水器</h3>-->
        <!--<p class="desc">性炭过滤 可清洗滤芯</p>-->
        <!--<p class="price">-->
            <!--¥76.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/c5ec5cd03ae31ef666935f63b77a5d69.jpg@q_90,f_webp" alt="九阳水龙头净水器 性炭过滤 可清洗滤芯">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=108956&skuId=327283" class="content-container clearfix" target="_blank" data-position-id="1000035">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>飞利浦剃须刀</h3>-->
        <!--<p class="desc">热卖爆款 快速干爽</p>-->
        <!--<p class="price">-->
            <!--¥179.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/4e6080b6b581b0524382706dfe280951.jpg@q_90,f_webp" alt="飞利浦剃须刀 热卖爆款 快速干爽">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=7946&skuId=36066" class="content-container clearfix" target="_blank" data-position-id="1000036">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>beats 入耳式耳机</h3>-->
        <!--<p class="desc">低音澎湃 轻盈小巧</p>-->
        <!--<p class="price">-->
            <!--¥578.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/9a5f34c8319d23fbe88861d9bb1867e5.jpg@q_90,f_webp" alt="beats 入耳式耳机 低音澎湃 轻盈小巧">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=224&skuId=3479" class="content-container clearfix" target="_blank" data-position-id="1000037">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>HP 15.6寸游戏本</h3>-->
        <!--<p class="desc">时尚纤薄外观 锐炬显卡</p>-->
        <!--<p class="price">-->
            <!--¥4799.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/62d786f8c4c821c73c5b97f9c0b88e95.jpg@q_90,f_webp" alt="HP 15.6寸游戏本 时尚纤薄外观 锐炬显卡">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=120012&skuId=412227" class="content-container clearfix" target="_blank" data-position-id="1000038">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>佳明光学心率腕表</h3>-->
        <!--<p class="desc">新品上市 功能卓越</p>-->
        <!--<p class="price">-->
            <!--¥2180.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/72e701f10e4250d4c700399962ebd44e.jpg@q_90,f_webp" alt="佳明光学心率腕表 新品上市 功能卓越">-->
        <!--<img class="brand-desc" src="/static/index/img/a26b9fb75de2f850718bc5b05194d473.jpg@q_90,f_webp">-->
    <!--</a>-->

<!--</div>-->


    <!--</div>-->

    <!--<div class="row show-grid">-->
    <!--</div>-->
<!--</div>-->
<!--<div id="house" class=" category-module module-container">-->
    <!--<div class="module-title">-->
        <!--<div class="row show-grid clearfix">-->
            <!--<div class="col-lg-4 title">-->
                <!--母婴家居<sub>BABY &amp; HOME</sub>-->
            <!--</div>-->
            <!--<div class="more">-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=750&amp;tr=cp.1_pr.77667&amp;priceRange=min%3D0%26max%3D0&amp;propertyFilterList=14516%3D366803&amp;shopIdList=&amp;imageSizeType=&amp;sortType=0&amp;marketId=0&amp;pageIndex=1&amp;sceneType=1"    target="_blank" data-position-id="1000028">防霾口罩</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1385&amp;tr=cp.1_pr.70596_po.1000012&amp;priceRange=min%3D0%26max%3D0&amp;propertyFilterList=&amp;shopIdList=&amp;imageSizeType=&amp;sortType=0&amp;marketId=0&amp;pageIndex=1&amp;sceneType=1"    target="_blank" data-position-id="1000029">洗护喂养</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=1373&amp;tr=cp.1_pr.70596_po.1000012"    target="_blank" data-position-id="1000030">尿裤湿巾</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=751&amp;qq-pf-to=pcqq.c2c"    target="_blank" data-position-id="1000031">雨伞</a>-->
<!--&lt;!&ndash;                 <a href="http://baidu.com">更多母婴家居</a>> &ndash;&gt;-->
            <!--</div>-->
        <!--</div>-->
    <!--</div>-->

    <!--<div class="row show-grid content">-->
        <!--<div class="col-lg-6 left-img" style="background-color: #22AAFF">-->
            <!--<img class="background-img" src="/static/index/img/cede4937405f100ef669dec7f2221eee.jpg@q_90,f_webp">-->
            <!--<a class="bg-link" href="http://mall.baidu.com/shop?shopId=369" target="_blank" data-position-id="1000032"></a>-->
            <!--<div class="category">-->


                <!--<h3>精选分类</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=695" title="锅具" alt="锅具"  target="_blank" data-position-id="1000031">锅具</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=1377&amp;tr=cp.1_pr.70596_po.1000012&amp;priceRange=min%3D0%26max%3D0&amp;propertyFilterList=&amp;shopIdList=&amp;imageSizeType=&amp;sortType=0&amp;marketId=0&amp;pageIndex=1&amp;sceneType=1" title="奶粉" alt="奶粉"  target="_blank" data-position-id="1000031">奶粉</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=716" title="水具" alt="水具"  target="_blank" data-position-id="1000031">水具</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=857" title="床品套件" alt="床品套件"  target="_blank" data-position-id="1000031">床品套件</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=1385&amp;tr=cp.1_pr.70596_po.1000012&amp;priceRange=min%3D0%26max%3D0&amp;propertyFilterList=&amp;shopIdList=&amp;imageSizeType=&amp;sortType=0&amp;marketId=0&amp;pageIndex=1&amp;sceneType=1&amp;tg=sv.18061262986301458896395305730_exp." title="洗护喂养" alt="洗护喂养"  target="_blank" data-position-id="1000031">洗护喂养</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=737" title="清洁工具" alt="清洁工具"  target="_blank" data-position-id="1000031">清洁工具</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=733" title="收纳" alt="收纳"  target="_blank" data-position-id="1000031">收纳</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=818" title="宠物生活" alt="宠物生活"  target="_blank" data-position-id="1000031">宠物生活</a>-->

                <!--</div>-->

                <!--<h3>时尚品牌</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=177" title="菲仕乐" alt="菲仕乐" target="_blank" data-position-id="1000031">菲仕乐</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=31&amp;tg=sv.18059190786301458896236038880_exp.&amp;tr=cp.3_pr.95107_po.4000021" title="美赞臣" alt="美赞臣" target="_blank" data-position-id="1000031">美赞臣</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=216" title="乐扣乐扣" alt="乐扣乐扣" target="_blank" data-position-id="1000031">乐扣乐扣</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=147" title="水星" alt="水星" target="_blank" data-position-id="1000031">水星</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=460&amp;tg=sv.18059190886301458896255576345_exp.&amp;tr=cp.3_pr.79897_po.4000021" title="哈罗闪" alt="哈罗闪" target="_blank" data-position-id="1000031">哈罗闪</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=101" title="Esprit" alt="Esprit" target="_blank" data-position-id="1000031">Esprit</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=547&amp;tr=cp.5_pr.91109" title="膳魔师" alt="膳魔师" target="_blank" data-position-id="1000031">膳魔师</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=210" title="3M" alt="3M" target="_blank" data-position-id="1000031">3M</a>-->

                <!--</div>-->

                <!--<div class="left-bottom-img">-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=331" target="_blank">-->
                        <!--<img src="/static/index/img/91572d0b3a8021bcf35163c853b13cbe.png@q_90,f_png">-->
                    <!--</a>-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=161&amp;tg=sv.18061262986301458896395305730_exp.&amp;tr=cp.3_pr.22378_po.4000021" target="_blank">-->
                        <!--<img src="/static/index/img/19411f486f3e87836b4a30faba5f3f80.png@q_90,f_png">-->
                    <!--</a>-->
                <!--</div>-->
            <!--</div>-->
        <!--</div>-->

<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=100003&skuId=349452" class="content-container clearfix" target="_blank" data-position-id="1000033">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>得宝加厚亲肤抽纸</h3>-->
        <!--<p class="desc">高品质 4层90抽*12包</p>-->
        <!--<p class="price">-->
            <!--¥59.90-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/b4b9a410f06ea11581efc6c387a5dcd4.jpg@q_90,f_webp" alt="得宝加厚亲肤抽纸 高品质 4层90抽*12包">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=120963&skuId=418158" class="content-container clearfix" target="_blank" data-position-id="1000034">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>食品蒸搅一体机</h3>-->
        <!--<p class="desc">特卖推荐！全场满149减10...</p>-->
        <!--<p class="price">-->
            <!--¥680.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/fb61e2858c58b675c13e7c140de1de2d.jpg@q_90,f_webp" alt="食品蒸搅一体机 特卖推荐！全场满149减10元">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=3165&skuId=12794" class="content-container clearfix" target="_blank" data-position-id="1000035">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>乐扣乐扣超值4件套</h3>-->
        <!--<p class="desc">踏青出游 满199减30</p>-->
        <!--<p class="price">-->
            <!--¥139.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/acfbd18f1c03a2b68aa4ccc86c9b2056.jpg@q_90,f_webp" alt="乐扣乐扣超值4件套 踏青出游 满199减30">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=1262&skuId=4104" class="content-container clearfix" target="_blank" data-position-id="1000036">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>梦洁家纺纯棉4件套</h3>-->
        <!--<p class="desc">甜心波点 纯棉亲肤</p>-->
        <!--<p class="price">-->
            <!--¥299.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/3f7f01898bcf1cf544f760d753cc77ec.jpg@q_90,f_webp" alt="梦洁家纺纯棉4件套 甜心波点 纯棉亲肤">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=101942&skuId=276074" class="content-container clearfix" target="_blank" data-position-id="1000037">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>哈罗闪 护肤油</h3>-->
        <!--<p class="desc">德国进口柔润护肤油200ml</p>-->
        <!--<p class="price">-->
            <!--¥109.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/a8991efb561715875d65c66a5f17b409.jpg@q_90,f_webp" alt="哈罗闪 护肤油 德国进口柔润护肤油200ml">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=112938&skuId=357130" class="content-container clearfix" target="_blank" data-position-id="1000038">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>双立人炒锅5件套</h3>-->
        <!--<p class="desc">Twin Nova III系列超值</p>-->
        <!--<p class="price">-->
            <!--¥1958.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/0c628a5172682ffb35906fdf13aac31e.jpg@q_90,f_webp" alt="双立人炒锅5件套 Twin Nova III系列超值">-->
        <!--<img class="brand-desc" src="/static/index/img/1cdbb965966c6d3c20c97e024bde7ad6.png@q_90,f_png">-->
    <!--</a>-->

<!--</div>-->


    <!--</div>-->

    <!--<div class="row show-grid">-->
    <!--</div>-->
<!--</div>-->
<!--<div id="food" class=" category-module module-container">-->
    <!--<div class="module-title">-->
        <!--<div class="row show-grid clearfix">-->
            <!--<div class="col-lg-4 title">-->
                <!--食品特产<sub>FOODHALL</sub>-->
            <!--</div>-->
            <!--<div class="more">-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=519"    target="_blank" data-position-id="1000028">坚果炒货</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=491"    target="_blank" data-position-id="1000029">糖果巧克力</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=117"    target="_blank" data-position-id="1000030">茗茶</a>-->
                <!--<a data-id="" href="http://mall.baidu.com/category?catidList=135"    target="_blank" data-position-id="1000031">白酒</a>-->
<!--&lt;!&ndash;                 <a href="http://baidu.com">更多食品特产</a>> &ndash;&gt;-->
            <!--</div>-->
        <!--</div>-->
    <!--</div>-->

    <!--<div class="row show-grid content">-->
        <!--<div class="col-lg-6 left-img" style="background-color: #22AAFF">-->
            <!--<img class="background-img" src="/static/index/img/9c02aa6a1df0975714dfba00af77a7c4.jpg@q_90,f_webp">-->
            <!--<a class="bg-link" href="http://mall.baidu.com/shop?shopId=750" target="_blank" data-position-id="1000032"></a>-->
            <!--<div class="category">-->


                <!--<h3>精选分类</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=430" title="休闲食品" alt="休闲食品"  target="_blank" data-position-id="1000031">休闲食品</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=147" title="饮料冲调" alt="饮料冲调"  target="_blank" data-position-id="1000031">饮料冲调</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=14" title="食品保健" alt="食品保健"  target="_blank" data-position-id="1000031">食品保健</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=117" title="茗茶" alt="茗茶"  target="_blank" data-position-id="1000031">茗茶</a>-->
                    <!--<a class="active" href="http://mall.baidu.com/category?catidList=134" title="中外名酒" alt="中外名酒"  target="_blank" data-position-id="1000031">中外名酒</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=304" title="粮油干货" alt="粮油干货"  target="_blank" data-position-id="1000031">粮油干货</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=555" title="生鲜食品" alt="生鲜食品"  target="_blank" data-position-id="1000031">生鲜食品</a>-->
                    <!--<a class="" href="http://mall.baidu.com/category?catidList=2" title="食品礼券" alt="食品礼券"  target="_blank" data-position-id="1000031">食品礼券</a>-->

                <!--</div>-->

                <!--<h3>时尚品牌</h3>-->
                <!--<div class="sub-list">-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=229" title="哈根达斯" alt="哈根达斯" target="_blank" data-position-id="1000031">哈根达斯</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=266" title="善存" alt="善存" target="_blank" data-position-id="1000031">善存</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=377" title="万多福" alt="万多福" target="_blank" data-position-id="1000031">万多福</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=306" title="芭喜" alt="芭喜" target="_blank" data-position-id="1000031">芭喜</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=241" title="德芙" alt="德芙" target="_blank" data-position-id="1000031">德芙</a>-->

                    <!--<a class="active"  href="http://mall.baidu.com/shop?shopId=205" title="华祥苑" alt="华祥苑" target="_blank" data-position-id="1000031">华祥苑</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=307" title="费列罗" alt="费列罗" target="_blank" data-position-id="1000031">费列罗</a>-->

                    <!--<a class=""  href="http://mall.baidu.com/shop?shopId=726" title="汾酒" alt="汾酒" target="_blank" data-position-id="1000031">汾酒</a>-->

                <!--</div>-->

                <!--<div class="left-bottom-img">-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=35" target="_blank">-->
                        <!--<img src="/static/index/img/e59be47af396f8e2d60a4fa9d30e4279.jpg@q_90,f_webp">-->
                    <!--</a>-->
                    <!--<a href="http://mall.baidu.com/shop?shopId=265" target="_blank">-->
                        <!--<img src="/static/index/img/6697fdd73c17e898d18554ef4dc98b2a.jpg@q_90,f_webp">-->
                    <!--</a>-->
                <!--</div>-->
            <!--</div>-->
        <!--</div>-->

<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=124552&skuId=443583" class="content-container clearfix" target="_blank" data-position-id="1000033">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>哆啦A梦 山楂3连发</h3>-->
        <!--<p class="desc">30年品质 佳宝用心做好</p>-->
        <!--<p class="price">-->
            <!--¥29.90-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/38908edc7c6f73423a72d02541298022.jpg@q_90,f_webp" alt="哆啦A梦 山楂3连发 30年品质 佳宝用心做好">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=111501&skuId=348329" class="content-container clearfix" target="_blank" data-position-id="1000034">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>德芙 巧克力</h3>-->
        <!--<p class="desc">摩卡榛仁巧克力98g*2</p>-->
        <!--<p class="price">-->
            <!--¥66.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/bb289d414d770e3184384715379bbb88.jpg@q_90,f_webp" alt="德芙 巧克力 摩卡榛仁巧克力98g*2">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=10716&skuId=50589" class="content-container clearfix" target="_blank" data-position-id="1000035">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>七彩云南 普洱茶</h3>-->
        <!--<p class="desc">印象云南普洱茶 357g</p>-->
        <!--<p class="price">-->
            <!--¥79.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/5dfdab80a111eefcaa37554616a9914e.jpg@q_90,f_webp" alt="七彩云南 普洱茶 印象云南普洱茶 357g">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=10409&skuId=106202" class="content-container clearfix" target="_blank" data-position-id="1000036">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>奇华萌翻熊猫曲奇</h3>-->
        <!--<p class="desc">香港品牌 铁罐198g</p>-->
        <!--<p class="price">-->
            <!--¥78.00-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/bbcdd7a6363633c79459101548799ff2.jpg@q_90,f_webp" alt="奇华萌翻熊猫曲奇 香港品牌 铁罐198g">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=112290&skuId=352561" class="content-container clearfix" target="_blank" data-position-id="1000037">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>宁化府 老陈醋</h3>-->
        <!--<p class="desc">山西老陈醋2400ml</p>-->
        <!--<p class="price">-->
            <!--¥34.90-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/cc0d2e5de19d31ed85b2278b71a7a7b3.jpg@q_90,f_webp" alt="宁化府 老陈醋 山西老陈醋2400ml">-->
    <!--</a>-->

<!--</div>-->
<!--<div class="col-lg-2 product-item">-->
    <!--<a    href="/product?itemId=97727&skuId=245201" class="content-container clearfix" target="_blank" data-position-id="1000038">-->
<!--&lt;!&ndash;          &ndash;&gt;-->
        <!--<h3>齐云山 酸枣糕</h3>-->
        <!--<p class="desc">南酸枣糕1000g 绿色食品</p>-->
        <!--<p class="price">-->
            <!--¥53.60-->
        <!--</p>-->
        <!--<img class="cover-img" src="/static/index/img/4529c0b6751be4931c61dd824c39ba18.jpg@q_90,f_webp" alt="齐云山 酸枣糕 南酸枣糕1000g 绿色食品">-->
        <!--<img class="brand-desc" src="/static/index/img/9a60e302a467e2d8d1f576e5cced1748.jpg@q_90,f_webp">-->
    <!--</a>-->

<!--</div>-->


    <!--</div>-->

    <!--<div class="row show-grid">-->
    <!--</div>-->
<!--</div>-->


        <div class="tool-bar">
            <ul>

                <li class="major tool-item icon-crown2" data-type="major">
                    <a href="#major" class="desc">今日<br>大牌</a>
                </li>

                <li class="immediate tool-item icon-star" data-type="immediate">
                    <a href="#immediate" class="desc">每日<br>精选</a>
                </li>

                <li class="clothing tool-item icon-clothes" data-type="clothing">
                    <a href="#clothing" class="desc">服装服饰</a>
                </li>
                <li class="bags tool-item icon-shoe" data-type="bags">
                    <a href="#bags" class="desc">鞋包运动</a>
                </li>
                <li class="beauty tool-item icon-mirror" data-type="beauty">
                    <a href="#beauty" class="desc">美妆珠宝</a>
                </li>
                <li class="domesitic tool-item icon-telephone" data-type="domesitic">
                    <a href="#domesitic" class="desc">数码家电</a>
                </li>
                <li class="house tool-item icon-sofa" data-type="house">
                    <a href="#house" class="desc">母婴家居</a>
                </li>
                <li class="food tool-item icon-plate" data-type="food">
                    <a href="#food" class="desc">食品特产</a>
                </li>

                <li class="icon-feedback2 icon-arrow-up btn-feedback">
                    <a href="javascript:void(0)" class="desc btn-feedback">意见<br>反馈</a>
                </li>

                <li class="top icon-arrow-up">
                    <a href="#header" class="desc">回到<br>顶部</a>
                </li>
            </ul>

        </div>

    </div>
</div>


<div id="footer">

    <!--<ul class="helper">-->
        <!--<li>-->
            <!--<div class="helper-item">-->
                <!--<i class="helper-icon icon-diamond"></i>-->
                <!--<h3>臻选品牌 正品保障</h3>-->
            <!--</div>-->
        <!--</li>-->
        <!--<li>-->
            <!--<div class="helper-item">-->
                <!--<i class="helper-icon icon-crown"></i>-->
                <!--<h3>新款推荐 引领潮流</h3>-->
            <!--</div>-->
        <!--</li>-->
        <!--<li>-->
            <!--<div class="helper-item">-->
                <!--<i class="helper-icon icon-lamp"></i>-->
                <!--<h3>创意个性 特色特惠</h3>-->
            <!--</div>-->
        <!--</li>-->
        <!--<li>-->
            <!--<div class="helper-item">-->
                <!--<i class="helper-icon icon-flower"></i>-->
                <!--<h3>优质服务 无忧购物</h3>-->
            <!--</div>-->
        <!--</li>-->
    <!--</ul>-->

    <div class="footer-link">
        <!--<ul>-->
            <!--<li>-->
                <!--<h3 class="title">-->
                    <!--<a >服务保障</a>-->
                <!--</h3>-->
                <!--<p><a href="/footer/helpCenter/qualitySafeguard" data-potition-id="1000039" target="_blank">正品保障</a></p>-->
                <!--<p><a href="/footer/helpCenter/returnService" data-potition-id="1000039" target="_blank">七天无理由退换货</a></p>-->
                <!--<p><a href="/footer/helpCenter/returnPolicy" data-potition-id="1000039" target="_blank">退货政策</a></p>-->
                <!--<p><a href="/footer/helpCenter/returnProcess" data-potition-id="1000039" target="_blank">退货流程</a></p>-->
            <!--</li>-->
            <!--<li>-->
                <!--<h3 class="title">-->
                    <!--<a >购物指南</a>-->
                <!--</h3>-->
                <!--<p><a class="register" href="javascript:" data-potition-id="1000040" target="_blank">免费注册</a></p>-->
                <!--<p><a href="/footer/helpCenter/shoppingProcess" data-potition-id="1000040" target="_blank">购物流程</a></p>-->
                <!--<p><a href="/footer/helpCenter/accountManagement" data-potition-id="1000040" target="_blank">账户管理</a></p>-->
                <!--<p><a href="/footer/helpCenter/distributionMode" data-potition-id="1000040" target="_blank">配送方式</a></p>-->
                <!--<p><a href="/footer/helpCenter/shoppingGuide/shoppingStep" data-potition-id="1000040" target="_blank">用户帮助</a></p>-->
            <!--</li>-->
            <!--<li>-->
                <!--<h3 class="title">-->
                    <!--<a >支付方式</a>-->
                <!--</h3>-->
                <!--<p><a href="/footer/helpCenter/onlinePayment" data-potition-id="1000041" target="_blank">在线支付</a></p>-->
                <!--<p><a href="https://www.baifubao.com/" data-potition-id="1000041" target="_blank">百度钱包</a></p>-->
            <!--</li>-->
            <!--<li>-->
                <!--<h3 class="title">-->
                    <!--<a>商家服务</a>-->
                <!--</h3>-->
                <!--<p><a href="http://mallzs.baidu.com/#/home" data-potition-id="1000042" target="_blank">商家入驻</a></p>-->
                <!--<p><a href="/footer/ruleCenter/rule" data-potition-id="1000042" target="_blank">规则中心</a></p>-->
                <!--<p><a href="/footer/helpCenter/merchantsSettled" data-potition-id="1000042" target="_blank">商家帮助</a></p>-->
            <!--</li>-->
            <!--<li class="footer-follow">-->
                <!--<h1 class="footer-logo">-->
                    <!--<img src="/static/index/img/logo_reverse.png">-->
                <!--</h1>-->
                <!--<p class="slogan">百度旗下电商，为您提供值得信赖的品质服务</p>-->
                <!--<div class="follow">-->
                    <!--<span class="text">关注我们</span>-->
                    <!--<i class="icon-weixin-logo icon-wechat">-->
                        <!--<span class="two-dimension-code"></span>-->
                    <!--</i>-->
                    <!--<a  target="_blank"  href="http://weibo.com/baidumall2015" class="icon-weibo-logo icon-micro-blog">-->
                    <!--</a>-->
                    <!--<a href="http://tieba.baidu.com/f?ie=utf-8&kw=百度MALL" class="icon-weibo-logo icon-tieba" target="_blank">-->
                    <!--</a>-->
                <!--</div>-->
                <!--<div class="feedback">-->
                    <!--<span class="text">意见反馈</span>-->
                    <!--<i class="icon-feedback btn-feedback"></i>-->
                <!--</div>-->
            <!--</li>-->
        <!--</ul>-->
    </div>

    <!--<div class="footer-copyright">-->
        <!--<div>-->
            <!--<a class="cop" href="http://www.miitbeian.gov.cn/state/outPortal/loginPortal.action" target="_blank">京ICP证030173号</a>-->
            <!--<a class="cop" href="/footer/businessLicence" target="_blank">营业执照信息</a>-->
        <!--</div>-->
        <!--<p>©2015-2016 baidu.com版权所有</p>-->
    <!--</div>-->
<!--</div>-->

<script type="text/javascript" src="/static/index/js/cookie.js"></script>
<script type="text/javascript" src="/static/index/js/header.js"></script>
<script type="text/javascript" src="/static/index/js/index.js"></script>
<script type="text/javascript" src="/static/index/js/etpl.js"></script>
<script type="text/javascript" src="http://mallcdn.baidu.com/static/2016033051016/js/common/cookie.js"></script>


<script>
$(function () {
        require(['index']);
})
</script>
        <script>
        if ('' !== '') {
            require(['common/md5'], function (md5) {
                var merchantSiteId = md5('');
                clearBaiduTJ('', merchantSiteId);
            });
        }
        </script>
        <script>
            window.alogObjectConfig = {
                product: '682',
                page: 'MALL-index',
                speed: {
                    sample: '1'
                },
                monkey: {
                    sample: '1'
                },
                exception: {
                    sample: '1'
                },
                feature: {
                    sample: '1'
                }
            };
            void function(a,b,c,d,e,f){function g(b){a.attachEvent?a.attachEvent("onload",b,!1):a.addEventListener&&a.addEventListener("load",b)}function h(a,c,d){d=d||15;var e=new Date;e.setTime((new Date).getTime()+1e3*d),b.cookie=a+"="+escape(c)+";path=/;expires="+e.toGMTString()}function i(a){var c=b.cookie.match(new RegExp("(^| )"+a+"=([^;]*)(;|$)"));return null!=c?unescape(c[2]):null}function j(){var a=i("PMS_JT");if(a){h("PMS_JT","",-1);try{a=a.match(/{["']s["']:(\d+),["']r["']:["']([\s\S]+)["']}/),a=a&&a[1]&&a[2]?{s:parseInt(a[1]),r:a[2]}:{}}catch(c){a={}}a.r&&b.referrer.replace(/#.*/,"")!=a.r||alog("speed.set","wt",a.s)}}if(a.alogObjectConfig){var k=a.alogObjectConfig.sample,l=a.alogObjectConfig.rand;if("https:"===a.location.protocol){if(d="https://gss2.bdstatic.com/70cFsjip0QIZ8tyhnq"+d,!k||!l)return}else d="http://img.baidu.com"+d;k&&l&&l>k||(g(function(){alog("speed.set","lt",+new Date),e=b.createElement(c),e.async=!0,e.src=d+"?v="+~(new Date/864e5),f=b.getElementsByTagName(c)[0],f.parentNode.insertBefore(e,f)}),j())}}(window,document,"script","/hunter/alog/dp.min.js");
        </script>
        <script>
            alog('speed.set', 'drt', +new Date);
        </script>
    </body>
</html>
