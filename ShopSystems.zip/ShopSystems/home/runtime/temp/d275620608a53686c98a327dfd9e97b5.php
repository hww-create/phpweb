<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:50:"C:\wamp\www\tp5\home\index\view\index\details.html";i:1461140941;}*/ ?>
﻿<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
        <meta name="baidu-site-verification" content="ZEXvy8Xkma" />
        <link rel="dns-prefetch" href="//mallcmscdn.baidu.com">
        <link rel="dns-prefetch" href="//mallcdn.baidu.com">
        <link rel="dns-prefetch" href="//hm.baidu.com">
        <link rel="dns-prefetch" href="//bcscdn.baidu.com">
        <link rel="dns-prefetch" href="//bj.bcebos.com">

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦【图片 价格 品牌 报价 评测】-百度MALL</title>
        <script>
            void function(g,f,j,c,h,d,b){g.alogObjectName=h,g[h]=g[h]||function(){(g[h].q=g[h].q||[]).push(arguments)},g[h].l=g[h].l||+new Date,d=f.createElement(j),d.async=!0,d.src=c,b=f.getElementsByTagName(j)[0],b.parentNode.insertBefore(d,b)}(window,document,"script","http://img.baidu.com/hunter/alog/alog.min.js","alog");void function(){function c(){return;}window.PDC={mark:function(a,b){alog("speed.set",a,b||+new Date);alog.fire&&alog.fire("mark")},init:function(a){alog("speed.set","options",a)},view_start:c,tti:c,page_ready:c}}();void function(n){var o=!1;n.onerror=function(n,e,t,c){var i=!0;return!e&&/^script error/i.test(n)&&(o?i=!1:o=!0),i&&alog("exception.send","exception",{msg:n,js:e,ln:t,col:c}),!1},alog("exception.on","catch",function(n){alog("exception.send","exception",{msg:n.msg,js:n.path,ln:n.ln,method:n.method,flag:"catch"})})}(window);
        </script>
<meta name="keywords" content="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦,百度MALL,网上购物">
<meta name="description" content="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦图片、价格、品牌样样齐全【百度MALL百分百正品行货，网购上百度MALL，放心又轻松】">

        <link rel="shortcut icon" href="http://mallcdn.baidu.com/static/2016033051016/favicon.ico" >
        <script src="/static/index/js/core.js"></script>

        <script>
            require.config({
        'waitSeconds': 30,
        'baseUrl': 'http://mallcdn.baidu.com/static/2016033051016/js',
        'packages': [
            {
                'name': 'echarts',
                'location': '../dep/echarts/2.2.7/src',
                'main': 'echarts'
            },
            {
                'name': 'zrender',
                'location': '../dep/zrender/2.1.1/src',
                'main': 'zrender'
            }
        ]
    });
        </script>

<link rel="stylesheet" href="/static/index/css/style.css">
<link rel="stylesheet" href="/static/index/css/product.css">

        <script>
        var cr = Math.floor(Math.random() * 99999);
        var activityId = '';
        var pageId = '5' ? '5' : 0;
        var rtTag = $.stringifyJSON({
    "ecom_view": {
        "prod": [ {
            "p_id": "94336",
            "p_name": "芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦",
            "p_price": "529.00",
            "p_class1": "服装服饰",
            "p_class2": "女装",
            "p_class3": "裙装",
            "p_class4": "连衣裙",
            "p_stock": "2",
            "p_img_url": "http://ipcmm.baidu.com/media/v1/0f00057f9ViF15sFKCGPq0.jpg",
            "p_url": "http://mall.baidu.com/product?itemId=17170&skuId=94336&tg=sv.18061262986301460904315070046_exp.&tr=cp.3_pr.13865_po.4000020"
        }]
    }
}
);

        // if (location.href.indexOf('mall.baidu.com') !== -1) {
            var _hmt = _hmt || [];
            var siteId = 'd64af1f3b8e241d56f0536501d4bfdd6';
            _hmt.push(['_setAccount', siteId]);
            _hmt.push(['_setAutoPageview', false]);

            if (rtTag) {
                _hmt.push(['_trackRTEvent', {
                    data: $.parseJSON(rtTag)
                }]);
            }

            trackPageViewTJ(siteId, '5', '[{"shopId": 297}]');
            if ('7481623' !== '') {
                require(['common/md5'], function (md5) {
                    var merchantSiteId = md5('7481623');
                    _hmt.push(['_setAccount', merchantSiteId]);
                    _hmt.push(['_setAutoPageview', true]);
                    deployBaiduTJ(merchantSiteId);
                });
            // }
        }

        </script>
    </head>
    <script>
        alog('speed.set', 'ht', +new Date);
    </script>
    <body>
        <script>
            var GLOBAL_CONF = {"debug":false,"passport":{"host":"passport.baidu.com","tpl":"bdmall"},"site":{"siteId":7202944,"ucId":10914574}};
        </script>

<div id="common-header" class="normal-header">
    <div class="mini-header-search">
        <div class="container">
            <div class="user-info">
                <a href="/" target="_self" data-position-id="1000002">欢迎光临百度MALL</a><span class="separate">|</span>
                <span class="common-login-info">
                <a href="javascript:;" class="J_loginBtn" data-position-id="1000007">请登录</a><span class="separate">|</span>
                <a href="javascript:;" class="J_regBtn" data-position-id="1000008">免费注册</a><span class="separate">|</span>
                </span>
                <a href="/home" target="_blank" data-position-id="1000005">个人中心</a><span class="separate">|</span>
                <a href="/home/order/list" target="_blank" data-position-id="1000043">我的订单</a><span class="separate">|</span>
                <a href="/cart/list" target="_blank" data-position-id="1000006"><i class="bag-icon f-icon"></i>购物袋（<span class="num">0</span>）</a>
            </div>
        </div>
    </div>
    <div id="header">

        <a class="logo" href="/" data-position-id="1000001">
            <img src="/static/index/img/mall_logo.png">
        </a>
<div class="search-box">
    <input type="text" class="search-text" placeholder="搜索你想要的" value="">
    <button class="search-btn">搜索</button>
    <ul class="search-suggest">
    </ul>
</div>

<dl class="widget-service-guarantee">
    <dd>
        <i class="icon-guarantee22"></i>
        <p>正品保障</p>
    </dd>
    <dd>
        <i class="icon-certified"></i>
        <p>品牌验真</p>
    </dd>
    <dd>
        <i class="icon-compensation"></i>
        <p>假一赔五</p>
    </dd>
</dl>
    </div>
    <div class="nav-container">
        <div id="nav">
            <ul class="main-menu">
                <li class="main-menu-item all-category with-sub-menu">
                    <a href="javascript:"><i class="ui-icon-category icon-category"></i>全部商品分类</a>
                    <div class="sub-menu-container">
                        <ul class="">
                            <li class="sub-menu-item">
                                <h3>服装服饰</h3>
                                <div class="second-menu-wapper">
                                    <a href="/category?catidList=1399" target="_blank" data-position-id="1000012">女装</a>
                                    <a href="/category?catidList=1433" target="_blank" data-position-id="1000012">男装</a>
                                    <a href="/category?catidList=1468" target="_blank" data-position-id="1000012">内衣袜品</a>
                                    <a href="/category?catidList=1464" target="_blank" data-position-id="1000012">服饰配件</a>
                                </div>
                                <div class="third-menu-container">
                                    <ul>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1399" target="_blank" data-position-id="1000012">女装</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1429" target="_blank" data-position-id="1000012">大衣风衣</a>
                                                <a href="/category?catidList=1400" target="_blank" data-position-id="1000012">羽绒服</a>
                                                <a href="/category?catidList=1414" target="_blank" data-position-id="1000012">毛衣</a>
                                                <a href="/category?catidList=1416" target="_blank" data-position-id="1000012">针织衫</a>
                                                <a href="/category?catidList=1407" target="_blank" data-position-id="1000012">外套</a>
                                                <a href="/category?catidList=1411" target="_blank" data-position-id="1000012">连衣裙</a>
                                                <a href="/category?catidList=1412" target="_blank" data-position-id="1000012">半身裙</a>
                                                <a href="/category?catidList=1424" target="_blank" data-position-id="1000012">休闲裤</a>
                                                <a href="/category?catidList=1421" target="_blank" data-position-id="1000012">牛仔裤</a>
                                                <a href="/category?catidList=1401" target="_blank" data-position-id="1000012">棉服</a>
                                                <a href="/category?catidList=1427" target="_blank" data-position-id="1000012">T恤</a>
                                                <a href="/category?catidList=1428" target="_blank" data-position-id="1000012">衬衫</a>
                                                <a href="/category?catidList=1422" target="_blank" data-position-id="1000012">西裤</a>
                                                <a href="/category?catidList=1406" target="_blank" data-position-id="1000012">西装</a>
                                                <a href="/category?catidList=1408" target="_blank" data-position-id="1000012">卫衣</a>
                                                <a href="/category?catidList=1409" target="_blank" data-position-id="1000012">马甲</a>
                                                <a href="/category?catidList=1425" target="_blank" data-position-id="1000012">打底裤</a>
                                                <a href="/category?catidList=1415" target="_blank" data-position-id="1000012">羊绒衫</a>
                                                <a href="/category?catidList=1739" target="_blank" data-position-id="1000012">背心吊带</a>
                                                <a href="/category?catidList=1423" target="_blank" data-position-id="1000012">短裤</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1433" target="_blank" data-position-id="1000012">男装</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1449" target="_blank" data-position-id="1000012">羽绒服</a>
                                                <a href="/category?catidList=1441" target="_blank" data-position-id="1000012">大衣风衣</a>
                                                <a href="/category?catidList=1437" target="_blank" data-position-id="1000012">棉服</a>
                                                <a href="/category?catidList=1440" target="_blank" data-position-id="1000012">夹克</a>
                                                <a href="/category?catidList=1460" target="_blank" data-position-id="1000012">针织衫</a>
                                                <a href="/category?catidList=1462" target="_blank" data-position-id="1000012">毛衣</a>
                                                <a href="/category?catidList=1435" target="_blank" data-position-id="1000012">T恤</a>
                                                <a href="/category?catidList=1452" target="_blank" data-position-id="1000012">卫衣</a>
                                                <a href="/category?catidList=1448" target="_blank" data-position-id="1000012">休闲裤</a>
                                                <a href="/category?catidList=1446" target="_blank" data-position-id="1000012">牛仔裤</a>
                                                <a href="/category?catidList=1456" target="_blank" data-position-id="1000012">西服</a>
                                                <a href="/category?catidList=1459" target="_blank" data-position-id="1000012">西裤</a>
                                                <a href="/category?catidList=1436" target="_blank" data-position-id="1000012">衬衫</a>
                                                <a href="/category?catidList=1445" target="_blank" data-position-id="1000012">马甲</a>
                                                <a href="/category?catidList=1463" target="_blank" data-position-id="1000012">羊绒衫</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1468" target="_blank" data-position-id="1000012">内衣袜品</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1470" target="_blank" data-position-id="1000012">文胸</a>
                                                <a href="/category?catidList=1473" target="_blank" data-position-id="1000012">吊带背心</a>
                                                <a href="/category?catidList=1474" target="_blank" data-position-id="1000012">保暖内衣</a>
                                                <a href="/category?catidList=1478" target="_blank" data-position-id="1000012">棉袜</a>
                                                <a href="/category?catidList=1480" target="_blank" data-position-id="1000012">家居睡衣</a>
                                                <a href="/category?catidList=1485" target="_blank" data-position-id="1000012">内裤</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1464" target="_blank" data-position-id="1000012">服饰配件</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1466" target="_blank" data-position-id="1000012">帽子</a>
                                                <a href="/category?catidList=1467" target="_blank" data-position-id="1000012">围巾丝巾</a>
                                            </div>

                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="sub-menu-item">
                                <h3>鞋靴箱包</h3>
                                <div class="second-menu-wapper">
                                    <a href="/category?catidList=1511" target="_blank" data-position-id="1000012">女鞋</a>
                                    <a href="/category?catidList=1493" target="_blank" data-position-id="1000012">男鞋</a>
                                    <a href="/category?catidList=1534" target="_blank" data-position-id="1000012">箱包皮具</a>
                                </div>
                                <div class="third-menu-container">
                                    <ul>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1511" target="_blank" data-position-id="1000012">女鞋</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1518" target="_blank" data-position-id="1000012">靴子</a>
                                                <a href="/category?catidList=1523" target="_blank" data-position-id="1000012">单鞋</a>
                                                <a href="/category?catidList=1513" target="_blank" data-position-id="1000012">休闲鞋</a>
                                                <a href="/category?catidList=1519" target="_blank" data-position-id="1000012">单靴</a>
                                                <a href="/category?catidList=1526" target="_blank" data-position-id="1000012">高跟鞋</a>
                                                <a href="/category?catidList=1531" target="_blank" data-position-id="1000012">坡跟鞋</a>
                                                <a href="/category?catidList=1520" target="_blank" data-position-id="1000012">棉靴</a>
                                                <a href="/category?catidList=1514" target="_blank" data-position-id="1000012">轻运动</a>
                                                <a href="/category?catidList=1524" target="_blank" data-position-id="1000012">平底鞋</a>
                                                <a href="/category?catidList=1532" target="_blank" data-position-id="1000012">软底鞋</a>
                                                <a href="/category?catidList=1521" target="_blank" data-position-id="1000012">雪地靴</a>
                                                <a href="/category?catidList=1528" target="_blank" data-position-id="1000012">增高鞋</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1493" target="_blank" data-position-id="1000012">男鞋</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1495" target="_blank" data-position-id="1000012">休闲鞋</a>
                                                <a href="/category?catidList=1503" target="_blank" data-position-id="1000012">靴子</a>
                                                <a href="/category?catidList=1494" target="_blank" data-position-id="1000012">正装鞋</a>
                                                <a href="/category?catidList=1496" target="_blank" data-position-id="1000012">商务休闲鞋</a>
                                                <a href="/category?catidList=1504" target="_blank" data-position-id="1000012">单靴</a>
                                                <a href="/category?catidList=1507" target="_blank" data-position-id="1000012">棉靴</a>
                                                <a href="/category?catidList=1509" target="_blank" data-position-id="1000012">舒适鞋</a>
                                                <a href="/category?catidList=1499" target="_blank" data-position-id="1000012">功能鞋</a>
                                                <a href="/category?catidList=1498" target="_blank" data-position-id="1000012">工装鞋</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1534" target="_blank" data-position-id="1000012">箱包皮具</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1535" target="_blank" data-position-id="1000012">拉杆箱</a>
                                                <a href="/category?catidList=1538" target="_blank" data-position-id="1000012">精品男包</a>
                                                <a href="/category?catidList=1542" target="_blank" data-position-id="1000012">电脑包</a>
                                                <a href="/category?catidList=1543" target="_blank" data-position-id="1000012">时尚女包</a>
                                                <a href="/category?catidList=1546" target="_blank" data-position-id="1000012">女双肩包</a>
                                                <a href="/category?catidList=1547" target="_blank" data-position-id="1000012">皮具钱包</a>
                                                <a href="/category?catidList=1548" target="_blank" data-position-id="1000012">腰带/礼盒</a>
                                                <a href="/category?catidList=1544" target="_blank" data-position-id="1000012">单肩包</a>
                                                <a href="/category?catidList=1545" target="_blank" data-position-id="1000012">手提包</a>
                                                <a href="/category?catidList=1540" target="_blank" data-position-id="1000012">单肩斜挎包</a>
                                                <a href="/category?catidList=1539" target="_blank" data-position-id="1000012">商务公文包</a>
                                                <a href="/category?catidList=1541" target="_blank" data-position-id="1000012">男双肩包</a>
                                            </div>

                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="sub-menu-item">
                                <h3>美妆珠宝</h3>
                                <div class="second-menu-wapper">
                                    <a href="/category?catidList=1125" target="_blank" data-position-id="1000012">面部护肤</a>
                                    <a href="/category?catidList=1142" target="_blank" data-position-id="1000012">彩妆</a>
                                    <a href="/category?catidList=1060" target="_blank" data-position-id="1000012">珠宝首饰</a>
                                    <a href="/category?catidList=1185" target="_blank" data-position-id="1000012">个人护理</a>
                                </div>
                                <div class="third-menu-container">
                                    <ul>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1125" target="_blank" data-position-id="1000012">面部护肤</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1126" target="_blank" data-position-id="1000012">面霜乳液</a>
                                                <a href="/category?catidList=1132" target="_blank" data-position-id="1000012">面膜</a>
                                                <a href="/category?catidList=1137" target="_blank" data-position-id="1000012">化妆水/爽肤水</a>
                                                <a href="/category?catidList=1133" target="_blank" data-position-id="1000012">面部精华</a>
                                                <a href="/category?catidList=1138" target="_blank" data-position-id="1000012">眼部护理</a>
                                                <a href="/category?catidList=1139" target="_blank" data-position-id="1000012">防晒</a>
                                                <a href="/category?catidList=1134" target="_blank" data-position-id="1000012">洁面卸妆</a>
                                                <a href="/category?catidList=1141" target="_blank" data-position-id="1000012">套装</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1142" target="_blank" data-position-id="1000012">彩妆</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1143" target="_blank" data-position-id="1000012">BB霜</a>
                                                <a href="/category?catidList=1144" target="_blank" data-position-id="1000012">底妆遮瑕</a>
                                                <a href="/category?catidList=1153" target="_blank" data-position-id="1000012">唇膏唇彩</a>
                                                <a href="/category?catidList=1161" target="_blank" data-position-id="1000012">睫毛膏/增长液</a>
                                                <a href="/category?catidList=1158" target="_blank" data-position-id="1000012">眼影眼线</a>
                                                <a href="/category?catidList=1157" target="_blank" data-position-id="1000012">眉笔/眉粉</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1060" target="_blank" data-position-id="1000012">珠宝首饰</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1061" target="_blank" data-position-id="1000012">黄金K金</a>
                                                <a href="/category?catidList=1062" target="_blank" data-position-id="1000012">铂金</a>
                                                <a href="/category?catidList=1067" target="_blank" data-position-id="1000012">钻石</a>
                                                <a href="/category?catidList=1068" target="_blank" data-position-id="1000012">珍珠</a>
                                                <a href="/category?catidList=1072" target="_blank" data-position-id="1000012">时尚饰品</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1185" target="_blank" data-position-id="1000012">个人护理</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1186" target="_blank" data-position-id="1000012">美发</a>
                                                <a href="/category?catidList=1204" target="_blank" data-position-id="1000012">沐浴洗手</a>
                                                <a href="/category?catidList=1194" target="_blank" data-position-id="1000012">口腔护理</a>
                                                <a href="/category?catidList=1200" target="_blank" data-position-id="1000012">女生护理</a>
                                                <a href="/category?catidList=1223" target="_blank" data-position-id="1000012">成人用品</a>
                                                <a href="/category?catidList=1210" target="_blank" data-position-id="1000012">美体塑形</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1176" target="_blank" data-position-id="1000012">男士专区</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1177" target="_blank" data-position-id="1000012">护肤</a>
                                                <a href="/category?catidList=1178" target="_blank" data-position-id="1000012">洁面</a>
                                                <a href="/category?catidList=1184" target="_blank" data-position-id="1000012">套装</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1227" target="_blank" data-position-id="1000012">香水</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1228" target="_blank" data-position-id="1000012">女香</a>
                                                <a href="/category?catidList=1229" target="_blank" data-position-id="1000012">男香</a>
                                                <a href="/category?catidList=1230" target="_blank" data-position-id="1000012">中性</a>
                                                <a href="/category?catidList=1231" target="_blank" data-position-id="1000012">礼盒</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1054" target="_blank" data-position-id="1000012">腕表</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1055" target="_blank" data-position-id="1000012">男士手表</a>
                                                <a href="/category?catidList=1056" target="_blank" data-position-id="1000012">女士手表</a>
                                                <a href="/category?catidList=1057" target="_blank" data-position-id="1000012">情侣手表</a>
                                                <a href="/category?catidList=1059" target="_blank" data-position-id="1000012">学生儿童表</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1087" target="_blank" data-position-id="1000012">眼镜礼品</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1088" target="_blank" data-position-id="1000012">太阳镜</a>
                                                <a href="/category?catidList=1089" target="_blank" data-position-id="1000012">眼镜</a>
                                                <a href="/category?catidList=1119" target="_blank" data-position-id="1000012">礼品文具</a>
                                            </div>

                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="sub-menu-item">
                                <h3>运动户外</h3>
                                <div class="second-menu-wapper">
                                    <a href="/category?catidList=903" target="_blank" data-position-id="1000012">运动服饰</a>
                                    <a href="/category?catidList=887" target="_blank" data-position-id="1000012">运动鞋包</a>
                                    <a href="/category?catidList=937" target="_blank" data-position-id="1000012">户外鞋服</a>
                                    <a href="/category?catidList=990" target="_blank" data-position-id="1000012">运动/户外用品</a>
                                </div>
                                <div class="third-menu-container">
                                    <ul>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=903" target="_blank" data-position-id="1000012">运动服饰</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=935" target="_blank" data-position-id="1000012">卫衣/套头衫</a>
                                                <a href="/category?catidList=906" target="_blank" data-position-id="1000012">夹克/风衣</a>
                                                <a href="/category?catidList=913" target="_blank" data-position-id="1000012">运动裤/裙</a>
                                                <a href="/category?catidList=922" target="_blank" data-position-id="1000012">运动配饰</a>
                                                <a href="/category?catidList=921" target="_blank" data-position-id="1000012">棉服</a>
                                                <a href="/category?catidList=936" target="_blank" data-position-id="1000012">羽绒服</a>
                                                <a href="/category?catidList=905" target="_blank" data-position-id="1000012">T恤</a>
                                                <a href="/category?catidList=920" target="_blank" data-position-id="1000012">毛衫/线衫</a>
                                                <a href="/category?catidList=925" target="_blank" data-position-id="1000012">训练/球服</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=887" target="_blank" data-position-id="1000012">运动鞋包</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=888" target="_blank" data-position-id="1000012">跑步鞋</a>
                                                <a href="/category?catidList=889" target="_blank" data-position-id="1000012">休闲/板鞋</a>
                                                <a href="/category?catidList=891" target="_blank" data-position-id="1000012">篮球鞋</a>
                                                <a href="/category?catidList=898" target="_blank" data-position-id="1000012">运动包</a>
                                                <a href="/category?catidList=894" target="_blank" data-position-id="1000012">足球鞋</a>
                                                <a href="/category?catidList=895" target="_blank" data-position-id="1000012">乒羽网鞋</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=937" target="_blank" data-position-id="1000012">户外鞋服</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=942" target="_blank" data-position-id="1000012">冲锋衣裤</a>
                                                <a href="/category?catidList=938" target="_blank" data-position-id="1000012">羽绒/棉服</a>
                                                <a href="/category?catidList=969" target="_blank" data-position-id="1000012">抓绒/软壳</a>
                                                <a href="/category?catidList=956" target="_blank" data-position-id="1000012">速干衣裤</a>
                                                <a href="/category?catidList=968" target="_blank" data-position-id="1000012">风衣/皮肤衣</a>
                                                <a href="/category?catidList=952" target="_blank" data-position-id="1000012">滑雪服</a>
                                                <a href="/category?catidList=973" target="_blank" data-position-id="1000012">户外配饰</a>
                                                <a href="/category?catidList=982" target="_blank" data-position-id="1000012">登山/越野鞋</a>
                                                <a href="/category?catidList=985" target="_blank" data-position-id="1000012">雪地靴</a>
                                                <a href="/category?catidList=984" target="_blank" data-position-id="1000012">休闲鞋</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=990" target="_blank" data-position-id="1000012">运动/户外用品</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=991" target="_blank" data-position-id="1000012">户外包</a>
                                                <a href="/category?catidList=1000" target="_blank" data-position-id="1000012">帐篷睡袋</a>
                                                <a href="/category?catidList=1005" target="_blank" data-position-id="1000012">户外装备</a>
                                                <a href="/category?catidList=1028" target="_blank" data-position-id="1000012">骑行运动</a>
                                                <a href="/category?catidList=1031" target="_blank" data-position-id="1000012">健身器材</a>
                                                <a href="/category?catidList=1004" target="_blank" data-position-id="1000012">野餐烧烤</a>
                                                <a href="/category?catidList=1017" target="_blank" data-position-id="1000012">球类</a>
                                                <a href="/category?catidList=1027" target="_blank" data-position-id="1000012">轮滑/滑板</a>
                                                <a href="/category?catidList=1021" target="_blank" data-position-id="1000012">游泳用品</a>
                                            </div>

                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="sub-menu-item">
                                <h3>数码家电</h3>
                                <div class="second-menu-wapper">
                                    <a href="/category?catidList=1550" target="_blank" data-position-id="1000012">手机通讯</a>
                                    <a href="/category?catidList=1597" target="_blank" data-position-id="1000012">数码产品</a>
                                    <a href="/category?catidList=1559" target="_blank" data-position-id="1000012">智能产品</a>
                                    <a href="/category?catidList=1570" target="_blank" data-position-id="1000012">电脑办公</a>
                                </div>
                                <div class="third-menu-container">
                                    <ul>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1550" target="_blank" data-position-id="1000012">手机通讯</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1551" target="_blank" data-position-id="1000012">手机</a>
                                                <a href="/category?catidList=1552" target="_blank" data-position-id="1000012">移动电源</a>
                                                <a href="/category?catidList=1553" target="_blank" data-position-id="1000012">手机配件</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1597" target="_blank" data-position-id="1000012">数码产品</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1598" target="_blank" data-position-id="1000012">摄影摄像</a>
                                                <a href="/category?catidList=1617" target="_blank" data-position-id="1000012">影音娱乐</a>
                                                <a href="/category?catidList=1605" target="_blank" data-position-id="1000012">耳机/耳麦</a>
                                                <a href="/category?catidList=1620" target="_blank" data-position-id="1000012">音箱音响</a>
                                                <a href="/category?catidList=1612" target="_blank" data-position-id="1000012">电子教育</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1559" target="_blank" data-position-id="1000012">智能产品</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1560" target="_blank" data-position-id="1000012">智能穿戴</a>
                                                <a href="/category?catidList=1567" target="_blank" data-position-id="1000012">智能拍摄</a>
                                                <a href="/category?catidList=1744" target="_blank" data-position-id="1000012">无人机</a>
                                                <a href="/category?catidList=1566" target="_blank" data-position-id="1000012">健康监测</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1570" target="_blank" data-position-id="1000012">电脑办公</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1571" target="_blank" data-position-id="1000012">笔记本电脑</a>
                                                <a href="/category?catidList=1573" target="_blank" data-position-id="1000012">台式机</a>
                                                <a href="/category?catidList=1572" target="_blank" data-position-id="1000012">平板电脑</a>
                                                <a href="/category?catidList=1587" target="_blank" data-position-id="1000012">办公设备</a>
                                                <a href="/category?catidList=1589" target="_blank" data-position-id="1000012">投影仪</a>
                                                <a href="/category?catidList=1584" target="_blank" data-position-id="1000012">路由器</a>
                                                <a href="/category?catidList=1576" target="_blank" data-position-id="1000012">鼠标键盘</a>
                                                <a href="/category?catidList=1586" target="_blank" data-position-id="1000012">游戏设备</a>
                                                <a href="/category?catidList=1574" target="_blank" data-position-id="1000012">电脑配件</a>
                                                <a href="/category?catidList=1581" target="_blank" data-position-id="1000012">移动硬盘</a>
                                                <a href="/category?catidList=1580" target="_blank" data-position-id="1000012">固态硬盘</a>
                                                <a href="/category?catidList=1582" target="_blank" data-position-id="1000012">U盘</a>
                                                <a href="/category?catidList=1583" target="_blank" data-position-id="1000012">存储卡</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1621" target="_blank" data-position-id="1000012">厨房电器</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1622" target="_blank" data-position-id="1000012">电压力锅</a>
                                                <a href="/category?catidList=1623" target="_blank" data-position-id="1000012">电饭煲</a>
                                                <a href="/category?catidList=1624" target="_blank" data-position-id="1000012">豆浆机</a>
                                                <a href="/category?catidList=1625" target="_blank" data-position-id="1000012">咖啡机</a>
                                                <a href="/category?catidList=1626" target="_blank" data-position-id="1000012">微波炉</a>
                                                <a href="/category?catidList=1627" target="_blank" data-position-id="1000012">料理/榨汁机</a>
                                                <a href="/category?catidList=1628" target="_blank" data-position-id="1000012">电烤箱</a>
                                                <a href="/category?catidList=1629" target="_blank" data-position-id="1000012">电磁炉</a>
                                                <a href="/category?catidList=1630" target="_blank" data-position-id="1000012">电水壶</a>
                                                <a href="/category?catidList=1631" target="_blank" data-position-id="1000012">电饼铛</a>
                                                <a href="/category?catidList=1634" target="_blank" data-position-id="1000012">面包机</a>
                                                <a href="/category?catidList=1632" target="_blank" data-position-id="1000012">电火锅</a>
                                                <a href="/category?catidList=1633" target="_blank" data-position-id="1000012">电炖锅</a>
                                                <a href="/category?catidList=1636" target="_blank" data-position-id="1000012">净水器</a>
                                                <a href="/category?catidList=1745" target="_blank" data-position-id="1000012">其它厨房</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1653" target="_blank" data-position-id="1000012">生活电器</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1661" target="_blank" data-position-id="1000012">扫地机</a>
                                                <a href="/category?catidList=1662" target="_blank" data-position-id="1000012">吸尘器</a>
                                                <a href="/category?catidList=1740" target="_blank" data-position-id="1000012">擦窗机器人</a>
                                                <a href="/category?catidList=1665" target="_blank" data-position-id="1000012">插座</a>
                                                <a href="/category?catidList=1658" target="_blank" data-position-id="1000012">取暖器</a>
                                                <a href="/category?catidList=1659" target="_blank" data-position-id="1000012">加湿器</a>
                                                <a href="/category?catidList=1660" target="_blank" data-position-id="1000012">净化器</a>
                                                <a href="/category?catidList=1664" target="_blank" data-position-id="1000012">挂烫机</a>
                                                <a href="/category?catidList=1663" target="_blank" data-position-id="1000012">电熨斗</a>
                                                <a href="/category?catidList=1666" target="_blank" data-position-id="1000012">其他生活家电</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1667" target="_blank" data-position-id="1000012">健康护理</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1694" target="_blank" data-position-id="1000012">按摩器</a>
                                                <a href="/category?catidList=1688" target="_blank" data-position-id="1000012">美体瘦身</a>
                                                <a href="/category?catidList=1668" target="_blank" data-position-id="1000012">剃须刀</a>
                                                <a href="/category?catidList=1669" target="_blank" data-position-id="1000012">口腔护理</a>
                                                <a href="/category?catidList=1673" target="_blank" data-position-id="1000012">电吹风</a>
                                                <a href="/category?catidList=1674" target="_blank" data-position-id="1000012">美发工具</a>
                                                <a href="/category?catidList=1678" target="_blank" data-position-id="1000012">美容工具</a>
                                                <a href="/category?catidList=1707" target="_blank" data-position-id="1000012">家用保健</a>
                                                <a href="/category?catidList=1706" target="_blank" data-position-id="1000012">足浴盆</a>
                                            </div>

                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="sub-menu-item">
                                <h3>家居家纺</h3>
                                <div class="second-menu-wapper">
                                    <a href="/category?catidList=694" target="_blank" data-position-id="1000012">厨房餐饮</a>
                                    <a href="/category?catidList=856" target="_blank" data-position-id="1000012">家纺软饰</a>
                                    <a href="/category?catidList=732" target="_blank" data-position-id="1000012">清洁收纳</a>
                                    <a href="/category?catidList=818" target="_blank" data-position-id="1000012">宠物生活</a>
                                </div>
                                <div class="third-menu-container">
                                    <ul>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=694" target="_blank" data-position-id="1000012">厨房餐饮</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=695" target="_blank" data-position-id="1000012">锅具</a>
                                                <a href="/category?catidList=708" target="_blank" data-position-id="1000012">烹饪勺铲</a>
                                                <a href="/category?catidList=711" target="_blank" data-position-id="1000012">刀剪砧板</a>
                                                <a href="/category?catidList=710" target="_blank" data-position-id="1000012">厨房配件</a>
                                                <a href="/category?catidList=728" target="_blank" data-position-id="1000012">保鲜收纳</a>
                                                <a href="/category?catidList=709" target="_blank" data-position-id="1000012">一次性用品</a>
                                                <a href="/category?catidList=713" target="_blank" data-position-id="1000012">烧烤烘焙</a>
                                                <a href="/category?catidList=712" target="_blank" data-position-id="1000012">餐具</a>
                                                <a href="/category?catidList=716" target="_blank" data-position-id="1000012">水具</a>
                                                <a href="/category?catidList=725" target="_blank" data-position-id="1000012">酒具</a>
                                                <a href="/category?catidList=726" target="_blank" data-position-id="1000012">咖啡具</a>
                                                <a href="/category?catidList=727" target="_blank" data-position-id="1000012">茶具</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=856" target="_blank" data-position-id="1000012">家纺软饰</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=857" target="_blank" data-position-id="1000012">床品套件</a>
                                                <a href="/category?catidList=860" target="_blank" data-position-id="1000012">床单/被罩</a>
                                                <a href="/category?catidList=866" target="_blank" data-position-id="1000012">被子/被芯</a>
                                                <a href="/category?catidList=867" target="_blank" data-position-id="1000012">床垫/床褥</a>
                                                <a href="/category?catidList=870" target="_blank" data-position-id="1000012">枕头/枕芯</a>
                                                <a href="/category?catidList=880" target="_blank" data-position-id="1000012">毛巾浴巾</a>
                                                <a href="/category?catidList=871" target="_blank" data-position-id="1000012">布艺软饰</a>
                                                <a href="/category?catidList=879" target="_blank" data-position-id="1000012">抱枕/靠垫</a>
                                                <a href="/category?catidList=865" target="_blank" data-position-id="1000012">毯子</a>
                                                <a href="/category?catidList=885" target="_blank" data-position-id="1000012">电热毯</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=732" target="_blank" data-position-id="1000012">清洁收纳</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=733" target="_blank" data-position-id="1000012">收纳整理</a>
                                                <a href="/category?catidList=737" target="_blank" data-position-id="1000012">清洁工具</a>
                                                <a href="/category?catidList=740" target="_blank" data-position-id="1000012">晾晒熨烫</a>
                                                <a href="/category?catidList=741" target="_blank" data-position-id="1000012">纸品湿巾</a>
                                                <a href="/category?catidList=747" target="_blank" data-position-id="1000012">衣物清洁</a>
                                                <a href="/category?catidList=738" target="_blank" data-position-id="1000012">洗护清洁剂</a>
                                                <a href="/category?catidList=751" target="_blank" data-position-id="1000012">雨伞雨具</a>
                                                <a href="/category?catidList=749" target="_blank" data-position-id="1000012">杀虫防霉</a>
                                                <a href="/category?catidList=750" target="_blank" data-position-id="1000012">净化除味</a>
                                                <a href="/category?catidList=748" target="_blank" data-position-id="1000012">皮具护理</a>
                                                <a href="/category?catidList=739" target="_blank" data-position-id="1000012">卫浴用具</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=818" target="_blank" data-position-id="1000012">宠物生活</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=819" target="_blank" data-position-id="1000012">宠物食物</a>
                                            </div>

                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="sub-menu-item">
                                <h3>母婴玩具</h3>
                                <div class="second-menu-wapper">
                                    <a href="/category?catidList=1377" target="_blank" data-position-id="1000012">奶粉</a>
                                    <a href="/category?catidList=1307" target="_blank" data-position-id="1000012">营养辅食</a>
                                    <a href="/category?catidList=1373" target="_blank" data-position-id="1000012">尿裤湿巾</a>
                                    <a href="/category?catidList=1385" target="_blank" data-position-id="1000012">洗护喂养</a>
                                </div>
                                <div class="third-menu-container">
                                    <ul>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1377" target="_blank" data-position-id="1000012">奶粉</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1378" target="_blank" data-position-id="1000012">婴幼儿奶粉</a>
                                                <a href="/category?catidList=1381" target="_blank" data-position-id="1000012">成人奶粉</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1307" target="_blank" data-position-id="1000012">营养辅食</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1308" target="_blank" data-position-id="1000012">米粉/菜粉</a>
                                                <a href="/category?catidList=1313" target="_blank" data-position-id="1000012">面条/粥</a>
                                                <a href="/category?catidList=1316" target="_blank" data-position-id="1000012">DHA</a>
                                                <a href="/category?catidList=1319" target="_blank" data-position-id="1000012">钙铁锌</a>
                                                <a href="/category?catidList=1323" target="_blank" data-position-id="1000012">维生素</a>
                                                <a href="/category?catidList=1325" target="_blank" data-position-id="1000012">宝宝零食</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1373" target="_blank" data-position-id="1000012">尿裤湿巾</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1374" target="_blank" data-position-id="1000012">纸尿裤</a>
                                                <a href="/category?catidList=1375" target="_blank" data-position-id="1000012">拉拉裤</a>
                                                <a href="/category?catidList=1376" target="_blank" data-position-id="1000012">湿巾</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1385" target="_blank" data-position-id="1000012">洗护喂养</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1395" target="_blank" data-position-id="1000012">宝宝护肤</a>
                                                <a href="/category?catidList=1394" target="_blank" data-position-id="1000012">宝宝洗浴</a>
                                                <a href="/category?catidList=1397" target="_blank" data-position-id="1000012">洗衣液/皂</a>
                                                <a href="/category?catidList=1386" target="_blank" data-position-id="1000012">奶瓶奶嘴</a>
                                                <a href="/category?catidList=1396" target="_blank" data-position-id="1000012">日常护理</a>
                                                <a href="/category?catidList=1389" target="_blank" data-position-id="1000012">餐具</a>
                                                <a href="/category?catidList=1390" target="_blank" data-position-id="1000012">水壶/水杯</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1259" target="_blank" data-position-id="1000012">婴童车床</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1263" target="_blank" data-position-id="1000012">婴儿手推车/学步车</a>
                                                <a href="/category?catidList=1260" target="_blank" data-position-id="1000012">汽车安全座椅</a>
                                                <a href="/category?catidList=1261" target="_blank" data-position-id="1000012">餐椅/摇椅</a>
                                                <a href="/category?catidList=1264" target="_blank" data-position-id="1000012">婴童户外骑行</a>
                                                <a href="/category?catidList=1262" target="_blank" data-position-id="1000012">婴儿床/儿童床</a>
                                                <a href="/category?catidList=1265" target="_blank" data-position-id="1000012">家居床品</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1326" target="_blank" data-position-id="1000012">婴童鞋服</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1327" target="_blank" data-position-id="1000012">套装</a>
                                                <a href="/category?catidList=1329" target="_blank" data-position-id="1000012">上衣</a>
                                                <a href="/category?catidList=1338" target="_blank" data-position-id="1000012">裤装</a>
                                                <a href="/category?catidList=1359" target="_blank" data-position-id="1000012">运动鞋服</a>
                                                <a href="/category?catidList=1340" target="_blank" data-position-id="1000012">羽绒服/棉服</a>
                                                <a href="/category?catidList=1348" target="_blank" data-position-id="1000012">童鞋</a>
                                                <a href="/category?catidList=1365" target="_blank" data-position-id="1000012">婴儿外出服</a>
                                                <a href="/category?catidList=1364" target="_blank" data-position-id="1000012">婴儿内衣</a>
                                                <a href="/category?catidList=1369" target="_blank" data-position-id="1000012">婴儿鞋帽袜</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1233" target="_blank" data-position-id="1000012">文娱玩具</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1239" target="_blank" data-position-id="1000012">遥控/电动</a>
                                                <a href="/category?catidList=1242" target="_blank" data-position-id="1000012">动漫玩具</a>
                                                <a href="/category?catidList=1252" target="_blank" data-position-id="1000012">益智玩具</a>
                                                <a href="/category?catidList=1243" target="_blank" data-position-id="1000012">积木拼插</a>
                                                <a href="/category?catidList=1234" target="_blank" data-position-id="1000012">DIY玩具</a>
                                                <a href="/category?catidList=1238" target="_blank" data-position-id="1000012">情景玩具</a>
                                                <a href="/category?catidList=1240" target="_blank" data-position-id="1000012">健身玩具</a>
                                                <a href="/category?catidList=1249" target="_blank" data-position-id="1000012">娃娃玩具</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=1266" target="_blank" data-position-id="1000012">妈咪专区</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=1272" target="_blank" data-position-id="1000012">防辐射服</a>
                                                <a href="/category?catidList=1267" target="_blank" data-position-id="1000012">文胸/内裤</a>
                                                <a href="/category?catidList=1270" target="_blank" data-position-id="1000012">孕妇装</a>
                                                <a href="/category?catidList=1292" target="_blank" data-position-id="1000012">孕期洗护</a>
                                                <a href="/category?catidList=1280" target="_blank" data-position-id="1000012">待产/新生</a>
                                            </div>

                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="sub-menu-item">
                                <h3>食品特产</h3>
                                <div class="second-menu-wapper">
                                    <a href="/category?catidList=430" target="_blank" data-position-id="1000012">休闲食品</a>
                                    <a href="/category?catidList=147" target="_blank" data-position-id="1000012">饮料冲调</a>
                                    <a href="/category?catidList=134" target="_blank" data-position-id="1000012">中外名酒</a>
                                    <a href="/category?catidList=117" target="_blank" data-position-id="1000012">茗茶</a>
                                </div>
                                <div class="third-menu-container">
                                    <ul>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=430" target="_blank" data-position-id="1000012">休闲食品</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=519" target="_blank" data-position-id="1000012">坚果炒货</a>
                                                <a href="/category?catidList=491" target="_blank" data-position-id="1000012">糖果/巧克力</a>
                                                <a href="/category?catidList=503" target="_blank" data-position-id="1000012">肉干肉脯</a>
                                                <a href="/category?catidList=431" target="_blank" data-position-id="1000012">饼干糕点</a>
                                                <a href="/category?catidList=440" target="_blank" data-position-id="1000012">蜜饯果干</a>
                                                <a href="/category?catidList=435" target="_blank" data-position-id="1000012">休闲零食</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=147" target="_blank" data-position-id="1000012">饮料冲调</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=161" target="_blank" data-position-id="1000012">咖啡/奶茶</a>
                                                <a href="/category?catidList=148" target="_blank" data-position-id="1000012">冲饮谷物</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=134" target="_blank" data-position-id="1000012">中外名酒</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=135" target="_blank" data-position-id="1000012">白酒</a>
                                                <a href="/category?catidList=141" target="_blank" data-position-id="1000012">葡萄酒</a>
                                                <a href="/category?catidList=142" target="_blank" data-position-id="1000012">收藏酒/陈年老酒</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=117" target="_blank" data-position-id="1000012">茗茶</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=122" target="_blank" data-position-id="1000012">红茶</a>
                                                <a href="/category?catidList=133" target="_blank" data-position-id="1000012">乌龙茶</a>
                                                <a href="/category?catidList=124" target="_blank" data-position-id="1000012">绿茶</a>
                                                <a href="/category?catidList=125" target="_blank" data-position-id="1000012">普洱</a>
                                                <a href="/category?catidList=118" target="_blank" data-position-id="1000012">养生茶</a>
                                                <a href="/category?catidList=1741" target="_blank" data-position-id="1000012">花草茶</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=14" target="_blank" data-position-id="1000012">食品保健</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=208" target="_blank" data-position-id="1000012">传统滋补</a>
                                                <a href="/category?catidList=210" target="_blank" data-position-id="1000012">蜂蜜/蜂产品</a>
                                                <a href="/category?catidList=16" target="_blank" data-position-id="1000012">蛋白质/氨基酸</a>
                                                <a href="/category?catidList=63" target="_blank" data-position-id="1000012">维生素/矿物质</a>
                                                <a href="/category?catidList=203" target="_blank" data-position-id="1000012">参类/灵芝类</a>
                                                <a href="/category?catidList=39" target="_blank" data-position-id="1000012">海洋生物类</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=304" target="_blank" data-position-id="1000012">粮油干货</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=305" target="_blank" data-position-id="1000012">方便食品</a>
                                                <a href="/category?catidList=373" target="_blank" data-position-id="1000012">熟食腊味</a>
                                                <a href="/category?catidList=381" target="_blank" data-position-id="1000012">调味品</a>
                                                <a href="/category?catidList=385" target="_blank" data-position-id="1000012">食用油</a>
                                            </div>

                                        </li>
                                        <li>
                                            <h3 class="second-title"><a href="/category?catidList=2" target="_blank" data-position-id="1000012">食品礼券</a></h3>
                                            <div class="sub-item">
                                                <a href="/category?catidList=6" target="_blank" data-position-id="1000012">蛋糕/面包券</a>
                                            </div>

                                        </li>
                                    </ul>
                                </div>
                            </li>

                        </ul>
                    </div>
                </li>
                <li class="main-menu-item"><a href="/" class="" data-position-id="1000010">首页</a></li>
<!--                 <li class="main-menu-item"><a href="/" class="">臻选</a></li> -->
<!--                 <li class="main-menu-item"><a href="/flpurchase" class="" target="_blank">闪购</a></li> -->
                <li class="main-menu-item"><a href="/brandStreet" class="" data-position-id="1000011">品牌街</a></li>
            </ul>

        </div>
    </div>
</div>

<script>

    $(document).ready(function(){
        require(['widget/header'], function (cart) {
            cart.init();
        });
    });

</script>

	<div class="product_container">


<div class="nav_position comWidth">
	<div class="nav" data-back-cat-id="16356">

			<a class="lm" href="/category?catidList=1398" data-id="1398" data-type="2" data-position-id="3000012">服装服饰
			</a>

			<span>&gt;</span>
			<a href="/category?catidList=1399" class="sm" data-id="1399" data-type="2" data-position-id="3000012">女装
			</a>
			<span>&gt;</span>
			<a href="/category?catidList=1410" class="sm" data-id="1410" data-type="2" data-position-id="3000012">裙装
			</a>
			<span>&gt;</span>
			<a href="/category?catidList=1411" class="sm" data-id="1411" data-type="1" data-position-id="3000012">连衣裙
			</a>
	</div>
	<div class="shop-position">
		<div class="shop-img">
			<a href="/shop?shopId=297" class="shop-img-wrap" target="_blank" data-position-id="3000022">
				<img src="/static/index/img/564b6f04c88d4840b81bc86dbbb68e55.gif" alt="badina服饰" title="badina服饰" onerror="this.src = '/img/widget/img_loading_450_450.png'; this.onerror = null; ">
			</a>
		</div>
		<div class="shop-line"></div>
		<div class="shop-detail" data-id="297">
			<a href="/shop?shopId=297" class="shop-tit-wrap" target="_blank" data-position-id="3000023">
				<h4 class="shop-tit">badina服饰</h4>
			</a>
			<div class="shop-cus J_talk" data-ucid="11118190" data-siteid="7481623" >
				<img class="custom-service" src="/static/index/img/custom_service2.gif"/>
				<span>客服</span>
			</div>
			<p class="shop-tel">0571-89195638</p>
		</div>
		<ul class="shop-section">
			<li class="go-to-shop">
				<a href="/shop?shopId=297" data-id="297" target="_blank" data-position-id="3000025">店铺</a>
			</li>
			<li class="vline-shop"></li>
			<li class="mark-shop">
				<a>收藏</a>
			</li>
		</ul>

	</div>



</div>

<div class="description_info comWidth">

	<div class="description clearfix">

		<div  id="mask"></div>
		<div id="big-show" class="comWidth">


    <div class="gallery-thumbs">

                    <div class="product-swiper-slide swiper-slide-active 0"  index="0">
                                <img src="/static/index/img/0f00057f9vzf15sfkcgpo0.jpg">
                        <span class="icon-four-corner"></span>
                    </div>
                    <div class="product-swiper-slide 1"   index="1">
                                <img src="/static/index/img/0f000c3lj8pn6tln0s9nn0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦">
                        <span class="icon-four-corner"></span>
                    </div>
                    <div class="product-swiper-slide 2"   index="2">
                                <img src="/static/index/img/0f000nzlyi7l6qmwbrnqd0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦">
                        <span class="icon-four-corner"></span>
                    </div>
                    <div class="product-swiper-slide 3"   index="3">
                                <img src="/static/index/img/0f0007zokeqypyjwqpg220.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦">
                        <span class="icon-four-corner"></span>
                    </div>
    </div>

    <div class="gallery-top product-swiper-container">
        <div class="product-swiper-wrapper">

                    <a class="product-swiper-slide 0 swiper-slide-active" >
                                <img src="/static/index/img/0f000c3lj_ln6tln0s9ny0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦">
                    </a>

                    <a class="product-swiper-slide 1" >
                                <img src="/static/index/img/0f000c3ljcjn6tln0s9nz0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦">
                    </a>

                    <a class="product-swiper-slide 2" >
                                <img src="/static/index/img/0f000nzlyfdl6qmwbrnqo0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦">
                    </a>

                    <a class="product-swiper-slide 3" >
                                <img src="/static/index/img/0f0007zokseypyjwqpg2q0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦">
                    </a>


        </div>




    </div>

        <div class="swiper-arrow arrow-next icon-arrow-right"></div>
        <div class="swiper-arrow arrow-prev icon-arrow-left"></div>
        <div class="mask-close icon-no"></div>








		</div>

		<div class="leftArea">



    <div class="product-swiper-container small-box gallery-top">
        <div id='float-box'></div>
        <div id="float-icon" class="icon-search"></div>

        <div class="product-swiper-wrapper">
                    <a class="product-swiper-slide 0 swiper-slide-active" >
                                <img src="/static/index/img/0f000c3lj_ln6tln0s9ny0.jpg" data-srcmi="http://ipcmm.baidu.com/media/v1/0f000c3lj_lN6Tln0s9ny0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦" >
                    </a>

                    <a class="product-swiper-slide 1" >
                                <img src="/static/index/img/0f000c3ljcjn6tln0s9nz0.jpg" data-srcmi="http://ipcmm.baidu.com/media/v1/0f000c3ljCJN6Tln0s9nZ0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦" >
                    </a>

                    <a class="product-swiper-slide 2" >
                                <img src="/static/index/img/0f000nzlyfdl6qmwbrnqo0.jpg" data-srcmi="http://ipcmm.baidu.com/media/v1/0f000nZlyfdl6QMWBrNQO0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦" >
                    </a>

                    <a class="product-swiper-slide 3" >
                                <img src="/static/index/img/0f0007zokseypyjwqpg2q0.jpg" data-srcmi="http://ipcmm.baidu.com/media/v1/0f0007ZokSeypYjWqPG2q0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦" >
                    </a>


        </div>

    </div>


    <div class="des_smimg gallery-thumbs">
                    <div class="product-swiper-slide swiper-slide-active 0"  index="0">
                                <img src="/static/index/img/0f00057f9vzf15sfkcgpo0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦" >
                        <span class="icon-four-corner"></span>
                    </div>
                    <div class="product-swiper-slide 1" index="1">
                                <img src="/static/index/img/0f000c3lj8pn6tln0s9nn0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦" >
                        <span class="icon-four-corner"></span>
                    </div>
                    <div class="product-swiper-slide 2" index="2">
                                <img src="/static/index/img/0f000nzlyi7l6qmwbrnqd0.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦" >
                        <span class="icon-four-corner"></span>
                    </div>
                    <div class="product-swiper-slide 3" index="3">
                                <img src="/static/index/img/0f0007zokeqypyjwqpg220.jpg" alt="芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦" >
                        <span class="icon-four-corner"></span>
                    </div>
    </div>










		<div class="share_set">
			<ul class="share_addition clearfix">
				<li>
					<div class="share_btn">
						<span class="share_icon icon-share"></span>
						<span class="share_des">分享</span>
					</div>
					<div id="bdshare-contain">
						<div class="bdsharebuttonbox" id="bdshare-box">
							<a href="#" class="bds_tsina icon-micro-blog" data-cmd="tsina" title="分享到新浪微博"></a>
							<a href="#" class="bds_tqq icon-tm-blog" data-cmd="tqq" title="分享到腾讯微博"></a>
							<a href="#" class="bds_douban icon-douban" data-cmd="douban" title="分享到豆瓣网"></a>
							<a href="#" class="bds_tieba icon-post-bar" data-cmd="tieba" title="分享到百度贴吧"></a>

						</div>
						<span class="big-tringle"></span>
						<span class="small-tringle"></span>
					</div>
				</li>
				<li>
					<a class="mark_btn">
						<span class="mark_icon icon-unfavorite2"></span>
						<span class="mark_icon icon-favorite"></span>
						<span class="mark_des">收藏</span>
					</a>
				</li>
			</ul>

		</div>



		</div>

		<div class="rightArea">
			<div class="des_content">

				<h1 class="des_content_tit" data-id="17170">芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦</h1>
				<p class="des_content_subtit">芭蒂娜2015欧洲站秋季新品 拼接长袖印花秋装a字连衣裙 修身显瘦</p>




					<div class="des_position">
						<div class="dl_position">
<dl class="clearfix price">
    <dt class="price_title" >价格</dt>
        <dd class="clearfix">
        <span class="price_yuan">￥</span>
        <span class="price_int">529</span>
        <span class="price_des">.00</span>
        <span class="price_cut_icon">4.6折</span>
        <span class="price_cut_yuan">￥</span>
        <span class="price_cut_money">1159.00</span>
    </dd>
</dl>
						</div>
					</div>

					<div class="des_down">
						<dl class="clearfix product-comment">
							<dt>商品评价</dt>
							<dd>
								<div class="score-star score-star-"></div>
							</dd>
						</dl>

						<dl class="clearfix delivery-panel" >
							<dt class="delivery">运费</dt>

<dd>
	<div class="postAge">
		<span class="deliveryAdd" title="浙江杭州">浙江杭州</span>
		<span>&nbsp;&nbsp;至</span>
		<span class="addr_tri">
			<span class="addr_tri_1" id="inputTest">选择收货地址</span>

			<i class="addr_icon icon-arrow-down4" id="inputIcon" ></i>

		</span>
		<div class="postAge-info">
				<span></span>
		</div>
	</div>
</dd>



	            		</dl>


		            			<dl class="clearfix para para0" >


										<dt class="para-select" data-pid="28"><span>颜色</span></dt>
									<dd class="clearfix ">
										<div class="para-dd">

												<div class="des_item " title="红印花" data-pid="28" data-vid="红印花" data-srcsi="http://ipcmm.baidu.com/media/v1/0f000AjobfdIN2MAoX7DO0.jpg" data-srcmi="http://ipcmm.baidu.com/media/v1/0f000FMoeNUFHhgM5dGZy0.jpg" data-srcli="http://ipcmm.baidu.com/media/v1/0f000FMoeReFHhgM5dGZf0.jpg" >
															<img class="color-img" title="红印花" src="/static/index/img/0f000ajobf7in2maox7dt0.jpg" alt="红印花"></img>

												</div>

										<div>
									</dd>
								</dl>

		            			<dl class="clearfix para para1" >


										<dt class="small-para-select" data-pid="41998"><span>尺码</span></dt>
									<dd class="clearfix ">
										<div class="para-dd">

											<div class="des_item des_item_sm " data-pid="41998" data-vid="2059"><span>S</span>
											</div>


											<div class="des_item des_item_sm " data-pid="41998" data-vid="2054"><span>M</span>
											</div>


											<div class="des_item des_item_sm " data-pid="41998" data-vid="2053"><span>L</span>
											</div>


											<div class="des_item des_item_sm " data-pid="41998" data-vid="18763"><span>XL</span>
											</div>


											<div class="des_item des_item_sm " data-pid="41998" data-vid="18764"><span>XXL</span>
											</div>

										<div>
									</dd>
								</dl>

					</div>

					<div class="book_up">
						<div class="des_input">
							<input type="text" id="des_num_text" value="1">
						</div>

						<div class="des_number">
							<div class="plus unselectable" unselectable="on">+</div>
							<hr/>
							<div class="reduction disable unselectable" unselectable="on">-</div>
						</div>
					</div>

					<div class="shop_buy">
						<a href="javascript:;" class="shopping_btn " data-position-id="3000017">立即购买</a><a href="javascript:;" class="buy_btn "><span class="buy_icon icon-shopping"></span><span class="buy_des">加入购物袋</span></a>
					</div>
					<div class="kc">
						<span>
						<span id="skuStock" class="hard_kc" data-value="2">仅剩2件</span>
						</span>
					</div>

					<div class="addition">
						<ul class="des_addition clearfix">
            <li>
                <a class="guarantee-option seven_days_return_btn" href="/footer/helpCenter/serviceGuarantee/seventDayReturn" target="_blank">
                    <i class="seven_days_return_icon icon-seven-day"></i>
                    <span class="seven_days_return_des content">七天无理由退换货</span>
                    <span class="desc tip">七天无理由退换货</span>
                    <span class="desc">所售商品支持“七天无理由退货”</span>
                </a>
            </li>

						</ul>
					</div>

			</div>
		</div>
		<div class="comWidth big-box-contain">
		    <div id="big-box">

		                        <img class="big-img big-img-show" data-id="0" src="/static/index/img/0f000c3ljvpn6tln0s9nf0.jpg" data-srcli="http://ipcmm.baidu.com/media/v1/0f000c3ljVpN6Tln0s9nf0.jpg" alt="http://ipcmm.baidu.com/media/v1/0f000c3ljVpN6Tln0s9nf0.jpg">
		                        <img class="big-img" data-id="1" src="/static/index/img/0f000c3ljg2n6tln0s9nk0.jpg" data-srcli="http://ipcmm.baidu.com/media/v1/0f000c3ljG2N6Tln0s9nK0.jpg" alt="http://ipcmm.baidu.com/media/v1/0f000c3ljG2N6Tln0s9nK0.jpg">
		                        <img class="big-img" data-id="2" src="/static/index/img/0f000nzlywnl6qmwbrnq40.jpg" data-srcli="http://ipcmm.baidu.com/media/v1/0f000nZlywNl6QMWBrNQ40.jpg" alt="http://ipcmm.baidu.com/media/v1/0f000nZlywNl6QMWBrNQ40.jpg">
		                        <img class="big-img" data-id="3" src="/static/index/img/0f0007zoksuypyjwqpg2o0.jpg" data-srcli="http://ipcmm.baidu.com/media/v1/0f0007ZokSUypYjWqPG2O0.jpg" alt="http://ipcmm.baidu.com/media/v1/0f0007ZokSUypYjWqPG2O0.jpg">
		    </div>

		</div>
	</div>
</div>
        <script>
            void function(e,t){for(var n=t.getElementsByTagName("img"),a=+new Date,i=[],o=function(){this.removeEventListener&&this.removeEventListener("load",o,!1),i.push({img:this,time:+new Date})},s=0;s<n.length;s++)!function(){var e=n[s];e.addEventListener?!e.complete&&e.addEventListener("load",o,!1):e.attachEvent&&e.attachEvent("onreadystatechange",function(){"complete"==e.readyState&&o.call(e,o)})}();alog("speed.set",{fsItems:i,fs:a})}(window,document);
        </script>
<div class="des_info comWidth clearfix">
	<div class="leftArea">
	</div>

	<div class="centerArea">
		<div class="product_detail_tit clearfix">
			<h3 class="product-detail-tab active" data-target="detail_wraper">商品详情</h3>
			<h3 class="product-comment-tab" data-target="product-comment-wrapper">商品评价</h3>
		</div>

		<div class="product-comment-wrapper tab-content-wrapper">
<div class="widget-loading">
    <span class="content">
        <img src="/static/index/img/loading.gif">
        <span class="text">正在加载，请稍后…</span>
    </span>
</div>
		</div>


		<div class="clearfix detail_wraper tab-content-wrapper">
			<div class="clearfix detail_set" >
				<ul id="">
						<li title="芬迪/FENDI">
						品牌：&nbsp;芬迪/FENDI
						</li>
						<li title="6534105100">
						货号：&nbsp;6534105100
						</li>
						<li title="涤纶">
						主要材质：&nbsp;涤纶
						</li>
						<li title="短裙">
						裙长：&nbsp;短裙
						</li>
						<li title="不对称">
						裙摆：&nbsp;不对称
						</li>
						<li title="圆领">
						领型：&nbsp;圆领
						</li>
						<li title="短袖">
						袖型：&nbsp;短袖
						</li>
						<li title="吊带">
						款式：&nbsp;吊带
						</li>
						<li title="修身型">
						版型：&nbsp;修身型
						</li>
						<li title="2016年">
						上市时间：&nbsp;2016年
						</li>
				</ul>
			</div>
			<div class="clearfix detail_contain">
				<div class="detail_content"><html> <head></head> <body>  <p><img class='lazy' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i2/854153843/TB2ZBiAepXXXXaaXXXXXXXXXXXX-854153843.jpg' align='absmiddle' /><img class='lazy' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i4/854153843/TB22U1fepXXXXbjXpXXXXXXXXXX-854153843.jpg' align='absmiddle' /></p>  <p><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i1/854153843/TB28YeGepXXXXXfXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i3/854153843/TB2uqpzeVXXXXcXXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i1/854153843/TB2OcqAepXXXXX4XXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i3/854153843/TB2i6ufepXXXXbmXpXXXXXXXXXX-854153843.jpg' /></p>  <p>&nbsp;</p>  <p><a target='_blank'><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i1/854153843/TB2_ZmsepXXXXcbXXXXXXXXXXXX-854153843.jpg' /></a><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i3/854153843/TB2HrSDepXXXXXTXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i4/854153843/TB2FbSoepXXXXcZXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i2/854153843/TB2Q.1yepXXXXanXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i2/854153843/TB2diKtepXXXXbYXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i2/854153843/TB2t_qaepXXXXcfXpXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i2/854153843/TB22ayCepXXXXX.XXXXXXXXXXXX-854153843.jpg' /></p>  <p><a target='_blank'><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i2/854153843/TB2z.CAepXXXXbfXXXXXXXXXXXX-854153843.jpg' /></a></p>  <p><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i3/854153843/TB2q5mjepXXXXajXpXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i1/854153843/TB2nTSsepXXXXbVXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i4/854153843/TB2ws5sepXXXXbTXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i1/854153843/TB2sjStepXXXXarXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i2/854153843/TB2H45mepXXXXcSXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i2/854153843/TB2gvygepXXXXbmXpXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i4/854153843/TB21_uuepXXXXbBXXXXXXXXXXXX-854153843.jpg' /><img class='lazy' align='absmiddle' data-original='http://malliccdn.baidu.com/https%3A//img.alicdn.com/imgextra/i1/854153843/TB24xeiepXXXXaLXpXXXXXXXXXX-854153843.jpg' /></p> </body></html></div>
			</div>
		</div>


	</div>
</div>
<div id="idStorage" data-shopid="297" data-userid="0" data-price="529.00" data-itemid="17170" data-skuid="94336" data-selectnum="1" data-skutype="0">
</div>



<script>
	var transSkuList = [{"imageId":89558,"infos":[{"pid":41998,"vid":2059},{"pid":28,"vname":"红印花"}],"itemId":17170,"outerId":"65341051007921","skuId":94336,"upc":"0","volume":0,"weight":0},{"imageId":89558,"infos":[{"pid":41998,"vid":2054},{"pid":28,"vname":"红印花"}],"itemId":17170,"outerId":"65341051007922","skuId":94337,"upc":"0","volume":0,"weight":0},{"imageId":89558,"infos":[{"pid":41998,"vid":2053},{"pid":28,"vname":"红印花"}],"itemId":17170,"outerId":"65341051007923","skuId":94338,"upc":"0","volume":0,"weight":0},{"imageId":89558,"infos":[{"pid":41998,"vid":18763},{"pid":28,"vname":"红印花"}],"itemId":17170,"outerId":"65341051007924","skuId":94339,"upc":"0","volume":0,"weight":0},{"imageId":89558,"infos":[{"pid":41998,"vid":18764},{"pid":28,"vname":"红印花"}],"itemId":17170,"outerId":"65341051007925","skuId":94340,"upc":"0","volume":0,"weight":0}];
</script>


<div class="tool-bar">
    <ul>
        <li class="custom-service J_talk" data-ucid="11118190" data-siteid="7481623">
            <div class="desc">商家<br>客服</div>
        </li>
        <li class="widget-tool-item icon-feedback2 btn-feedback" title="意见反馈">
            <div class="desc btn-feedback">意见反馈</div>
        </li>
        <li class="top icon-arrow-up">
            <div class="desc">回到<br>顶部</div>
        </li>
    </ul>
</div>
<script>
    require(['product/toolbar']);
</script>


	</div>

<div id="footer">

    <ul class="helper">
        <li>
            <div class="helper-item">
                <i class="helper-icon icon-diamond"></i>
                <h3>臻选品牌 正品保障</h3>
            </div>
        </li>
        <li>
            <div class="helper-item">
                <i class="helper-icon icon-crown"></i>
                <h3>新款推荐 引领潮流</h3>
            </div>
        </li>
        <li>
            <div class="helper-item">
                <i class="helper-icon icon-lamp"></i>
                <h3>创意个性 特色特惠</h3>
            </div>
        </li>
        <li>
            <div class="helper-item">
                <i class="helper-icon icon-flower"></i>
                <h3>优质服务 无忧购物</h3>
            </div>
        </li>
    </ul>

    <div class="footer-link">
        <ul>
            <li>
                <h3 class="title">
                    <a >服务保障</a>
                </h3>
                <p><a href="/footer/helpCenter/qualitySafeguard" data-potition-id="1000039" target="_blank">正品保障</a></p>
                <p><a href="/footer/helpCenter/returnService" data-potition-id="1000039" target="_blank">七天无理由退换货</a></p>
                <p><a href="/footer/helpCenter/returnPolicy" data-potition-id="1000039" target="_blank">退货政策</a></p>
                <p><a href="/footer/helpCenter/returnProcess" data-potition-id="1000039" target="_blank">退货流程</a></p>
            </li>
            <li>
                <h3 class="title">
                    <a >购物指南</a>
                </h3>
                <p><a class="register" href="javascript:" data-potition-id="1000040" target="_blank">免费注册</a></p>
                <p><a href="/footer/helpCenter/shoppingProcess" data-potition-id="1000040" target="_blank">购物流程</a></p>
                <p><a href="/footer/helpCenter/accountManagement" data-potition-id="1000040" target="_blank">账户管理</a></p>
                <p><a href="/footer/helpCenter/distributionMode" data-potition-id="1000040" target="_blank">配送方式</a></p>
                <p><a href="/footer/helpCenter/shoppingGuide/shoppingStep" data-potition-id="1000040" target="_blank">用户帮助</a></p>
            </li>
            <li>
                <h3 class="title">
                    <a >支付方式</a>
                </h3>
                <p><a href="/footer/helpCenter/onlinePayment" data-potition-id="1000041" target="_blank">在线支付</a></p>
                <p><a href="https://www.baifubao.com/" data-potition-id="1000041" target="_blank">百度钱包</a></p>
            </li>
            <li>
                <h3 class="title">
                    <a>商家服务</a>
                </h3>
                <p><a href="http://mallzs.baidu.com/#/home" data-potition-id="1000042" target="_blank">商家入驻</a></p>
                <p><a href="/footer/ruleCenter/rule" data-potition-id="1000042" target="_blank">规则中心</a></p>
                <p><a href="/footer/helpCenter/merchantsSettled" data-potition-id="1000042" target="_blank">商家帮助</a></p>
            </li>
            <li class="footer-follow">
                <h1 class="footer-logo">
                    <img src="/static/index/img/logo_reverse.png">
                </h1>
                <p class="slogan">百度旗下电商，为您提供值得信赖的品质服务</p>
                <div class="follow">
                    <span class="text">关注我们</span>
                    <i class="icon-weixin-logo icon-wechat">
                        <span class="two-dimension-code"></span>
                    </i>
                    <a  target="_blank"  href="http://weibo.com/baidumall2015" class="icon-weibo-logo icon-micro-blog">
                    </a>
                    <a href="http://tieba.baidu.com/f?ie=utf-8&kw=百度MALL" class="icon-weibo-logo icon-tieba" target="_blank">
                    </a>
                </div>
                <div class="feedback">
                    <span class="text">意见反馈</span>
                    <i class="icon-feedback btn-feedback"></i>
                </div>
            </li>
        </ul>
    </div>

    <div class="footer-copyright">
        <div>
            <a class="cop" href="http://www.miitbeian.gov.cn/state/outPortal/loginPortal.action" target="_blank">京ICP证030173号</a>
            <a class="cop" href="/footer/businessLicence" target="_blank">营业执照信息</a>
        </div>
        <p>©2015-2016 baidu.com版权所有</p>
    </div>
</div>

<script type="text/javascript" src="/static/index/js/cookie.js"></script>
<script type="text/javascript" src="/static/index/js/md5.js"></script>
<script type="text/javascript" src="/static/index/js/toolbar.js"></script>
<script type="text/javascript" src="/static/index/js/header.js"></script>
<script type="text/javascript" src="/static/index/js/product.js"></script>
<script type="text/javascript" src="/static/index/js/etpl.js"></script>
<script type="text/javascript" src="/static/index/js/alog.min.js"></script>
<script>
$(function () {
    require(['product/product']);

})
</script>
        <script>
        if ('7481623' !== '') {
            require(['common/md5'], function (md5) {
                var merchantSiteId = md5('7481623');
                clearBaiduTJ('7481623', merchantSiteId);
            });
        }
        </script>
        <script>
            window.alogObjectConfig = {
                product: '682',
                page: 'MALL-product',
                speed: {
                    sample: '1'
                },
                monkey: {
                    sample: '1'
                },
                exception: {
                    sample: '1'
                },
                feature: {
                    sample: '1'
                }
            };
            void function(a,b,c,d,e,f){function g(b){a.attachEvent?a.attachEvent("onload",b,!1):a.addEventListener&&a.addEventListener("load",b)}function h(a,c,d){d=d||15;var e=new Date;e.setTime((new Date).getTime()+1e3*d),b.cookie=a+"="+escape(c)+";path=/;expires="+e.toGMTString()}function i(a){var c=b.cookie.match(new RegExp("(^| )"+a+"=([^;]*)(;|$)"));return null!=c?unescape(c[2]):null}function j(){var a=i("PMS_JT");if(a){h("PMS_JT","",-1);try{a=a.match(/{["']s["']:(\d+),["']r["']:["']([\s\S]+)["']}/),a=a&&a[1]&&a[2]?{s:parseInt(a[1]),r:a[2]}:{}}catch(c){a={}}a.r&&b.referrer.replace(/#.*/,"")!=a.r||alog("speed.set","wt",a.s)}}if(a.alogObjectConfig){var k=a.alogObjectConfig.sample,l=a.alogObjectConfig.rand;if("https:"===a.location.protocol){if(d="https://gss2.bdstatic.com/70cFsjip0QIZ8tyhnq"+d,!k||!l)return}else d="http://img.baidu.com"+d;k&&l&&l>k||(g(function(){alog("speed.set","lt",+new Date),e=b.createElement(c),e.async=!0,e.src=d+"?v="+~(new Date/864e5),f=b.getElementsByTagName(c)[0],f.parentNode.insertBefore(e,f)}),j())}}(window,document,"script","/hunter/alog/dp.min.js");
        </script>
        <script>
            alog('speed.set', 'drt', +new Date);
        </script>
    </body>
</html>
