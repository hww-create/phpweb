<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"C:\wamp\www\tp5\application\app_extend\view\miaosha\index\index.html";i:1460901995;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
		欢迎使用百度商城微信扩展
</body>
</html>