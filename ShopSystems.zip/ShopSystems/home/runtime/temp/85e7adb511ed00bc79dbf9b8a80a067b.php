<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"C:\wamp\www\tp5\application\app_extend\view\tuangou\index\index.html";i:1460902053;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
		欢迎使用百度商城团购扩展
</body>
</html>