<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"E:\phpstudy\PHPTutorial\WWW\PHPweb\ShopSystems\home\index\view\index\index.html";i:1574262590;}*/ ?>
﻿<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
        <meta name="baidu-site-verification" content="ZEXvy8Xkma" />
        <link rel="dns-prefetch" href="//mallcmscdn.baidu.com">
        <link rel="dns-prefetch" href="//mallcdn.baidu.com">
        <link rel="dns-prefetch" href="//hm.baidu.com">
        <link rel="dns-prefetch" href="//bcscdn.baidu.com">
        <link rel="dns-prefetch" href="//bj.bcebos.com">

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>首页</title>
        <script>
            void function(g,f,j,c,h,d,b){g.alogObjectName=h,g[h]=g[h]||function(){(g[h].q=g[h].q||[]).push(arguments)},g[h].l=g[h].l||+new Date,d=f.createElement(j),d.async=!0,d.src=c,b=f.getElementsByTagName(j)[0],b.parentNode.insertBefore(d,b)}(window,document,"script","http://img.baidu.com/hunter/alog/alog.min.js","alog");void function(){function c(){return;}window.PDC={mark:function(a,b){alog("speed.set",a,b||+new Date);alog.fire&&alog.fire("mark")},init:function(a){alog("speed.set","options",a)},view_start:c,tti:c,page_ready:c}}();void function(n){var o=!1;n.onerror=function(n,e,t,c){var i=!0;return!e&&/^script error/i.test(n)&&(o?i=!1:o=!0),i&&alog("exception.send","exception",{msg:n,js:e,ln:t,col:c}),!1},alog("exception.on","catch",function(n){alog("exception.send","exception",{msg:n.msg,js:n.path,ln:n.ln,method:n.method,flag:"catch"})})}(window);
        </script>
<meta name="description" content="hww">
<meta name="keywords" content="hww">

        <link rel="shortcut icon" href="http://mallcdn.baidu.com/static/2016033051016/favicon.ico" >
        <script src="/static/index/js/core.js"></script>

        <script>
            require.config({
        'waitSeconds': 30,
        'baseUrl': 'http://mallcdn.baidu.com/static/2016033051016/js',
        'packages': [
            {
                'name': 'echarts',
                'location': '../dep/echarts/2.2.7/src',
                'main': 'echarts'
            },
            {
                'name': 'zrender',
                'location': '../dep/zrender/2.1.1/src',
                'main': 'zrender'
            }
        ]
    });
        </script>

<link rel="stylesheet" href="/static/index/css/style.css">

        <script>
        var cr = Math.floor(Math.random() * 99999);
        var activityId = '';
        var pageId = '1' ? '1' : 0;
        var rtTag = $.stringifyJSON({
    "ecom_page": {
        "page_type": "home"
    }
}
);

        // if (location.href.indexOf('mall.baidu.com') !== -1) {
            var _hmt = _hmt || [];
            var siteId = 'd64af1f3b8e241d56f0536501d4bfdd6';
            _hmt.push(['_setAccount', siteId]);
            _hmt.push(['_setAutoPageview', false]);

            if (rtTag) {
                _hmt.push(['_trackRTEvent', {
                    data: $.parseJSON(rtTag)
                }]);
            }

            trackPageViewTJ(siteId, '1', '');
            if ('' !== '') {
                require(['common/md5'], function (md5) {
                    var merchantSiteId = md5('');
                    _hmt.push(['_setAccount', merchantSiteId]);
                    _hmt.push(['_setAutoPageview', true]);
                    deployBaiduTJ(merchantSiteId);
                });
            // }
        }

        </script>
    </head>
    <script>
        alog('speed.set', 'ht', +new Date);
    </script>
    <body>
        <script>
            var GLOBAL_CONF = {"debug":false,"passport":{"host":"passport.baidu.com","tpl":"bdmall"},"site":{"siteId":7202944,"ucId":10914574}};
        </script>

<div class="home-container">



<div id="common-header" class="normal-header0">
    <div class="mini-header-search">
        <div class="container">
            <div class="user-info">
                <span class="common-login-info"></span>
            </div>
        </div>
    </div>



    <div class="nav-container">
        <div id="nav">
            <ul class="main-menu">
                <li class="main-menu-item all-category with-sub-menu">
                    <a href="javascript:"><i class="ui-icon-category icon-category"></i>全部商品分类</a>
                    <div class="sub-menu-container">
                        <ul class="">

                        <?php foreach($type as $data): ?>
                            <li class="sub-menu-item">
                                <h3><?php echo $data['name']; ?></h3>
                                <div class="second-menu-wapper">
                                    <?php foreach($data['child'] as $data2): ?>
                                                                                             <!--<?php echo $data2['name']; ?>-->
                                    <a href="/category?catidList=1399" target="_blank" data-position-id="1000012"></a>

                                    <?php endforeach; ?>
                                   
                                </div>
                                <div class="third-menu-container">
                                  <?php foreach($data['child'] as $data2): ?>
                                    <ul>
                                        <li>
                                       

                                            <h3 class="second-title"><a href="/index.php/index/index/lists?id=<?php echo $data2['id']; ?>" target="_blank" data-position-id="1000012"><?php echo $data2['name']; ?></a></h3>


                                            <div class="sub-item">
                                                <?php foreach($data2['child2'] as $data3): ?>
                                                    <a href="/index.php/index/index/lists?id=<?php echo $data3['id']; ?>" target="_blank" data-position-id="1000012"><?php echo $data3['name']; ?></a>
                                                <?php endforeach; ?>
                                              
                                            </div>

                                        </li>
                                       

                                       
                                    </ul>
                                     <?php endforeach; ?>
                                </div>
                            </li>
                            <?php endforeach; ?>
                              
                        </ul>
                            
                    </div>

                </li>
            </ul>

        </div>
    </div>
</div>


<script>

    $(document).ready(function(){
        require(['widget/header'], function (cart) {
            cart.init();
        });
    });

</script>
    <div class="currentTime" data-time="1460904652379"></div>

    <!--控制首页图片的大小-->
    <div class="slide-banner-container">
        <div class="row show-grid slide-banner clearfix">
            <div class="col-lg-2">
            </div>

            <div class="col-lg-8 slider-controller">
                <i class="swiper-button-prev icon-arrow-left" ></i>
                <i class="swiper-button-next icon-arrow-right"></i>
                <div class="swiper-pagination swiper-pagination-white">
                        <span class="swiper-pagination-switch"></span>
                        <span class="swiper-pagination-switch"></span>
                        <span class="swiper-pagination-switch"></span>
                        <span class="swiper-pagination-switch"></span>
                </div>
            </div>


        <div class="main-slider">
                <div class="slider-item-container" style="background-color: #f6dbee">
                        <div class="slider-img-container" data-color="#f6dbee">
                                <a href="http://mall.baidu.com/shop?shopId=563" target="_blank"  data-position-id="1000013">
                                        <img src="/static/index/img/88bcf08d532b3fdd92f95305f2b04e19.jpg@q_90,f_webp">
                                </a>
                        </div>
                </div>

                <div class="slider-item-container" style="background-color: #e8fbfa">
                        <div class="slider-img-container" data-color="#e8fbfa">
                                <a href="http://mall.baidu.com/promote?pageCode=camel" target="_blank"  data-position-id="1000013">
                                        <img src="/static/index/img/e20d646b43ac8c8a9170af3cb67eda29.jpg@q_90,f_webp">
                                </a>
                        </div>
                </div>

                <div class="slider-item-container" style="background-color: #bf90b4">
                        <div class="slider-img-container" data-color="#bf90b4">
                                <a href="http://mall.baidu.com/shop?shopId=740" target="_blank"  data-position-id="1000013">
                                        <img src="/static/index/img/8402f3bb8af88204c7d8ed6eaef749d5.jpg@q_90,f_webp">
                                </a>
                        </div>
                </div>

                <div class="slider-item-container" style="background-color: #000000">
                        <div class="slider-img-container" data-color="#000000">
                                <a href="http://mall.baidu.com/shop?shopId=55&amp;tr=cp.32_pr.71157" target="_blank"  data-position-id="1000013">
                                        <img src="/static/index/img/efcafd25439d88fce22360e572a16603.jpg@q_90,f_webp">
                                </a>
                        </div>
                </div>

        </div>

    </div>
    <script>
        void function(e,t){for(var n=t.getElementsByTagName("img"),a=+new Date,i=[],o=function(){this.removeEventListener&&this.removeEventListener("load",o,!1),i.push({img:this,time:+new Date})},s=0;s<n.length;s++)!function(){var e=n[s];e.addEventListener?!e.complete&&e.addEventListener("load",o,!1):e.attachEvent&&e.attachEvent("onreadystatechange",function(){"complete"==e.readyState&&o.call(e,o)})}();alog("speed.set",{fsItems:i,fs:a})}(window,document);
    </script>






        <div class="tool-bar">
            <ul>

                <!--<li class="major tool-item icon-crown2" data-type="major">-->
                    <!--<a href="#major" class="desc">今日<br>大牌</a>-->
                <!--</li>-->

                <!--<li class="immediate tool-item icon-star" data-type="immediate">-->
                    <!--<a href="#immediate" class="desc">每日<br>精选</a>-->
                <!--</li>-->

                <!--<li class="clothing tool-item icon-clothes" data-type="clothing">-->
                    <!--<a href="#clothing" class="desc">服装服饰</a>-->
                <!--</li>-->
                <!--<li class="bags tool-item icon-shoe" data-type="bags">-->
                    <!--<a href="#bags" class="desc">鞋包运动</a>-->
                <!--</li>-->
                <!--<li class="beauty tool-item icon-mirror" data-type="beauty">-->
                    <!--<a href="#beauty" class="desc">美妆珠宝</a>-->
                <!--</li>-->
                <!--<li class="domesitic tool-item icon-telephone" data-type="domesitic">-->
                    <!--<a href="#domesitic" class="desc">数码家电</a>-->
                <!--</li>-->
                <!--<li class="house tool-item icon-sofa" data-type="house">-->
                    <!--<a href="#house" class="desc">母婴家居</a>-->
                <!--</li>-->
                <!--<li class="food tool-item icon-plate" data-type="food">-->
                    <!--<a href="#food" class="desc">食品特产</a>-->
                <!--</li>-->

                <!--<li class="icon-feedback2 icon-arrow-up btn-feedback">-->
                    <!--<a href="javascript:void(0)" class="desc btn-feedback">意见<br>反馈</a>-->
                <!--</li>-->

                <!--<li class="top icon-arrow-up">-->
                    <!--<a href="#header" class="desc">回到<br>顶部</a>-->
                <!--</li>-->
            </ul>

        </div>

    </div>
</div>


<div id="footer">


    <div class="footer-link">


    </div>


<script type="text/javascript" src="/static/index/js/cookie.js"></script>
<script type="text/javascript" src="/static/index/js/header.js"></script>
<script type="text/javascript" src="/static/index/js/index.js"></script>
<script type="text/javascript" src="/static/index/js/etpl.js"></script>
<script type="text/javascript" src="http://mallcdn.baidu.com/static/2016033051016/js/common/cookie.js"></script>


<script>
$(function () {
        require(['index']);
})
</script>
        <script>
        if ('' !== '') {
            require(['common/md5'], function (md5) {
                var merchantSiteId = md5('');
                clearBaiduTJ('', merchantSiteId);
            });
        }
        </script>
        <script>
            window.alogObjectConfig = {
                product: '682',
                page: 'MALL-index',
                speed: {
                    sample: '1'
                },
                monkey: {
                    sample: '1'
                },
                exception: {
                    sample: '1'
                },
                feature: {
                    sample: '1'
                }
            };
            void function(a,b,c,d,e,f){function g(b){a.attachEvent?a.attachEvent("onload",b,!1):a.addEventListener&&a.addEventListener("load",b)}function h(a,c,d){d=d||15;var e=new Date;e.setTime((new Date).getTime()+1e3*d),b.cookie=a+"="+escape(c)+";path=/;expires="+e.toGMTString()}function i(a){var c=b.cookie.match(new RegExp("(^| )"+a+"=([^;]*)(;|$)"));return null!=c?unescape(c[2]):null}function j(){var a=i("PMS_JT");if(a){h("PMS_JT","",-1);try{a=a.match(/{["']s["']:(\d+),["']r["']:["']([\s\S]+)["']}/),a=a&&a[1]&&a[2]?{s:parseInt(a[1]),r:a[2]}:{}}catch(c){a={}}a.r&&b.referrer.replace(/#.*/,"")!=a.r||alog("speed.set","wt",a.s)}}if(a.alogObjectConfig){var k=a.alogObjectConfig.sample,l=a.alogObjectConfig.rand;if("https:"===a.location.protocol){if(d="https://gss2.bdstatic.com/70cFsjip0QIZ8tyhnq"+d,!k||!l)return}else d="http://img.baidu.com"+d;k&&l&&l>k||(g(function(){alog("speed.set","lt",+new Date),e=b.createElement(c),e.async=!0,e.src=d+"?v="+~(new Date/864e5),f=b.getElementsByTagName(c)[0],f.parentNode.insertBefore(e,f)}),j())}}(window,document,"script","/hunter/alog/dp.min.js");
        </script>
        <script>
            alog('speed.set', 'drt', +new Date);
        </script>
    </body>
</html>
