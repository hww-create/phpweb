<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"E:\phpstudy\PHPTutorial\WWW\PHPweb\ShopSystems\home\index\view\index\details.html";i:1574261337;}*/ ?>
!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>

</body>
</html>