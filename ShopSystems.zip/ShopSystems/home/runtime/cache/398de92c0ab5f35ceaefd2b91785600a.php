<?php
//000000000000a:4:{s:6:"fields";a:2:{i:0;s:2:"id";i:1;s:8:"filepath";}s:4:"bind";a:2:{s:2:"id";i:1;s:8:"filepath";i:2;}s:4:"type";a:2:{s:2:"id";s:16:"int(10) unsigned";s:8:"filepath";s:12:"varchar(255)";}s:2:"pk";s:2:"id";}
?>