<?php
//000000000000a:4:{s:6:"fields";a:5:{i:0;s:2:"id";i:1;s:4:"name";i:2;s:3:"pid";i:3;s:4:"path";i:4;s:5:"level";}s:4:"bind";a:5:{s:2:"id";i:1;s:4:"name";i:2;s:3:"pid";i:1;s:4:"path";i:2;s:5:"level";i:1;}s:4:"type";a:5:{s:2:"id";s:7:"int(10)";s:4:"name";s:12:"varchar(255)";s:3:"pid";s:7:"int(11)";s:4:"path";s:12:"varchar(255)";s:5:"level";s:8:"int(255)";}s:2:"pk";s:2:"id";}
?>