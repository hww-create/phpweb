<?php

namespace ItsDangerous\BadData;

class SignatureExpired extends BadTimeSignature {}
