<?php

namespace ItsDangerous\BadData;
use Exception;

class BadData extends Exception {}
