<?php

namespace app\test\model;

use think\Model;

class BannerImg extends Model
{
    
}

