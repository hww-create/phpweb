<?php
/**
 * 路由注册
 *
 * 以下代码为了尽量简单，没有使用路由分组
 * 实际上，使用路由分组可以简化定义
 * 并在一定程度上提高路由匹配的效率
 */

// 写完代码后对着路由表看，能否不看注释就知道这个接口的意义
use think\Route;

//Sample
Route::get('api/v1/sample/:key', 'api/v1.Sample/getSample');
Route::post('api/v1/sample/test3', 'api/v1.Sample/test3');



//Banner
//主页接口
Route::get('api/v1/banner/:id', 'api/v1.Banner/getBanner');



//Theme
//theme简要信息接口
Route::get('api/v1/theme', 'api/v1.Theme/getThemes');
//theme详情接口
Route::get('api/v1/theme/:id', 'api/v1.Theme/getComplexOne');
Route::post('api/v1/theme/:t_id/product/:p_id', 'api/v1.Theme/addThemeProduct');
Route::delete('api/v1/theme/:t_id/product/:p_id', 'api/v1.Theme/deleteThemeProduct');



//Product
//创建商品接口
Route::post('api/v1/product', 'api/v1.Product/createOne');
//删除商品接口
Route::delete('api/v1/product/:id', 'api/v1.Product/deleteOne');
//获取商品分类接口
Route::get('api/v1/product/by_category/paginate', 'api/v1.Product/getByCategory');
//分类商品接口
Route::get('api/v1/product/by_category', 'api/v1.Product/getAllInCategory');
//商品详情接口
Route::get('api/v1/product/:id', 'api/v1.Product/getOne',[],['id'=>'\d+']);
//最近新品接口
Route::get('api/v1/product/recent', 'api/v1.Product/getRecent');



//Category
//获取分类接口
Route::get('api/v1/category', 'api/v1.Category/getCategories');
//获取所有分类列表接口
Route::get('api/v1/category/all', 'api/v1.Category/getAllCategories');



//Token
Route::post('api/v1/token/user', 'api/v1.Token/getToken');
Route::post('api/v1/token/app', 'api/v1.Token/getAppToken');
Route::post('api/v1/token/verify', 'api/v1.Token/verifyToken');



//Address
Route::post('api/v1/address', 'api/v1.Address/createOrUpdateAddress');
Route::get('api/v1/address', 'api/v1.Address/getUserAddress');



//Order
//下单接口(下单是提交信息，所以用post)
Route::post('api/v1/order', 'api/v1.Order/placeOrder');
//订单详情接口  (可以)
Route::get('api/v1/order/:id', 'api/v1.Order/getDetail',[], ['id'=>'\d+']);
Route::put('api/v1/order/delivery', 'api/v1.Order/delivery');
//不想把所有查询都写在一起，所以增加by_user，很好的REST与RESTFul的区别
//订单信息分页查询接口 (可以)
Route::get('api/v1/order/by_user', 'api/v1.Order/getSummaryByUser');
Route::get('api/v1/order/paginate', 'api/v1.Order/getSummary');



//Pay
//微信预订单接口
Route::post('api/v1/pay/pre_order', 'api/v1.Pay/getPreOrder');
//给微信定义一个回调API的地址(接收微信通知的参数并且把参数转化到receiveNotify接口的接口)
Route::post('api/v1/pay/notify', 'api/v1.Pay/receiveNotify');
//微信转发接口
Route::post('api/v1/pay/re_notify', 'api/v1.Pay/redirectNotify');
Route::post('api/v1/pay/concurrency', 'api/v1.Pay/notifyConcurrency');



//Message
Route::post('api/v1/message/delivery', 'api/:version.Message/sendDeliveryMsg');






