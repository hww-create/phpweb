<?php


//Route::rule('路由表达式','路由地址','请求类型','路由参数(数组)','变量规则(数组)');
//Route::rule('hello','sample/Test/hello','GET|POST',['https'=>false]);

//这个:id是由客户端传过来的
//接口参数校验是很重要的(验证层)

use think\Route;


//版本1(banner) (可以)
Route::get('api/v1/banner/:id','api/v1.Banner/getBanner');



//theme简要信息接口
Route::get('api/v1/theme','api/v1.Theme/getSimpleList');
//theme详情接口
Route::get('api/v1/theme/:id','api/v1.Theme/getComplexOne');


//最近新品接口(recent) (可以)
Route::get('api/v1/product/recent','api/v1.Product/getRecent');
//分类商品接口
Route::get('api/v1/product/by_category','api/v1.Product/getAllProductInCategory');
//商品详情接口
Route::get('api/v1/product/:id','api/v1.Product/getProductDetail',[],['id'=>'\d+']);


//分类列表接口 (可以)
Route::get('api/v1/category/all','api/v1.Category/getAllCategories');


//Token接口(post安全性更高(把code参数放到post的body里面来传))
Route::post('api/v1/token/user','api/v1.Token/getToken');


//用户地址路由
Route::post('api/v1/address','api/v1.Address/createOrUpdateAddress');



//下单接口(下单是提交信息，所以用post)
Route::post('api/v1/order','api/v1.Order/placeOrder');
//订单详情接口  (可以)
Route::get('api/v1/order/:id','api/v1.Order/getOrderDetail',[],['id'=>'\d+']);
//订单信息分页查询接口 (可以)
Route::get('api/v1/order/by_user','api/v1.Order/getSummaryByUser');


//微信预订单接口
Route::post('api/v1/pay/pre_order','api/v1.Pay/getPreOrder');
//给微信定义一个回调API的地址(接收微信通知的参数并且把参数转化到receiveNotify接口的接口)
Route::post('api/v1/pay/notify','api/v1.Pay/receiveNotify');
//微信转发接口
Route::post('api/v1/pay/re_notify','api/v1.Pay/redirectNotify');








//动态版本
//Route::get('api/:version/banner/:id','api/:version.Banner/getBanner');



