<?php

//配置微信信息的文件
  return [
     'app_id'=>'',
     'app_secret'=>'',
     'login_url'=>"https://api.weixin.qq.com/sns/jscode2session?".
         "appid=%s&secret=%s&js_code=%s&grant_type=authorization_code"

  ];

//小程序的账号密码是在小程序账号后台的一个设置选项，然后在里面点开发设置获取
?>
