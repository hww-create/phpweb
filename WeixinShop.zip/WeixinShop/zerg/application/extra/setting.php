<?php

return[
    //
    'img_prefix'=>'http://weixin.com',
    //Token令牌失效时间
    'token_expire_in_time'=>7200

];

?>
