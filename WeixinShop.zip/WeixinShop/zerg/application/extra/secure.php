<?php

  return [
      'token_salt'=>'HHsTieBU377mJtKr',
      //微信回调路由的地址
      'pay_back_url'=>'www.weixin.com/index.php/api/v1/pay/notify'
  ];
?>
