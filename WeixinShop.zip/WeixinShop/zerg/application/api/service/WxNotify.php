<?php


namespace app\api\service;

use app\api\model\Product as ProductModel;
use app\lib\enmu\OrderStatusEnmu;
use think\Exception;
use think\Loader;
use app\api\model\Order as OrderModel;
use app\api\service\Order as OrderService;
use think\Log;

Loader::import('WxPay.WxPay',EXTEND_PATH,'Api.php');

 //微信处理回调类
class WxNotify extends \WxPayNotify
{

  //微信处理回调的方法入口 (重写了sdk类的NotifyProcess()方法)
  public function NotifyProcess($objData, $config, &$msg)
  {
      //处理支付成功的情况
      if($objData['result_code'] == 'SUCCESS')
      {

         //检测库存量
         //就把订单号从$objData里面取出来(out_trade_no为微信预订单的单号)
          $orderNO = $objData['out_trade_no'];
          try{
              //根据订单号把数据库的订单信息查询出来
              $order = OrderModel::where('order_no','=',$orderNO)
                    ->find();
              //如果订单没有被处理过，就做订单的库存量检测
              if($order->status == 1)
              {
                 $service = new OrderService();
                 $stockStatus=$service->checkOrderStock($order->id);//包含用户所购买的数量
                 //是否通过库存量的检测
                 if($stockStatus['pass']){
                     //更新订单状态
                     $this->updateOrderStatus($order->id,true);
                     //消减库存量
                     $this->reduceStock($stockStatus);
                 }
                 else{//已支付无内存
                     $this->updateOrderStatus($order->id,false);
                 }
              }
                 return true;
          }
          catch(Exception $ex){ //处理不成功出现异常，继续发送异步处理消息
              Log::error($ex);
                 return false;
          }
      }
  }


  //更新订单状态
  private function updateOrderStatus($orderID,$success)
  {
      //如果订单支付成功的状态
     $status = $success?
         OrderStatusEnmu::PAY :
         OrderStatusEnmu::PAY_BUT_OUT_OF;
     OrderModel::where('id','=',$orderID)
                ->update(['status'=>$status]);
  }


  //消减库存量方法
  private function reduceStock($stockStatus)
  {
      foreach($stockStatus['pStatusArray'] as $singlePStatus)
      {
         //库存量-订单商品数量 $singlePStatus['count']
         ProductModel::where('id','=',$singlePStatus['id'])
                     ->setDec('stock',$singlePStatus['count']);

      }
  }


}

?>
