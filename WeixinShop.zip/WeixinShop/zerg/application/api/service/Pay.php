<?php

namespace app\api\service;


use app\lib\enmu\OrderStatusEnmu;
use app\lib\exception\OrderMissException;
use app\lib\exception\TokenMissException;
use think\Exception;
use app\api\model\Order as OrderModel;
use app\api\service\Order as OrderService;
use think\Loader;
use think\Log;

//引用外部文件 url:(extend/WxPay/WxPay.Api.php)
Loader::import('WxPay.WxPay',EXTEND_PATH,'.Api.php');


class Pay
{
   private $orderID;
   private $orderNO;


   function __construct($orderID)
   {
       if(empty($orderID))
       {
         throw new Exception('订单号不允许为NULL');
       }
       else
       {
         $this->orderID = $orderID;
       }
   }


   //编写支付逻辑的主方法(也就是调用众多的副方法形成(可读性高))
   public function Pay()
   {
       /* 1.对传过来的订单号做三道检测
        *
        * (1)订单号可能根本就不存在
        * (2)订单号可能确实是存在的，但是，订单号和当前用户是不匹配的()
        * (3)订单有可能是被支付过得
        */
        $this->checkOrderValidate();
       //2.进行库存量检测
      $orderService = new OrderService();
      //返回订单的状态(把订单的id号传过)
      $status = $orderService->checkOrderStock($this->orderID);
      if(!$status['pass'])
      {
         return $status;
      }
       //3.微信预订单的生成
       return $this->makeWinxinPreOrder($status['orderPrice']);
   }






   //1.对订单号做三重检测的方法的封装方法
   private function checkOrderValidate()
   {
       //根据这个order表id查询出相应的订单号
       $order = OrderModel::where('id','=',$this->orderID)->find();
       if(!$order)
       {
           throw new OrderMissException([
               'msg'=>'订单不存在，请检查ID是否正确'
           ]);
       }
       //判断订单是否与当前用户相匹配
       if(!BaseToken::isValidateOperate($order->user_id)){
           throw new TokenMissException([
                'msg'=>'订单与用户不匹配！',
                'error'=>'10003'
           ]);
       }
       //判断订单是否被支付(调用自定义的枚举)
       if($order->status != OrderStatusEnmu::UNPAY)
       {
          throw new OrderMissException([
                  'msg'=>'订单已支付过啦',
                  'errorCode'=>'80003',
                  'code'=>'400'
          ]);
       }
         //以上三种情况都通过返回订单号
         $this->orderNO = $order->order_no;
         return true;
   }





    //3.做微信预订单的生成
    private function makeWinxinPreOrder($totalPrice)
    {
        //获取用户的身份标识openid(代表用户身份的id号)
        $openid = BaseToken::getCurrentTokenVar('openid');
        if(!$openid)
        {
            throw new TokenMissException();
        }
        //有了openid之后开始调用微信所提供的预订单的接口（WxPay.Data:统一下单输入对象）
         $wxOrderData = new \WxPayUnifiedOrder();
        //设置预订单号
         $wxOrderData->SetOut_trade_no($this->orderNO);
        //校验类型
         $wxOrderData->SetTrade_type('JSAPI');
        //设置订单的总金额
        $wxOrderData->SetTotal_fee($totalPrice*100);
        //商品简要描述
        $wxOrderData->SetBody('；零食商贩');
        //指定用户身份标识
        $wxOrderData->SetOpenid($openid);
        //接收微信的回调通知(异步通知)地址
        $wxOrderData->SetNotify_url(config('secure.pay_back_url'));
        //把这个对象$wxOrderData发送到预订单的接口里面去，就返回到一个签名的预订单结果
       return $this->getPaySignature($wxOrderData);
    }

    //把这个对象发送到预订单的接口里面去，就返回到一个签名的预订单结果 的方法
     private function getPaySignature($wxOrderData)
     {
          //接收微信的返回结果(完成微信接口的调用)
          $wxOrder = \WxPayApi::unifiedOrder($wxOrderData);
          if($wxOrder['return_code']!='SUCCESS'||
             $wxOrder['result_code']!='SUCCESS')
          {
             //就记录错误异常日志
             Log::record($wxOrder,'error');
             Log::record('获取预支付订单失败','error');
          }
          //(1)prepay_id:作用在于像用户推送一个模板消息(用于签名的模板消息)
           $this->recordPreOrder($wxOrder);
          //(2)sign:生成签名
           $signature = $this->sign($wxOrder);
           return $signature;
     }

     //(1)(prepay_id)编写给用户推送一个签名模板消息的方法
     private function recordPreOrder($wxOrder)
     {
        OrderModel::where('id','=',$this->orderID)
                 ->update(['prepay_id'=>$wxOrder['prepay_id']]);
     }

     //(2)(sign)生成签名的方法
      private function sign($wxOrder)
      {
          //重点：这个WxPayJsApiPay类里面有根据所设的参数生成签名的方法
          $jsApiPayData = new \WxPayJsApiPay();
          //把小程序的APPid传进来
          $jsApiPayData->SetAppid(config('wx.app_id'));
          //时间戳(要转化为时间戳)
          $jsApiPayData->SetTimeStamp((string)time());
          //生成随机字符串
          $rand = md5(time() . mt_rand(0,1000));
          $jsApiPayData->SetNonceStr($rand);
          //生成包
          $jsApiPayData->SetPackage('prepay_id='.$wxOrder['prepay_id']);
          //设置签名类型
          $jsApiPayData->SetSignType('md5');
          //使用签名
          $sign = $jsApiPayData->MakeSign();
          $rawValues['paySign'] = $sign;
 //调用这个GetValues()方法就是相当于这个对象会把我们所需要的一系列参数都转化为原始的rawValues(为数组)
          $rawValues = $jsApiPayData->GetValues();
          return $rawValues;
      }

}

?>
