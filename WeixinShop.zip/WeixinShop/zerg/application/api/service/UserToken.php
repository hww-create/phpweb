<?php


namespace app\api\service;


use app\lib\enmu\ScopeEnmu;
use app\lib\exception\TokenMissException;
use think\Exception;
use app\lib\exception\WechatLoginMissException;
use app\api\model\User as UserModel;

class UserToken extends BaseToken
{
    //客户端传来的code
    protected $code;
    //小程序app的id
    protected $weixinAppID;
    //小程序app的密码
    protected $weixinAppSecret;
    //小程序的路径(是微信提供给我们的api)
    protected $weixinLoginUrl;


    //定义构造方法重新定义变量
    function __construct($code)
    {
        $this->code = $code;
        $this->weixinAppID = config('weixin.app_id');
        $this->weixinAppSecret = config('weixin.app_secret');
        $this->weixinLoginUrl = sprintf(config('weixin.login_url'),
                              $this->weixinAppID,$this->weixinAppSecret,$this->code);
    }


    //写个业务逻辑提供给Token控制器的调用的方法
    //这个get方法是用来处理业务逻辑的
    public function get()
    {
        //这是调用公共文件common.php来获取微信的数据
        $result = curl_get($this->weixinLoginUrl);
        //将微信的数据对象转化为数组
        $weixinResult = json_encode($result,true);
        //如果获取数据为空
        if(empty($weixinResult)){
           throw new Exception('获取session_key及openID时异常,微信内部错误');
        }
        //就获取微信数据成功
        else{
            $loginFail = array_key_exists('errorcode',$weixinResult);
              //如果登录异常
              if($loginFail){
                 $this->processLoginError($weixinResult);
              }
              //如果登录正常，就给用户获取令牌
              else{
                return $this->grantToken($weixinResult);
              }
        }
    }





     //自定义异常封装方法
    private function processLoginError($weixinResult)
    {
           throw new WechatLoginMissException([
               'msg'=>$weixinResult,
               'errorCode'=>$weixinResult['error']
           ]);
    }

     //自定义颁发令牌方法
    private function grantToken($weixinResult)
    {
      //首先拿到从微信服务端传过来的openid
      $openid = $weixinResult['openid'];
      //数据库里看一下这个openid是不是已经存在
      $user = UserModel::getByOpenID($openid);
      //如果存在，则直接取出，如果不存在，那么新增一条user记录
      if($user){
           $uid = $user->id;
      }else{
           $uid = $this->newUser($openid);
      }
      //生成令牌，准备缓存数据，写入缓存
      //(value: weixinResult,uid,scope);(key:令牌 cachedValue)

        //接收缓存的方法
        $cachedValue = $this->prepareCachedValue($weixinResult,$uid);
      //把使用缓存生成的令牌返回到客户端去
        $token = $this->saveToCache($cachedValue);
        return $token;
    }



     //自定义从数据库新加id的方法
    private function newUser($openid)
    {
        $user = UserModel::create(['openid'=>$openid]);
        return $user;
    }


    

    //自定义一个接收缓存的方法(value)
    private function prepareCachedValue($weixinResult,$uid)
    {
        $cacahedValue = $weixinResult;
        $cacahedValue['uid'] = $uid;
        $cacahedValue['scope'] = ScopeEnmu::User;  //16(用户权限)
        return $cacahedValue;
    }

    //自定义一个写入(生成)缓存的方法(key) //生成token
    private function saveToCache($cachedValue)
    {
        //生成令牌key
       $key = self::generateToken();
       $value = json_encode($cachedValue);
       //令牌失效时间在setting配置文件里面定义
       $token_expire_in_time = config('setting.token_expire_in_time');
       //开始写入缓存
        $request = cache($key,$value,$token_expire_in_time);
        if(!$request){
            throw new TokenMissException([
                'msg'=>'服务器缓存异常',
                'errorCode'=>10005
            ]);
        }
        return $key;
    }




}

?>
