<?php


namespace app\api\service;


use app\api\model\OrderProduct;
use app\api\model\Product;
use app\api\model\UserAddress;
use app\lib\exception\OrderMissException;
use app\lib\exception\UserMissException;
use think\Db;
use think\Exception;

class Order
{
 //下订单的商品列表，也就是客户端传递过来的products参数
 //重点:一个oProducts就等于一个'product_id'
     protected $oProducts;
 //真实的商品信息(包括库存量) (在我们数据库里面拿出来的数据)
     protected $products;
     protected $uid;

     //保证主方法对于其它主方法的调用
     public function place($uid,$oProducts)
     {
         //1.oProducts和products作对比(检测库存量的操作)
         $this->oProducts = $oProducts;
         //$products从数据库中查询出来
         $this->products = $this->getProductsByOrderProducts($oProducts);
         $this->uid = $uid;
         //订单商品状态检测
         $oStatus = $this->getOrderStatus();
              //(1)库存量的再次检测，如果不通过,就给用户返回oStatus的信息
              if(!$oStatus['pass'])
              {
                  $oStatus['order_id'] = -1;
                    return $oStatus;
              }
              else{
                 //(2)如果库存量检测通过，则创建订单，就会生成订单id号
                 //2.生成订单快照
                  $orderSnap = $this->snapOrder($oStatus);
                 //3.生成订单(并把订单写入到数据库中去)
                  $order = $this->createOrder($orderSnap);
                  $order['pass'] = true;
                  return $order;
              }

     }





        //生成订单的方法
        private function   createOrder($snap)
        {
                //生成随机订单号
                $orderNo = self::makeOrderNo();
                //使用Order模型获取数据库的字段(因为创建了Order模型，所以可以直接调用数据库的字段)
                $order = new \app\api\model\Order();
                $order->user_id = $this->uid;
                $order->order_no = $orderNo;
                $order->total_price = $snap['orderPrice'];
                $order->total_count = $snap['totalCount'];
                $order->total_img = $snap['snapImg'];
                $order->total_name = $snap['snapName'];
                $order->total_address = $snap['snapAddress'];
                $order->total_items = json_encode($snap['pStatus']);
                //通过模型写入数据库
                $order->save();
                //把order的id赋值到order_product的order_id里面
                $orderID = $order->id;
                $create_time = $order->create_time;

                foreach ($this->oProducts as &$p) {
                    $p['order_id'] = $orderID;
                }
                //调用oederProduct模型再把数据保存多一次在order_product里面
                $orderProduct = new OrderProduct();
                $orderProduct->saveAll($this->oProducts);

                return [
                    'order_no' => $orderNo,
                    'order_id' => $orderID,
                    'order_time' => $create_time
                ];
        }

        //生成订单号的方法(生成一些不唯一的字符串)
       public static function makeOrderNo()
       {
           $yCode = array('A','B','C','D','E','F','G','H','I','J');
           $orderSn =
               $yCode[intval(date('Y')) - 2017] . strtoupper(dechex(date('m'))) .
               date('d') . substr(time(),-5) . substr(microtime(),2,5) .
               sprintf('%02d',rand(0,99));
           return $orderSn;
       }





       //生成订单快照的方法 (接收订单商品的状态参数)
       private function snapOrder($oStatus)
       {
           //代表订单商品的初始快照信息
           $snap = [
               //订单商品的价格
                 'orderPrice'=>0,
               //订单商品的总数量
                 'totalCount'=>0,
               //订单下面所包含的所有商品状态
                 'pStatus'=>[],
               //订单上的用户的收货地址
                 'snapAddress'=>null,
               //图片右边的信息
                 'snapName'=>'',
               //商品图片
                 'snapImg'=>''
           ];
           //然后对以上订单快照信息赋值
            $snap['orderPrice']=$oStatus['orderPrice'];
            $snap['totalCount']=$oStatus['totalCount'];
            $snap['pStatus']=$oStatus['pStatusArray'];
            $snap['snapAddress']=json_encode($this->getUserAddress());
            $snap['snapName']=$this->products[0]['name'];
            $snap['snapImg']=$this->products[0]['main_img_url'];

               if(count($this->products) > 1){
                   $snap['name'] .= '等';
               }
       }

         //定义获取用户地址的真实数据库信息(用于订单快照方法)
         private function getUserAddress()
         {
             $userAddress = UserAddress::where('user_id','=',$this->uid)->find();
              if($userAddress){
                  throw new UserMissException([
                     'msg'=>'用户收货地址不存在，下单失败！',
                     'error'=>60001
                  ]);
              }
              else{
                  return $userAddress->toArray();
              }
         }






         //(pay 2.)对外提供库存量检测的方法
         public function checkOrderStock($orderID)
         {
           //重点：因为之前写了生成订单，所以数据库里面有订单的商品信息，所以直接在订单商品数据库里面查就行
          $oProducts = OrderProduct::where('order_id','=',$orderID)->select();
          $this->oProducts = $oProducts;

          //通过上一步检测出来的oProducts来获取真实库存量的产品信息
          $this->products = $this->getProductsByOrderProducts($oProducts);

          $status = $this->getOrderStatus();
          return $status;
         }








      //这个getOrderStatus方法是根据getProductStatus方法来判断的
      //这是订单商品的状态的方法
      private function getOrderStatus()
      {
         $oStatus = [
            'pass'=>true,
            'orderPrice'=>0,
            'totalCount'=>0,
            'pStatusArray'=>[]
         ];
          //遍历出订单的一个个的商品的id，数量，真实商品
          foreach($this->oProducts as $oProduct) {
              //写出真实商品的库存状态
              $pStatus = $this->getProductStatus(
                           $oProduct['product_id'],
                           $oProduct['count'],
                           $this->products
              );
              //接下来给订单的商品状态赋值
              //如果这个订单的很多商品中的某一个商品有一个没有库存，就不行！
              if (!$pStatus['haveStock']) {
                  //就返回给客户
                  $oStatus['pass'] = false;
              }
              else{
                  //商品总价(单价*总价)
                  $oStatus['orderPrice'] = $oStatus['orderPrice'] + $pStatus['totalPrice'];
                  //商品的总数量
                  $oStatus['totalCount'] = $oStatus['totalCount'] + $pStatus['count'];
                  array_push($oStatus['pStatusArray'], $pStatus);
              }
              return $oStatus;
          }
      }

      //这个方法就是为了拿到真实product的状态
      private function getProductStatus($oPIDs,$oCount,$products)
      {
         //定个数组序号
          $pIndex = -1;
         //保存着订单里面某一个商品的详细信息(先列出来不赋值)
          $pStatus = [
               'id'=>null,
               'name' =>'',
               'count' => 0,
               'totalPrice'=>0,
               'haveStock'=>false
          ];
          //使订单商品的id对应数据库的真实商品id (也就是要使得订单商品与真实商品对应)
         for($i=0;$i<count($products);$i++){
             if($oPIDs == $products[$i]['id']){
                 $pIndex = $i;
             }
         }

          //如果不对应
          if($pIndex == -1){
             //客户端传递的product_id有可能根本不存在
              throw new OrderMissException([
                 'msg'=>'id为'.$oPIDs.'的商品不存在，创建订单失败！'
              ]);
          }
          else{//对应了就把
              $product = $products[$pIndex];
              //真实商品的id号
              $pStatus['id'] = $product['id'];
              $pStatus['name'] = $product['name'];
              $pStatus['count'] = $oCount;
              $pStatus['totalPrice'] = $product['price']*$oCount;
              if($product['stock'] - $oCount >= 0){
              $pStatus['haveStock'] = true;
              }
          }
            return $pStatus;
      }






     //根据 订单商品信息的id 查找 真实的商品信息的id(从数据库查)  (给$this->products赋值)
    private function getProductsByOrderProducts($oProducts)
    {
      //首先定义一个接收订单id的空数组
       $oPIDs = [];
      //然后使用循环  把客户端传过来的订单包含商品的id  赋值到空数组中
        foreach($oProducts as $item){
            array_push($oPIDs,$item['product_id']);
        }
      //接着根据这个 已经有所有的订单商品id号的数组 来查询 真实商品的所有信息
        $products = Product::all($oPIDs)
         ->visible('id','price','stock','name','main_img_url')
         ->toArray();

        return $products;  //(这个结果为数组形式)
    }


}

?>
