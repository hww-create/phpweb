<?php


namespace app\api\service;


use app\lib\enmu\ScopeEnmu;
use app\lib\exception\ForbiddenMissException;
use app\lib\exception\TokenMissException;
use think\Cache;
use think\Exception;
use think\Request;

class BaseToken
{
   //这个方法跟实际对象没有关系 //生成令牌字符串的方法
    public static function generateToken()
    {
        //用32个字符组成一组随机字符串(充当容器)
        $randChars = getRandChar(32);
        //为了加强安全性,用三组字符串，进行md5加密
         $timestamp = $_SERVER['REQUEST_TIME_FLOAT'];
        //salt 盐   在secure配置文件里面配置令牌安全参数
        $salt = config('secuer.token_salt');
        return md5($randChars.$timestamp.$salt);
    }





      //这个方法太重要了也太强大了！！！
      //从缓存里面读取令牌等等的数据
      //根据token的key值来对应用户传来的value值的 通用方法
    public static function getCurrentTokenVar($key)
    {
         //从header头里面获取信息 (key的值)
         $token = Request::instance()->header('token');
         //从缓存里面读取对应的token相关的   value值
         $vars = Cache::get($token);
        //如果 没有 从缓存当中读取到对应的token相关的value值
        if(!$vars){
            throw new TokenMissException();
        }
        else{
             //如果传进来的value值不是数组而是对象,就转化为数组形式
             if(!is_array($vars)){
                  $vars = json_encode($vars,true);
             }
             //通过传过来的key找到指定的缓存值(如果数组中存在相关的key)
             if(array_key_exists($key,$vars)){
                 return $vars[$key];
             }
             else{
                 throw new Exception('尝试获取的Token变量并不存在。');
             }
        }

    }

     //获取当前用户的的id号的方法
    public static function getCurrentUid()
    {
        //token
        $uid = self::getCurrentTokenVar('uid');
        return $uid;
    }






     //前置方法通用方法系列


    //验证初级权限的作用域的前置方法(用于address控制器)
    //CMS管理员和用户都能访问
    public static function needPrimaryScope()
    {
        //从缓存里面读取这个scope （也就是通过这个令牌读取）
        $scope = self::getCurrentTokenVar('scope');
        if($scope){
            if($scope>=ScopeEnmu::User){  //>=16(用户和CMS管理员可以访问)
                return true;
            }
            else{
                throw new ForbiddenMissException();
            }
        }
        else{
            throw new TokenMissException();
        }
    }

    //前置方法(用于Order控制器)
    //只有用户能访问
     public static function needYongHuScope()
     {
       //从缓存里面读取这个scope （也就是通过这个令牌读取）
         $scope = self::getCurrentTokenVar('scope');
         if($scope){
             if($scope==ScopeEnmu::User){  //16 只能用户访问
                 return true;
             }
             else{
                 throw new ForbiddenMissException();
             }
         }
         else{
             throw new TokenMissException();
         }
     }



    //检测数据库order表中的订单号是否和用令牌从缓存中获取的用户id号一致 的方法
    public static function isValidateOperate($checkedUID)
    {
      if(empty($checkedUID))
      {
          throw new Exception('检测当前UID时必须传入一个被检查的UID');
      }
      //获取当前请求用户的UID
       $currentOperateUID = self::getCurrentUid();
      if($currentOperateUID == $checkedUID){
            return true;
      }

    }
}

?>
