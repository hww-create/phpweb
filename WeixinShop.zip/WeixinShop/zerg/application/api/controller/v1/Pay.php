<?php


namespace app\api\controller\v1;

use app\api\service\WxNotify;
use app\api\validate\IdMustBePostiveInt;
use app\api\service\Pay as PayService;
use think\Loader;

Loader::import('WxPay.WxPay',EXTEND_PATH,'Api.php');

class Pay extends BaseController
{
   //定义权限，只能用户访问,CMS管理员不能访问
   protected $beforeActionList = [
    'checkYongHuScope' => ['only'=>'getPreOrder']
   ];


    //首先请求预订单的信息接口
    public function getPreOrder($id='')
    {
     //重点:这里是api要到微信服务器再生成一个微信服务器所要求的订单(预订单)，不是我们管理的订单
     //重点:只需要用户在访问这个接口的时候携带这个令牌，我们就可以拿到用户的openid(这个小程序ID也是同理)
     //重点:我们拿到客户端的令牌的时候，就可以换取这个openid
        (new IdMustBePostiveInt())->gocheck();
        $pay = new PayService($id);
        return $pay->Pay();
    }





    //接收微信通知的参数并且把参数转化到receiveNotify接口的接口
    public function receiveNotify()
    {
        //来获取微信传给我们的$xmlData
        $xmlData = file_get_contents('php://input');
        //发送http请求的方法
        $result = curl_post_raw('www.weixin.com/index.php/api/v1/pay/re_notify?
                                XDEBUG_SESSION_START=13133',$xmlData);
        return ;
    }



    //把参数转化到这个
    public function redirectNotify()
    {
        //通知频率为15/15/30/180/1800/1800/1800/3600, 单位：秒

        //1.检查库存量，超卖
        //2.更新这个订单的status状态(更新order表的status字段)
        //3.减库存(product表的stock字段-相应订单包含商品的数量)
//如果成功处理，我们就返回微信成功处理的信息，否则，我们需要返回没有成功处理的信息

        $notify = new WxNotify();
        //重点:因为在微信的WxPay.Notify.php文件中，NotifyProcess是被封装在Handle中，所以直接调用Handle()方法
        $notify->Handle();
    }
}

?>
