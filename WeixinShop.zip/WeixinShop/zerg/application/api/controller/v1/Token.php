<?php


namespace app\api\controller\v1;


use app\api\service\UserToken;
use app\api\validate\TokenGetValidate;

class Token
{
    public function getToken($code='')
    {
        (new TokenGetValidate())->gocheck();

         $ut = new UserToken($code);
         $token = $ut->get();
         return[
             'token'=>$token
             ];
    }
}

?>
