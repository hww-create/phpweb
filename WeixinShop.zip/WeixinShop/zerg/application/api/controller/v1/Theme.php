<?php

namespace app\api\controller\v1;


//专题控制器
use app\api\validate\IDColletcion;
use app\api\model\Theme as ThemeModel;
use app\api\validate\IdMustBePostiveInt;
use app\lib\exception\ThemeMissException;

class Theme
{
   /*
    *@url /theme?id=id1,id2.......
    *@return 一组theme模型
    */
   //theme简要信息接口
     public function getSimpleList($ids='')
     {
        //这里调用验证器的规则(我们自定义的验证器)
         (new IDColletcion())->gocheck();
        //调用业务层的Banner类的getSimpleListByID方法,并返回结果
         $theme = ThemeModel::getSimpleListByID($ids);
         //判断业务层是否出现了错误
         if($theme->isEmpty()){
             //这里返回模型的对象
             throw new ThemeMissException();
         }
         return $theme;
     }


      /*
       *@url /theme/:id
       */
      //theme详情接口
     public function getComplexOne($id)
     {
         //这里调用验证器的规则(我们自定义的验证器)
         (new IdMustBePostiveInt())->gocheck();
         //调用业务层的Banner类的getThemeWithProducts方法,并返回结果
         $theme = ThemeModel::getThemeWithProducts($id);
         //判断业务层是否出现了错误
         if(!$theme){
             //这里返回模型的对象
             throw new ThemeMissException();
         }
         return $theme;
     }

}

?>
