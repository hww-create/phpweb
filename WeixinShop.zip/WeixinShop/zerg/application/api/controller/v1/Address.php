<?php

namespace app\api\controller\v1;


use app\api\service\UserToken;
use app\api\validate\AddressNewValidate;
use app\api\service\BaseToken;
use app\api\model\User as UserModel;
use app\lib\enmu\ScopeEnmu;
use app\lib\exception\ForbiddenMissException;
use app\lib\exception\SuccessMessage;
use app\lib\exception\TokenMissException;
use app\lib\exception\UserMissException;


class Address extends BaseController
{

    //相当于拦截器(前置方法)
   protected $beforeActionList = [
     'checkPrimaryScope'=>['only'=>'createOrUpdateAddress']
   ];



  public function createOrUpdateAddress()
  {
      $validate = new AddressNewValidate();
      $validate->gocheck();

      //首先根据Token来获取当前请求用户的uid(这里的uid是已经通过令牌的)
       $uid = BaseToken::getCurrentUid();
      //根据uid来查找数据，判断 用户 是否存在，如果不存在抛出异常
       $user = UserModel::get($uid);
        if(!$user){
           throw new UserMissException();
        }
      //获取 用户 从客户端提交来的 地址信息
       $dataArray = $validate->getDataByRule(input('post.'));
      //根据 本地数据库中的 用户地址信息 是否存在，从而判断是添加地址还是更新地址
       $userAddress = $user->UserAddress;
       if(!$userAddress){
           //新增
           $user->UserAddress()->save($dataArray);
       }
       else{
           //更新
           $user->UserAddress->save($dataArray);
       }
       //给用户返回添加或者更新成功的信息
         return json(new SuccessMessage(),201);
  }
}

?>
