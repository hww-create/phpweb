<?php


namespace app\api\controller\v1;


use app\api\service\BaseToken as BaseTokenService;
use app\api\service\BaseToken;
use app\api\validate\IdMustBePostiveInt;
use app\api\validate\OrderPlaceValidate;
use app\api\validate\PagingParameterValidate;
use app\lib\enmu\ScopeEnmu;
use app\lib\exception\ForbiddenMissException;
use app\lib\exception\OrderMissException;
use app\lib\exception\TokenMissException;
use app\api\service\Order as OrderService;
use app\api\model\Order as OrderModel;


class Order extends BaseController
{

    //相当于拦截器(前置方法)
    protected $beforeActionList = [
       'checkYonghuScope'=>['only'=>'placeOrder'],
       'checkPrimaryScope'=>['only'=>'getSummaryByUser,getOrderDetail']
    ];

    //(1)首先获取用户的uid(传过来的参数)
    //(2)用户在选择商品后，向API提交包含它所选择商品的相关信息
    //(3)API在接收到订单里面包含的商品信息后，就需要开始检查订单相关商品的库存量
    //(4)这个商品有库存，把订单数据存入到数据库中=下单成功，就返回客户端信息，告诉客户端可以支付了
    //(5)客户端(小程序)调用我们的支付接口，进行支付
    //(6)(1)还需要再次进行库存量的检测(存在下单之后不会进行立刻支付的可能)
    //(6)(2)服务器这边就可以调用微信的支付接口进行支付
    //(7)小程序根据服务器返回的结果拉起微信支付
    //(8)微信会返回给我们一个支付的结果(异步)
    //(9)支付成功，也需要进行库存量的检查
    //(10)最终总成功进行库存量的扣除

   public function placeOrder()
   {
       (new OrderPlaceValidate())->gocheck();
       $products = input('post.products/a');
       $uid = BaseTokenService::getCurrentUid();

       //获取订单生成的方法
       $order =  new OrderService();
       $status = $order->place($uid,$products);
       return $status;
   }


   //订单信息分页查询接口
   public function getSummaryByUser($page,$size)
   {
       (new PagingParameterValidate())->gocheck();
       //使用令牌从缓存中获取用户的id
       $uid = BaseToken::getCurrentUid();
       $pagingOrders = OrderModel::getSmmaryByUser($uid,$page,$size);
       if($pagingOrders->isEmpty()){
           return[
               'data'=>[],
               //分页查询的当前页码    (调用源码的方法)
               'current_page'=>$pagingOrders->getCurrentPage()
           ];
       }
       else {//如果不为空
           $data = $pagingOrders->toArray();
           return [
               'data' => $data,
               //分页查询的当前页码    (调用源码的方法)
               'current_page' => $pagingOrders->getCurrentPage()
           ];
       }
   }


   //订单详情接口
    public function getOrderDetail($id)
    {
        (new IdMustBePostiveInt())->gocheck();
        //传入这个模型的某一条记录的属性，找到对应的订单的记录，从而把它作为模型的参数返回回来
        $orderDetail = OrderModel::get($id);
        if(!$orderDetail)
        {
            throw new OrderMissException();
        }
        return $orderDetail->hidden(['prepay_id']);
    }



}

?>
