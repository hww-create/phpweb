<?php


namespace app\api\controller\v1;
use app\api\service\BaseToken;
use think\Controller;



class BaseController extends Controller
{

    //管理员和用户都能访问(访问createOrUpdateAddress的前置方法)
    protected function checkPrimaryScope()
    {
        BaseToken::needPrimaryScope();
    }


    //只能用户访问，管理员不能访问(访问placeOrder的前置方法)
    protected function checkYongHuScope()
    {
        BaseToken::needYongHuScope();
    }
}

?>
