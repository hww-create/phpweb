<?php


namespace app\api\controller\v1;


use app\api\validate\IdMustBePostiveInt;
use app\api\validate\ProductCountValidate;
use app\api\model\Product as ProductModel;
use app\lib\exception\ProductMissException;

class Product
{
    //获取 最近新品 的接口（recent）
    //默认展示(客户端传来的参数决定)条商品
    public function getRecent($count=15)
    {
        //我们自定义的验证器
        (new ProductCountValidate())->gocheck();
        //调用业务层的Banner类的getMostRecent()方法,并返回结果
        $products = ProductModel::getMostRecent($count);
        //判断业务层是否出现了错误
        if($products->isEmpty()){
            //这里返回模型的对象
            throw new ProductMissException();
        }
        //对summary这个属性做一个临时隐藏
        $products = $products->hidden(['summary']);
        //获取到了就返回给它
         return $products;
  }


  // 分类商品 接口
    public function getAllProductInCategory($id)
    {
        (new IdMustBePostiveInt())->gocheck();
        $products =  ProductModel::getAllProductInCategoryByID($id);
        if($products->isEmpty()){
            throw new ProductMissException();
        }
//        //对summary这个属性做一个临时隐藏
//         $products = $products->hidden(['summary']);
        return $products;
    }


    //详情信息 接口
    public function getProductDetail($id)
    {
        (new IdMustBePostiveInt())->gocheck();
        $product = ProductModel::getProductDetailByID($id);
        if(!$product){
            throw new ProductMissException();
        }
        return $product;
    }


    //删除商品的接口
    public function deleteProductID()
    {

    }
}

?>
