<?php

namespace app\api\controller\v1;
use app\api\model\Category as CategoryModel;
use app\lib\exception\CategoryMissException;

//分类控制器
class Category
{
    //分类列表接口
    public function getAllCategories()
    {
      $categories = CategoryModel::all([],'Image');
      if(!$categories){
          throw new CategoryMissException();
      }
        return $categories;
    }
}

?>
