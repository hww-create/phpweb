<?php

namespace app\api\controller\v1;
use app\api\validate\IdMustBePostiveInt;
//这里给model层的Banner起一个别名以更好的区分M层和C层的Banner
use app\api\model\Banner as BannerModel;
use app\lib\exception\BannerMissException;
use think\Exception;


class Banner
{
     //这个只是一个参数，不是一组参数，才会这么写
    public function getBanner($id) //$id就是接口的参数 //将id作为参数校验
    {
          //我们自定义的验证器
          (new IdMustBePostiveInt())->gocheck();
          //调用业务层的Banner类的getBannerByID方法,并返回结果
             $banner = BannerModel::getBannerByID($id);
             //判断业务层是否出现了错误
             if(!$banner){
                 //这里返回模型的对象
                 throw new BannerMissException();
             }
            //获取到了就返回给它
            return json($banner);
    }
}



?>
