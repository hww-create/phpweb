<?php

namespace app\api\controller\v2;
use app\api\validate\IdMustBePostiveInt;
//这里给model层的Banner起一个别名以更好的区分M层和C层的Banner
use app\api\model\Banner as BannerModel;
use app\lib\exception\BannerMissException;
use think\Exception;


class Banner
{

    public function getBanner($id) //$id就是接口的参数 //将id作为参数校验
    {
       return "This is a version.";
    }
}



?>
