<?php


namespace app\api\model;


use think\Model;

class Image extends BaseModel
{
 //设置隐藏字段(使用hidden) 隐藏了image表的字段
 protected $hidden = ['id','from','delete_time','update_time'];


    //设置读取器的方法:命名方式:get(要读取的名字)Attr
    public function getUrlAttr($value,$data)
    {
      return $this->prefixImgUrl($value,$data);
    }
}

?>
