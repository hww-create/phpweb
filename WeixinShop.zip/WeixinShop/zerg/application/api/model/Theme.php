<?php


namespace app\api\model;
use think\Model;

class Theme extends Model
{
    //隐藏theme表的部分字段
     protected $hidden = [
       'delete_time','update_time',
        'topic_Img_id','head_img_id'
     ];




     //theme简要信息接口对应的查询模型
     public static function getSimpleListByID($ids)
     {
         //这是C层来调用 查询的方法(就不用在C层里面写调用的代码)
         $idss = explode(',',$ids);
         $theme = self::with(['topicImg','headImg'])->select($idss);
            return $theme;
     }



     //theme详情接口对应的查询模型
     public static function getThemeWithProducts($id)
     {
          $theme = self::with('Product,topicImg,headImg')->find($id);
          return $theme;
     }





   //topicImg模型(一对一)
   public function topicImg()
   {
       //使用topicImg模型关联Image模型
       return $this->belongsTo('Image','topic_img_id','id');
   }


   //headImg模型(一对一)
   public function headImg()
   {
      //使用topicImg模型关联Image模型
       return $this->belongsTo('Image','head_img_id','id');
   }


   //products模型(多对多)
    //theme详情接口对应的关联模型
   public function Product()
   {
       return $this->belongsToMany('Product','theme_product','product_id','id');
   }

}

?>
