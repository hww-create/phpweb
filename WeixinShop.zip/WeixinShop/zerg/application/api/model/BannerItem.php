<?php

namespace app\api\model;
use think\model;

class BannerItem extends BaseModel
{
    //设置隐藏字段(使用hidden) 隐藏了banner_item表的字段
    protected $hidden = ['id','img_id','delete_time','banner_id','update_time'];

    //关联函数(Banner_item关联image)
   public function Image()
   {
       return $this->belongsTo('Image','img_id','id');
   }

}

?>
