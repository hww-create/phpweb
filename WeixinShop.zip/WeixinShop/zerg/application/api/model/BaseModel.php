<?php


namespace app\api\model;


use think\Model;

class BaseModel extends Model
{

     //在基类里面设置类似于读取器的方法，让其他子类的读取器调用这个方法
    protected function prefixImgUrl($value,$data)
    {
        //读取自定义的配置文件 from是图片的来源，除1不是本地之外的图片
        $final = $value;
        if($data['from'] == 1){
            $final = config('setting.img_prefix').$value;
        }
        return $final;
    }
}

?>
