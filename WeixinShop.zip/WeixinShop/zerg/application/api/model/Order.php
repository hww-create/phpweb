<?php


namespace app\api\model;


class Order extends BaseModel
{
   //隐藏字段
   protected $hidden = ['user_id','delete_time','update_time'];
   //自动写入时间戳
   protected $autoWriteTimestamp = true;


    //(order表字段:snap_items)  (读取器)
    public function getSnapItemAttr($value)
    {
        if(empty($value))
        {
            return null;
        }
        return json_decode($value);
    }


    //(order表字段:snap_address) (读取器)
    public function getSnapAddressAttr($value)
    {
        if(empty($value))
        {
            return null;
        }
        return json_decode($value);
    }



     //订单信息分页查询方法
     public static function getSmmaryByUser($uid,$page=1,$size=15)
     {
         //paginate就为分页查询 (使用简洁模式)
         //并且根据时间倒序排序
       $pagingData = self::where('user_id','=',$uid)
            ->order('create_time,desc')
            ->paginate($size,true,['page'=>$page]);
       return $pagingData;
     }
}

?>
