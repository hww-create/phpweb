<?php


namespace app\api\model;


class Category extends BaseModel
{
    protected $hidden = [
            'delete_time','update_time'
    ];



    //分类列表模型关联查询方法
    public static function getAllCategoriesCanShu()
    {
        $categories = self::with('Image')->select();
        return $categories;
    }


    //分类列表模型关联
   public function Image()
   {
      return $this->belongsTo('Image','topic_img_id','id');
   }



}


?>