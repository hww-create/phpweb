<?php


namespace app\api\model;


class UserAddress extends BaseModel
{
protected $hidden = ['id','delete_time','user_id'];

//  public static function getUserAddressAll()
//  {
//
//  }


}

?>
