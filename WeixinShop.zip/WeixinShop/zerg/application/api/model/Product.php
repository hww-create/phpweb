<?php

namespace app\api\model;

use app\api\model\Product as ProductModel;

class Product extends BaseModel
{
   //隐藏product表的部分字段
   protected $hidden = [
       'delete_time','update_time',
       'category_id','create_time',
       'main_img_id',
   ];


    //最近新品查询模型(recent)
    public static function getMostRecent($count)
    {
      //最近新品这里是独立的，不需要关联模型
        //查询指定数量的商品
      $products = self::limit($count)
                 //这个商品按照创建时间字段倒序排列
                 ->order('create_time desc')
                 ->select();
        return $products;
    }


    //分类商品查询模型(categoryProduct)
    public static function getAllProductInCategoryByID($categoryID)
    {
        $products = self::where('category_id','=',$categoryID)->select();
        return $products;
    }


    //商品详情查询模型(productDetail)
    public static function getProductDetailByID($id)
    {
        $product = self::with([
             'productImage'=>function($query){
                        $query->with(['ImageUrl'])
                              ->order('order','asc');
             }
        ])
                       ->with(['productProperty'])
                       ->find($id);
        return $product;
    }




    //Product模型创建与product_image表关联的模型关系的方法
    public function productImage()
    {
        return $this->hasMany('productImage.ImageUrl','product_id','id');
    }

    //Product模型创建与product_property表关联的模型关系的方法
    public function productProperty()
    {
        return $this->hasMany('productProperty','product_id','id');
    }




   public function getMainImgUrlAttr($value,$data)
   {
       return $this->prefixImgUrl($value,$data);
   }



}

?>
