<?php


namespace app\api\model;


class productProperty extends BaseModel
{
    protected $hidden = [
        'img_id','delete_time','id'
    ];
}

?>
