<?php


namespace app\api\model;


class User extends BaseModel
{
    //关联模型(使用用户模型关联用户地址的模型，是一对一的关系)
    public function UserAddress()
{
    return $this->hasOne('UserAddress','user_id','id');
}






    //获取微信服务器的id(从数据库里面查)
    public static function getByOpenID($openid)
    {
        $user = self::where('openid','=',$openid)->find();
        return $user;
    }



    //

}

?>
