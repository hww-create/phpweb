<?php


namespace app\api\model;


class ImageUrl
{

}

?>
