<?php


namespace app\api\model;


class productImage extends BaseModel
{
    protected $hidden = [
        'img_id','delete_time','product_id'
    ];

    //productImage模型创建与image表关联的模型关系的方法
    //因为是获取image图片的url的，所以定义了这个名字
    public function ImageUrl()
    {
        return $this->belongsTo('ImageUrl','img_id','id');
    }
}

?>
