<?php


namespace app\api\model;
use think\Db;
use think\Exception;
use think\Model;
use think\Request;

class Banner extends BaseModel
{
     //设置隐藏字段(使用hidden) 隐藏了banner表的字段
     protected $hidden = ['delete_time','updata_times'];


    //这是C层来调用 查询的方法(就不用在C层里面写调用的代码)
    public static function getBannerByID($id)
    {
        //把这个查询语句放在model层里面(封装) self代表自己的类中有model(所以就用self)
        $banner = self::with(['BannerItem','BannerItem.Image'])->find($id);
        return $banner;
    }


    //关联函数(Banner关联Banner_item)
    public function BannerItem()
    {
        //因为是一对多的关系，所以使用hasMany方法
        return $this->hasMany('BannerItem','banner_id','id');
    }






}

?>
