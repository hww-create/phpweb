<?php


namespace app\api\validate;



//theme的验证规则(专题)
class IDColletcion extends BaseValidate
{
    //这里是定义验证器的验证规则
    protected $rule=[
            'ids'=>'require|checkIDs'
    ];
    //这里定义验证不通过的返回给用户的信息
    protected $message = [
            'ids'=>'传过来的id必须为以逗号分割的多个正整数'
    ];

    //ids = id1,id2......
    //首先把客户端传来的字符串转换为数组形式
    protected function checkIDs($value)
    {
       //这里把客户端传过来的字符串分割为数组形式
       $values = explode(',',$value);
       //如果为空数组
       if(empty($values)){
           return false;
       }
        //如果不为正整数
       foreach($values as $id){
          if(!$this->isPostiveInteger($id)){
              return false;
          }
       }
       return true;
    }
}

?>
