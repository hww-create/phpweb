<?php


namespace app\api\validate;

//Token令牌验证器
class TokenGetValidate extends BaseValidate
{
    //传来的code不能为空值
   protected $rule = [
           'code' => 'require|isNotEmpty'
   ];


   //定义传值的错误信息然后返回给客户端
   protected $message = [
           'code'=>'没有code还想获取token,没门!'
   ];

}

?>
