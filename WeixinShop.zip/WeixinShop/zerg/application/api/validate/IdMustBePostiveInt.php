<?php
namespace app\api\validate;
use think\Validate;


//banner（主页）验证规则
class IdMustBePostiveInt extends BaseValidate
{
    //首先设置校验规则
    protected $rule = [
        'id'=>'require|isPostiveInteger'
        ];

    //这里定义验证不通过的返回给用户的信息
    protected  $message = [
        'id'=>''
    ];

}
?>