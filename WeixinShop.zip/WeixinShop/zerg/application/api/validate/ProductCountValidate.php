<?php


namespace app\api\validate;

//product产品验证器
class ProductCountValidate extends BaseValidate
{
   protected $rule = [
       'count' =>'isPositiveInteger|between:1,15'
   ];
}
?>
