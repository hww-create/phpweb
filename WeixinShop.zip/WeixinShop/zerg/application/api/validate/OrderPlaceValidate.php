<?php


namespace app\api\validate;


use app\lib\exception\ParameteException;

class OrderPlaceValidate extends BaseValidate
{
    protected $oProducts = [
     ['product_id'=>1,'count'=>2],
     ['product_id'=>2,'count'=>3],
     ['product_id'=>3,'count'=>2],
    ];

    protected $products = [
     ['product_id'=>1,'count'=>2],
     ['product_id'=>2,'count'=>2],
     ['product_id'=>3,'count'=>3],
    ];



    //这个是直接给用户传过来的参数整体做校验(商品组)
    protected $rule = [
        'products'=>'checkProducts'
    ];




    //这里这么写规则的目的是为了更好的为代码增加复用性，也就是避免了代码重复写，直接用面向对象的方式封装调用
    protected $singleRule = [
        'product_id'=>'require|isPositiveInteger',
        'count'=>'require|isPositiveInteger'
    ];


    //这是对 一组数组类型的数据 做校验
    /*
     * (1)必须为数组
     * (2)必须不能为空
     * (3)必须为正整数
     */
    //自定义商品组的校验方法
    protected function checkProducts($values)
    {
        if(!is_array($values)){
            throw new ParameteException([
                'msg'=>'商品参数传输格式不正确！'
            ]);
        }
        if(empty($values)){
            throw new ParameteException([
                'msg'=>'商品列表不能为空！'
            ]);
        }
        foreach($values as $value){
           $this->checkProduct($value);
        }

        return true;

    }


    //这个方法里面包含了我们在上面定义的single中整数的校验
    protected function checkProduct($value){
        $validate = new BaseValidate($this->singleRule);
        $result = $validate->check($value);
         if(!$result){
             throw new ParameteException([
                 'msg'=>'商品参数列表错误'
             ]);
         }
            return $result;
    }
}

?>
