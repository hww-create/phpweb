<?php


namespace app\api\validate;


//用户收货地址验证器(address)
class AddressNewValidate extends BaseValidate
{
    protected $rule = [
            'name'=>'require|isNotEmpty',
            'mobile'=>'require|isMobile',
            'province'=>'require|isNotEmpty',
            'city'=>'require|isNotEmpty',
            'country'=>'require|isNotEmpty',
            'detail'=>'require|isNotEmpty',
    ];
}

?>
