<?php


namespace app\api\validate;
use app\lib\exception\ParameteException;
use think\Validate;
use think\Request;
use think\Exception;

//基础验证器
class BaseValidate extends validate
{

    //把最最基础的验证器的 验证规则 写在基础验证器的控制器中，使得其它所有验证器控制器都继承这个Basevalidate
    //公共的gocheck()方法,使得所有的控制器都调用这个验证规则
    public function gocheck()
    {
        //这里相当于是获取了客户端传来的参数($id)(获取http传入的参数)
           $request = Request::instance();
           $params = $request->param();
        //对这些参数做校验
           $result = $this->batch()->check($params);

        //接着判断数据是否符合验证规则，如果错误，抛出异常
          if(!$result){
              //抛出异常
              throw new ParameteException([
                  'msg'=>$this->error,
              ]);
          }
          else{
              return true;
          }

    }


     //如果TP5没有校验规则，就要自定义校验规则，也就是自定义函数来设置
    //在基类的验证器里面，这些都为公共的验证方法
    protected function isPostiveInteger($value='',$rule='',$data='',$field='')
    {
        //如果值为数字并且为整数并且大于0，返回真
        if(is_numeric($value) && is_int($value + 0) && ($value + 0) > 0){
            return true;
        }
        else{
            //这里为了让结果返回回到IDCollection，所以就要返回true
            return false;
        }
    }



     protected function isMobile($value)
     {
         $rule = '^1(3|4|5|6|7|8)[0-9]\d{8}$^';
         $result = preg_match($rule,$value);
         if($result){
           return true;
         }
         else{
             return false;
         }
     }


    protected function isNotEmpty($value='')
    {
        if(empty($value)){
            return false;
        }
        else{
            return true;
        }
    }



    //这个是重点
    //创建 根据这个通用的规则获取数据 的方法
    //这个参数(数组)包含客户端传过来的所有参数变量
    public function getDataByRule($arrays)
    {
        //这些id号全部都是从我们的缓存通过令牌来读取出来的
       if(array_key_exists('user_id',$arrays)|array_key_exists('id',$arrays)){
           //不允许包含user_id或者uid,防止恶意覆盖user_id外键
           throw new ParameteException([
               'msg'=>'参数中包含有非法的参数名user_id或者uid'
           ]);
       }
       $newArray = [];
        foreach ($this->rule as $key=>$value) {
 //这里把客户端的参数的数组赋值给了我们的自定义空数组，也就是获取到了用户数据
            $newArray[$key] = $arrays[$key];
       }
         return $newArray;
    }


}

?>
