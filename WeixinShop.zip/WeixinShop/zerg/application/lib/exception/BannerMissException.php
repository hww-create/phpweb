<?php


namespace app\lib\exception;


//自定义异常类
class BannerMissException extends BaseException
{
    //这里子类的内容已经把继承父类的内容重写了
    public $code = 404;
    public $msg = '请求的Banner不存在';
    public $errorCode = 40000;
}
?>
