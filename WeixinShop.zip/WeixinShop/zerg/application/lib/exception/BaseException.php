<?php

namespace app\lib\exception;
use think\Exception;

//自定义的最最基础异常类(相当于try{})
class BaseException extends Exception
{
    //HTTP的状态码 404,200
    public $code = 400;
    //错误具体信息
    public $msg = '参数错误';
    //自定义的错误码
    public $errorCode = 10000;


    //构建验证器异常的构造函数
     public function __construct($params=[])
     {
         //写上防御性代码
         if(!is_array($params)){
               //如果传过来的参数不是数组，则返回到用户那里
               return;
         }
         //如果用户传入的是数组，则可以把用户参数传入到这个基类的成员变量中
         if(array_key_exists('code',$params)){
             $this->code = $params['code'];
         }
         if(array_key_exists('msg',$params)){
             $this->msg = $params['msg'];
         }
         if(array_key_exists('errorCode',$params)){
             $this->errorCode = $params['errorCode'];
         }
     }
}

?>
