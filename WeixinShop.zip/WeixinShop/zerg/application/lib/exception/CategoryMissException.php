<?php


namespace app\lib\exception;


class CategoryMissException extends BaseException
{
    //这里子类的内容已经把继承父类的内容重写了
    public $code = 404;
    public $msg = '指定的类目不存在,请检查参数';
    public $errorCode = 50000;
}

?>
