<?php
namespace app\lib\exception;
use Exception;
use think\Config;
use think\exception\Handle;
use think\Log;
use think\Request;

//这个ExceptionHandler的类就是处理结果的(catch{})
//如果要自定义异常结果的话，就要重写handle
class ExceptionHandler extends Handle
{
    private $code;
    private $msg;
    private $errorCode;

    public function render(\Exception $ex)
    {
        //如果用户行为导致的异常
        if ($ex instanceof BaseException) {
            //这里是自定义的异常
            $this->code = $ex->code;
            $this->msg = $ex->msg;
            $this->errorCode = $ex->errorCode;
        } //       //如果服务器自身的异常
        else {
            //就使用config里面的应用调试模式配置来判断(如果正确)
            if (Config::get('app_debug')) {
                //指定框架错误的页面(还原TP5的render方法)
                return parent::render($ex);
            }
            else {
                //重点:当前的错误需要用日志来处理和记录
                $this->code = '500';
                $this->msg = '服务器内部错误，不想被看到';
                $this->errorCode = '999';
                $this->recordErrorLog($ex);
                }
        }


        //获取用户参数才能知道有没有异常，才能捕捉并处理异常
        $request = Request::instance();


//       //输出结果出来
        $result = [
            'msg' => $this->msg,
            'error_code' => $this->errorCode,
            'request_url' => $request->url()
        ];


//        //最后返回结果
        return json($result, $this->code);
    }



      //添加异常处理的日志方法
        private function recordErrorLog(\Exception $ex)
        {
            //因为在config关了日志自动生成，所以这里要初始化出来
            Log::init([
                'type'=>'File',
                'PATH'=>'LOG_PATH',
                'level'=>['error']
            ]);
            //查看错误的信息是什么(第二个参数是错误的等级)
            Log::record($ex->getMessage(),'error');
        }
}

?>
