<?php


namespace app\lib\exception;


class SuccessMessage
{
    public $code = 201;
    public $msg = 'ok';
    public $errorCode = 0;
}

?>