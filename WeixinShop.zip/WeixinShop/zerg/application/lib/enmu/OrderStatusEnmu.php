<?php


namespace app\lib\enmu;


class OrderStatusEnmu
{
   //待支付
    const UNPAY = 1;
   //已支付
    const PAY = 2;
   //已支发货
    const DELIVERED = 3;
   //待支付，但库存不足
    const PAY_BUT_OUT_OF = 4;
}

?>
