<?php

namespace app\lib\enmu;


class ScopeEnmu
{
   //Scope
   const User = 16;
   const Super = 32;
}

?>
